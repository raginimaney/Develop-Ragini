# iapiservice

This repository contains two sets of DGC reference examples, one in Java and one in Node, both following the [IAPI specification](https://docs.kasisto.com/).   This project establishes a set of reference implementations that can be used by internal and external teams to build new IAPI implementations.  Portions of this codebase may eventually be extended into libraries that offer high-level abstractions to allow teams to build IAPI applications more efficiently.  Until then, the IAPI methods themselves (/start_conversation, /user_user_input, etc as documented in the specification above) are the primary contract.  Any intents built off this codebase cannot be guaranteed to be supported in the future, so use at your own risk. 

This project has subdirectory for each language implementation.  Consult the READMEs for [Java](./java) and [Node](./node) for more information on those respective implementations. 

1. Intent definitions all implementations are located [here](./intent_definitions/)
2. Integration Testcases for all implementations are located  [here](./test/testcases/)

While the intent-definitions and testcase frameworks are language-independent, by convention specific subdirectories exist to associate them with the corresponding implementation.  For example, if an intent-definition is associated with only the java-implementation, it should be placed [here](./intent_definitions/java/)


## How can Developers can integrate with Kai-Application 

As with all IAPI applications, in order to build an end-to-end intent, you must combine IAPI webhooks (/start_conversation, /send_user_input , /cancel_user_input) with a kai-application+db running the /intents method.  The IAPI webhook methods should be implemented in this project based on the examples provided. 

There are two primary mechanisms for developers to test their integration. 

1. using a locally-run version of kai/db (via docker-containers or local source code)
2. or via a deployed version of the application (in AWS or customer onprem)


### Customer Dev Integration

To support customer integrations, Kasisto may provide an AWS-hosted version of the Kai-application which developers can use to submit their intent-definitions and test their integration.   Customers can then use the json-tool, CAPI-api or functional tests to verify the functionality of their end-to-end application. In such a context, the deployment looks like this:

![alt text](https://github.com/kasisto/iapiservice/blob/master/docs/customer_integration.png)

### Kasisto-Internal Dev Integrations

Kasisto developers have a few options in testing their integration.  They can pull source from git for kai and run the application locally. For most-app developers, configuring and running the kai application can be a hassle.  It is thus recommended that an app developer working on DGCs use a container-based approach to running a stable version of the kai-application/db. 

The deployment looks like this:

![alt text](https://github.com/kasisto/iapiservice/blob/master/docs/kasisto_integration.png)

The two-container based approaches for running the kai-application are described below: 

### Docker Setup

A docker-compose [file](./docker-compose.yml) defines a set of targets for bring up an iapiservice and it's dependendent services (kai, kai-database).   
  1. Install Docker (including setting memory to 8GB in preferences)
  2. type 'docker-compose up iapiservice_java' or 'docker-compose up iapiservice_node' depending on which version of the application you are running.  Note, follow the instructions in the respective java/node projects for building the iapi applications.
  3. Test via the json tool in http://localhost:8090/kai/api/v1/json/index.html
  4. Submit your forms to your local kai:
      ```curl -X POST -H "Content-Type: application/json" -H "secret: <secret>" -d@<intent_def>.json       http://localhost:8090/kai/api/v1/intents/```
  5. Run [json-tool](https://localhost:8090/kai/api/v1/json/index.html) and asking questions from intent definitions
  

# Testing Frameworks

Unit-testing is recommended.  Following the guidance in the respective node/java readmes for how to perform unit-testing [here](./node/README.md#unit-testing) and [here](./java/README.md#unit-testing).  For integration-testing, there are two frameworks that are supported, with test-cases and tools that work across any implementation.  

1. Functional Tests
2. Botium tests

Both frameworks provide tests over end-to-end iapi+kai system and verify user-input/system response behavior.  Either framework can be used to test against a DGC in any implementation language (node, java, etc).  

## Functional Tests

Functional tests (aka bobscript) are the default framework that most Kasisto-developers will have familarity and is currently integrated into our kai-build processes.   

An Example of such bobscript tests:
```
["start over",{"api":"capi","rule":"valid_capi_response","intent":"VpaStartOver"}],
["show my business balance",{"api":"capi","rule":"valid_capi_response","intent":"cashposition","sub_intent":"start_conversation"}],
["USD",{"api":"capi","rule":"valid_capi_response","intent":"cashposition","sub_intent":"CP_currency"}],
```

Functional tests should be placed in the appropriate java/node [subdirectory](tests/testscases/functional)

To execute the functional you can run the test-runner out a local-directory where the kai-application is checked out or you can use the 

```
ant -buildfile ../kai/tests/build.xml unit  -Dno.testcore.publish=true -Dtests.filename=<path_to_testfile> -Dserver.url=http://kai-int.kitsys.net -Dserver.port=8090
```

Alternatively, you use a docker-based test-runner via by invoking 'docker-compose run functional_testrunner. 

## Botium Tests

The [botium framework](https://www.botium.at/) provides similar functionality to the functional tests, but provides a pared-down test format that may make it easier for non-technical people to write.  An example of the format is as follows:

```
#me
i need help with a transaction

#bot default
Whats the reference number? If thats not available, tell me the account, amount and date.

#me
8752700122HI

#bot default
Ok. Here is what I found:
          
#bot default
Transaction id:8752700122HI
```

Botium tests should be placed in the respective node/java [directory](./test/testcases/botium/spec/)

To run the test-cases, you need to execute the test-proxy and then the test-runner as follows:

'npm run testproxy'
'npm run testdev'

This will execute any test-cases that are defined in the development [test-directory](/test/testcases/botium/spec/convo_dev).

Botium also provides 'emulator' tools for 'constructing' test-case automatically by interacting with the a running version of the bot and then 'saving' the conversations. These can be used to provide a regression testbed to ensure that the bot-behavior does not change. Or these testcases can then subsequently updated to specify the desired behavior in the case where the bot is not performing correctly. 

To run the console-based emulator from botium [directory](./test/testcases/botium) type 'npm run emulator' or 'npm run emulatorBrowser' to run the browser-based emulator. 



 
 ## Build Processes for Kasisto DGC Development
 
For Kasisto-internal development, we have established quality-gates to ensure that the integrity of the builds.  We are currently using Gitlab.com to provide end-to-end CI.  We have integrated hooks into Github.com so that any new PR into the iapiservice project will trigger end-to-end build and successful execution of integration tests before a PR can be merged into master. 

The gitab pipeline configuration [file](.gitlab-ci.yml) defines the steps of the build process. 

1. Execute unit tests
2. Build iapi-service docker container
3. Deploy kai, iapi-service containers into kubernetes cluster
4. Execute botium and functional tests
5. Teardown containers. 
6. (Optionally) deploy stable iapi-container to a persistent kubernetes environment (http://iapi-stable.kasis.to)

Note, additional kubernetes configuration is defined [here](./openshift/iapi-template.yaml)




 
 We are looking into how to integrate functional and test_forms into a gating process as well though the following step:
 
 1. Spin up 3 containers for a) stable version of Kai, b) db, and c) test-runner (via docker-compose and other supporting CI systems)
 2. Bring up the candidate services in 4th container, and uploaded the intent-definitions
 3. Execute the test results from the test-container to the [build server](http://buildserver.kitsys.net)
 4. Gate on functional/test_forms test results.
 
 The overall internal build workflow looks as follows:
 
 ![alt text](https://github.com/kasisto/iapiservice/blob/master/docs/kasisto_ci_dgc.png)
 
 
 ## Adding Customer Normalizers
 
To enable any kai-normalizer for triggers you can specify it in the intent-definition as follows:
 
 ```
   {
            "name" : "cc_num",
            "type" : "Normalizer",
            "norm_type" : "credit_card_number"
    }
```

Use type, 'Normalizer' and for norm_type, use the the TAG value defined in the Normalizer class from the kai-subapp (e.g.  public static final String TAG = "<credit_card_number>";)

Make sure that the normalizer label (e.g. public static final String LABEL = "Domain:CreditCardNumber";) is set in two relevant environment configurations for the kai subapp: 

1. normalization_sets in stat_config_4.properties
2. domain_form_filling_normset in domain.properties

To use the kai-normalizers within iapi-intents for non-triggers, specify the type with the convention 'norm.x', where is the kai normalizer tag, e.g: 

```
 {
  "conversation_id" : "36520f31-b4c9-48e1-95e8-c10ad53d4282",
  "conversation_state" : "PENDING_USER",
  "message_contents" : [ ],
  "request_user_input" : {
    "name" : "card_number",
    "type" : "norm.credit_card_number",
  }
}
```

Note, there may be NLU quality considersations to adding new normalizers to a kai-application for the first time, so you should validate your model with the functional tests for the subapp and you may need to retrain your core NLU models.

 ## Using Environment properties
 
 When deployed within Kasisto environments as a traditional 'Service', the corresponding customer env properties will be made available to the service under /etc/kasisto/env.properties.   There is an existing class IapiEnvConf which can help retrieve the properties for use in the webhook services.   Be sure to provide a reasonable fallback behavior in the case where the property is not populated.   Common use-case for environment properties are Enterprise-api secrets/endpoints, which vary across qa/stage deployments. 



