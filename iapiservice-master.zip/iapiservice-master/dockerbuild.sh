#! /bin/ash

set -e 
exit 0
