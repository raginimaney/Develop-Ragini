# Java Framework Overview

This codebase builds off previously built [internal examples](https://github.com/kasisto/services/tree/master/guided-conv-webhook).  The framework has been extended in a few ways:

1) Developed a FSM-based model for representing the IAPI workflow with notions of state, transition and action.  These aim to provide a level-model for the workflow distinct from the business logic around validation, NLG, and backend integration. 
2) Provide simple template models on top of the FSM model that supports simple end-to-end flows to collect parameters.  The goal here is to provide a 'recipe' for simple forms such as dynamic-faq and linear-workflows while allowing developers to fallback to the full workflow model when necessary.  
3) Introduce conventions for [Internationalization](https://github.com/kasisto/iapiservice/blob/master/java/README.md#internationalization) and externalization of text/prompt resources
4) Demonstrate Integration with the EAPI via Modified EAPI Client
5) Start to introduce best-practices for unit-testing

## Code Organization

The code is organized into key sections. 

1. [Core](./src/main/java/com/kasisto/iapi/webhook/core)
2. [Apps](./src/main/java/com/kasisto/iapi/webhook/apps)

Core contains the key library-components including the FSM-model and the key interfaces.  Apps contains the individual applications.   New intents should be placed as a subpackage under apps.  


## Examples

There are four examples in this apps codebase
1. Card renewal ([workflow sceenshot](./docs/cardrenew.png))
2. Insights ([workflow sceenshot](./docs/insight_budget.png))
3. GUAI ([workflow sceenshot](./docs/guai.png))
4. Business Banking CashPosition ([recording of basic flow](./docs/java_cash_position.mov) , [workflow sceenshot](https://github.com/kasisto/iapiservice/blob/master/java/docs/cashposition.png))
5. Basic Bank Form (built off the generic linear model)
3. Dynamic FAQ ([workflow sceenshot](./docs/dyn_faq_flow.png))

These examples are in varying states of completeness but aim to exercise different types of scenarios. 

## The FSM model

The updated version is based on an explicit workflow model that uses FSM to define the workflow separate from the logic to process input and generate responses.  In this model, there are the follow concepts:

Concepts:

1. Workflow: A high-level per-intent flow composed of States and Transitions. 
2. State: A step in a workflow
3. Transition: A path between two states, when a condition is satisfied for for a particular event
4. Event: The set of user inputs (parameters) for the current input (or over the entire session) 
5. Condition: A test of over the events inputs that permits the transition between states
6. Action: The resulting effect of a transition between states, corresponding to a result display to user




## The Linear Model

In the classes provided in the [linear model](src/main/java/com/kasisto/iapi/webhook/core/workflow/linearworkflow) a default workflow is defined that automatically generates the transitions through the workflow in a linear step-by-step fashion based on the provided input parameters.  

To implement a new concrete implementation of the linear model, you have to provide an IntentHelper class that provides the list of parameters, methods of parameter validation and methods for processing the completed form.  See the [BankFormHelper](src/main/java/com/kasisto/iapi/webhook/apps/bankform/BankFormHelper.java) example which solicits a series of inputs in a fixed sequence. 

Below represents the workflow for the linear model:
(screenshot)
![alt text](./docs/generic_linear.png)


## Dynamic FAQ Model

To support basic ‘dynamic-faq’ use cases, you can configure new use cases entirely via aconfiguration.  These cases are types of intents where there are parameterized FAQ responses.   For example, if someone wants to open an account there may be 5 different answers based on the account-type: savings, checking, credit-card,etc.  In the case where the user provides the parameter in the question it will provide the corresponding answer.  Otherwise, it will provide a series of quick-reply options, and then the answer based on the selected button. 


The flow looks like this:
 
 ![alt text](./docs/dyn_faq_flow.png)

By populating a resource configuration file like this, and update the AbstractProcessorFactory, you can create new intents very quickly. 

```
productelligibility.prompt=Which product are you interested in?
productelligibility.prompt.quick_replies.text.0=Current Account|current account
productelligibility.prompt.quick_replies.text.1=Savings Account|savings account
productelligibility.disambig.current_account.prompt=The requirements for a current account is $5000
productelligibility.disambig.savings_account.prompt=The requirements for a savings account is $6000
```

Note, to define answers/prompts in rich-media or via the CMS tooling, you can simply use the ref-id convention, such as, where ctaId=30 is the id in the CMS system. 
productelligibility.prompt={ctaId=30}


## How to developer a new application

1. Create a new intent definition in ./intent_definitions (e.g [guai definition](../intent_definitions/java/guai.definition.json) ) including trigger sentences, slots, messages and other configuration
2. Create a package at the [com.kasisto.iapi.webhook.apps.appname](./src/main/java/com/kasisto/iapi/webhook/apps) level
3. Determine if your application can be built via extending the Linear Model.  If so, extent the IntentHelper class and follow the BankForm example, implementing the appropriate methods. 
3. If the linear model is not sufficient, extend the [AbstractIntentProcessor](src/main/java/com/kasisto/iapi/webhook/core/AbstractIntentProcessor.java), and [Workflow](src/main/java/com/kasisto/iapi/webhook/core/workflow/Workflow.java) classes with implementations within your app subpackage.
4. Update the [IntentProcessorFactory](src/main/java/com/kasisto/iapi/webhook/core/IntentProcessorFactory.java) to return the appropriate Processor for the intent-name from the intent-definitions
4. Write [unit tests](./src/test/java/com/kasisto/iapi/webhook)
5. Validate the end-to-end integration with the Kai-application as described in the [integration-testing instructions](../README.md#integration-testing)

For complex custom workflows, it make make sense to design up front the workflow in advance of coding using a charting tool like [LucidCharts](https://www.lucidchart.com).  Identify the key input parameters, you want to collect, the states of your workflow, the transitions between them and the corresponding action that should result. 

Note, that a Condition is expected to return a boolean result on the basis of the information contained in the WorkflowEvent state. The WorkflowEvent contains the input parameters from current and previous utterances.   If conditions have to be satisfied based on backend-criteria (account.balance > x or creditcard.expired=false, etc), it is best practice to extend the WFEvent with additional payload and allow the AbstractProcessor to populate that additional information into the WFEvent prior to asking the workflow instance to determine the correct transition.  


##  Unit Testing

While integration-tests frameworks are [provided](https://github.com/kasisto/iapiservice/#integration-testing-frameworks), junit tests are the best way to efficiently test the behavior on a granular scale of individual classes.  These unit tests should not have external dependencies on other services (e.g kai or eapi) and should use mocking where necessary. These tests are intended to be executed as part of quality-gates for PRs so should continue to run efficiently by developer prior to commit.  

To execute type 'mvn test'

There are three recommended patterns for unit-testing your intent. 

1. For isolated behavior, write unit tests over that behavior at the smallest unit possible (class or function level)
2. To test workflow behavior in isolation, create a workflow in the testsetup, and write tests that verify given a particular input-states and workflow event, you get the follow transition (action, end-state). See: [InsightsWorkflowTest](./src/test/java/com/kasisto/iapi/webhook/insights/InsightsWorkflowTest.java)
3. To test the end-to-end workflow including request-input processing, session-handling, workflow and response generation right tests over the WebhookService for a particular intent. See: [WebookServiceInsightsTest.java](./src/test/java/com/kasisto/iapi/webhook/api/WebhookServiceInsightsTest.java#L108) This will provide the most natural testing scheme of the IAPI methods, but will ignore http-level considerations. 
3. When possible you should aim to test at the individual processor implementation level to isolate validation and the smaller units of the workflow, such as account-aggregation. 

Example Unit test over only Workflow:

```Java
     WFEvent aEvent = new WFEvent(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"));

        WFTransition aTransition = workflow.getTransition(InsightsWorkflow.States.START, aEvent);
        assertEquals(aTransition.getEnd(), InsightsWorkflow.States.CATEGORY);

        WFEvent bEvent = new WFEvent(new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "madeupcategory"));
        bEvent.addToPreviousUserInput(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"));

        //test that sent back to the category state
        WFTransition bTransition = workflow.getTransition(InsightsWorkflow.States.CATEGORY, bEvent);
        assertEquals(bTransition.getEnd(), InsightsWorkflow.States.CATEGORY);
```

Example Unit test over Webhook that tests from StartConversationRequest through to ConversationResponse:
```Java

        //set a budget
        StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME,
                new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET));
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
        String convoid = response.conversation_id;
        assertEquals(response.message_contents.get(0).payload.toString(), "What is the category for the budget");

        //food
        SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "madeupcategory"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);
        assertEquals(response.message_contents.get(0).payload.toString(), "Not a valid category. What is the category for the budget");

```


Note none of the unit tests should rely on starting the application server or external dependencies such as EAPI. They should run efficiently and in isolation.  

Note, NLU concerns are obviously not captured in these unit tests as they do test over the Kai-functionality or the NLU model.  To test that functionality see the bobscript and test_forms testing processes below.  However, a developer should aim to do the majority of their testing at the unit testing level and not rely on the integration testing to validate IAPI service level functionality.



## EAPI Integration

Some IAPI webhooks will require access to backend accounts/transaction data via the [EAPI](https://github.com/kasisto/kasisto-server-api).  A version of the EAPI [client](src/main/java/com/kasisto/iapi/webhook/core/eapi/SimplifiedEnterpriseApiClient.java) has provided in this project.  In the future this client will be generated as a library to ensure consistency with the EAPI specification. 

By convention backend-integrations should be performed within the subclass of the IntentProcessor code, not in the workflow logic itself.   By implementing _updatePreconditions_ and _updatePostConditions_ you can populate into the session object _SystemEvents_ that can be reasoned about in the workflow logic.   Additionally, EAPI integration can happen in the generateResponseForAction() method to retrieve transaction/account to populate into the ConversationResponse.

## Constructing Responses

There are Java POJOs for the MessageContent and RequestUserObject.  If one is building dynamic message-content that is driven by backend data (cards, balances, etc), it is best to build 'CTA' construction methods/classes that can transform the objects from the backend-domain to the rendered objects, like is used in [InsightsCtaGenerator](src/main/java/com/kasisto/iapi/webhook/apps/insights/InsightsCtaGenerator.java).   

For pure static CTA-responses, one can use a ${ctaid} variable in your response (TODO: example, and link to IAPI documentation). 

It may be desirable to use a blended-approach where a static-json response, where static-json is defined within the DGC project and variable-interpolation is used to populate the specific user-input parameter variables.  This may be easier to maintain/read by non-developers and less-verbose. [TODO: working on the appropriate templating language. Jackson+ custom code is probably sufficient for variable interpolation, but if we want loop/condition control then may need to use something like FreeMarker or ThymeLeaf, though neither is particularly well-suited for Json-templating]

# How to test your bot locally

Bring up stable kai-container from base <iapiservice> directory

```
docker-compose up kai
```

Upload the intent-definitions to the target kai environment once the kai service has started. 

```
export IAPI_PORT=8290
export IAPI_HOSTNAME=host.docker.internal (or use ngrok)
sh scripts/upload_defs.sh 
```

Start the java service from <iapiservice>/java directory. 

```
mvn jetty:run
```

To run the Botium CLI/Tests.  From <iapiservice>/test/testcases/botium,  run Testproxy and then either the CLI tool or Botium test-runner after specifying botium testfile directory

```
npm run testproxy
then either:
npm run emulator
(or)
export BOTIUM_CONVO_PATH=<path-to-testfiles>(e.g.<iapiservice>/test/testcases/botium/spec/convo)
npm run testdev
```

Update you appropriate skills.js source and restart via 'npm start' to pick up your changes, using the emulator or json tool to verify changes.

To run the Functional test-cases. Update IAPI_TYPE=node in docker-compose.yml From <iapiservice> directory:

```
docker-compose up functional_testrunner
```


## Internationalization

In order to support internationalization, natural language messages can be stored in java resource objects per locale.  For an example, see [English](./src/main/resources/BankApplication_form_en_US.properties) and [French](./src/main/resources/BankApplication_form_fr_CA.properties) resource files for the bank application example. Note, by convention, parameter substitutions can be included in the prompts by using ${X} [notation](./src/main/resources/CardBlock.properties). It is up to the webhook implementation to apply the variable substitution, using the genText() method of AbstractProcessor. 

Resources should be loaded in the Processor class following a convention that ties the resource to a specific iapi-intent: ResourceBundle promptResource = ResourceBundle.getBundle(intentname);

By convention, you should avoid creating separate code (processor, workflows, etc) for localized versions of the same intent, rather parameterize with the locale object to load the corresponding resources. 

## Versioning

An IAPI webhook intent can optionally specify the minimum api version that it will accept requests from.  If the api_version field of the start_conversation [request](https://docs.kasisto.com/iapi#start-conversation-request) has a value less than the minimalApiVersion field of [IntentProcessor](src/main/java/com/kasisto/iapi/webhook/core/AbstractIntentProcessor.java), then the webhook will return a 403 error.  This can be used to indicate an webhook uses a new feature that is not supported by earlier versions of the API.  

## SSL Support

Within the existing Docker deployment model, you can deploy webhooks that are secured with HTTPS by using a modified version of the Dockerfile that will install nginx and proxy requests to the underlying jetty service.  Alternatively, you can configure direct Jetty-support for SSL by install the certificates with the keytool. 


##  Miscelleanous 

1. Baloam is included in this projects as a libs jar.  Because we don't have a nexus maven repo, you have to install the balaom dependency by executing this command to get it into your local repo:
``` 
mvn install:install-file -Dfile=./libs/balaom.jar -DgroupId=com.kasisto  -DartifactId=balaom -Dversion=1.0 -Dpackaging=jar  -DlocalRepositoryPath=/root/.m2/repository/
```
2. The enterprise adapter code for EnterpriseApiClient and ApiClient are replicated in this repo as there is not a simple Enterprise Adapter client project that does not have deep dependencies into VPA.  Ideally, the enterprise client can be cleaned up and added as a maven dependency to make it available to this (and other) projects. 
3. Make the test-runner (bobscript and test-forms) test runners available cleanly outside of the kai project for developer use and easy integration into build integration processes. Either by updating the d4d configuration, or by making the source binaries for the test 'runners' exportable into this project via a MVN/Nexus repo.
4. Clearer separation for input validation
5. Incorporation of NLG templating, including json-based templates with variable-interpolation or basic condition/loop control.
