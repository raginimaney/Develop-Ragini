package com.kasisto.iapi.webhook.apps;

import org.glassfish.jersey.server.ResourceConfig;

public class MyApplication extends ResourceConfig {

    public MyApplication() {
        register(new MyApplicationBinder());
        packages(true, "com.kasisto.iapi.webhook");
    }
}

