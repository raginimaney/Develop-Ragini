package com.kasisto.iapi.webhook.apps;

import com.kasisto.iapi.webhook.core.workflow.AbstractIntentProcessorFactory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;

public class MyApplicationBinder extends AbstractBinder {

    @Override
    protected void configure() {
        bind(MyApplicationIntentProcessorFactory.class).to(AbstractIntentProcessorFactory.class);
    }

}

