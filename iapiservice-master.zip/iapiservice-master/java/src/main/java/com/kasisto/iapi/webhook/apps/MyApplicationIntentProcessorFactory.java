package com.kasisto.iapi.webhook.apps;

import com.kasisto.iapi.webhook.apps.bankform.BankFormHelper;
import com.kasisto.iapi.webhook.apps.baseline.BaselineHelper;
import com.kasisto.iapi.webhook.apps.baseline.BaselineOptionsHelper;
import com.kasisto.iapi.webhook.apps.baseline.BaselineWithCustomPromptsHelper;
import com.kasisto.iapi.webhook.apps.bb.cashposition.CashPositionIntentProcessor;
import com.kasisto.iapi.webhook.apps.bb.cashposition.CashPositionWorkflow;
import com.kasisto.iapi.webhook.apps.bb.transactioninquiry.TransactionInquiryIntentProcessor;
import com.kasisto.iapi.webhook.apps.bb.transactioninquiry.TransactionInquiryWorkflow;
import com.kasisto.iapi.webhook.apps.cardrenew.CardRenewIntentProcessor;
import com.kasisto.iapi.webhook.apps.cardrenew.CardRenewWorkflow;
import com.kasisto.iapi.webhook.apps.cards.CardActivateProcessor;
import com.kasisto.iapi.webhook.apps.cards.CardActivateWorkflow;
import com.kasisto.iapi.webhook.apps.cards.CardBlockProcessor;
import com.kasisto.iapi.webhook.apps.cards.CardBlockWorkflow;
import com.kasisto.iapi.webhook.apps.baseline.BaselineDynFaqHelper;
import com.kasisto.iapi.webhook.apps.greetings.GreetingsIntentProcessor;
import com.kasisto.iapi.webhook.apps.guai.GUAIIntentProcessor;
import com.kasisto.iapi.webhook.apps.guai.GUAIWorkflow;
import com.kasisto.iapi.webhook.apps.help.HelpIntentProcessor;
import com.kasisto.iapi.webhook.apps.insights.InsightsBudgetIntentProcessor;
import com.kasisto.iapi.webhook.apps.insights.InsightsWorkflow;
import com.kasisto.iapi.webhook.apps.payment.*;
import com.kasisto.iapi.webhook.apps.product.ProductDynFaqHelper;
import com.kasisto.iapi.webhook.apps.survey.SurveyHelper;
import com.kasisto.iapi.webhook.apps.thankyou.ThankYouIntentProcessor;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApiClient;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.workflow.AbstractIntentProcessorFactory;
import com.kasisto.iapi.webhook.core.workflow.SingleStepWorkflow;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.DynFaqGenericHelper;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.GenericDynFaqProcesssor;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.GenericDynFaqWorkflow;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericLinearWorkflow;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcesssor;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


/**
 * Factory class used to create a intent controller to process the user inputs.
 *
 * @author olivier
 */


public class MyApplicationIntentProcessorFactory implements AbstractIntentProcessorFactory {

    private SimplifiedEnterpriseApi eapiClient;

    //private static String EAPI_URL = "http://kai-en-us-mock-enterprise-api-service-qa.kitsys.net/api";

    public MyApplicationIntentProcessorFactory() {

        IapiEnvConf conf = IapiEnvConf.getInstance();
        String eapiURL = conf.getProperties().get(IapiEnvConf.EAPI_URL_PROPERTY_NAME) != null ? conf.getProperties().getProperty(IapiEnvConf.EAPI_URL_PROPERTY_NAME) : IapiEnvConf.EAPI_URL_PROPERTY_DEFAULT;
        setSimplifiedEnterpiseApi(SimplifiedEnterpriseApiClient.getInstance(eapiURL));
    }


    public String[] getAllIntentNames() {
        return new String[]{
                CardRenewIntentProcessor.CARD_RENEW_INTENT_NAME,
                InsightsBudgetIntentProcessor.IB_INTENT_NAME,
                BaselineHelper.BASELINE_INTENT_NAME,
                BaselineWithCustomPromptsHelper.BASELINE_INTENT_CUSTOM_PROMPTS_NAME,
                BaselineOptionsHelper.BASELINE_OPTIONS_INTENT_NAME,
                BankFormHelper.BANK_FORM_INTENT_NAME,
                BankFormHelper.BANK_FORM_INTENT_NAME_CA_FR,
                GUAIIntentProcessor.GUAI_INTENT_NAME,
                TransactionInquiryIntentProcessor.TX_INQUIRY_INTENT_NAME,
                CashPositionIntentProcessor.CP_INTENT_NAME,
                PaymentExecutionIntentProcessor.PAYMENT_EXEC_INTENT_NAME,
                PaymentBeneficiaryIntentProcessor.PAYMENT_BEN_INTENT_NAME,
                PaymentFeesIntentProcessor.PAYMENT_FEES_INTENT_NAME,
                PaymentProcessingTimeIntentProcessor.PAYMENT_PROCESSING_TIME_INTENT_NAME,
                PaymentCancelIntentProcessor.PAYMENT_CANCEL_INTENT_NAME,
                ThankYouIntentProcessor.THANKYOU_INTENT_NAME,
                GreetingsIntentProcessor.GREETINGS_INTENT_NAME,
                SurveyHelper.SURVEY_INTENT_NAME,
                PaymentExecutionIntentProcessor.PAYMENT_EXEC_INTENT_NAME,
                CardBlockProcessor.CARD_UNBLOCK_INTENT_NAME,
                CardBlockProcessor.CARD_BLOCK_INTENT_NAME,
                CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME


        };
    }

    public void setSimplifiedEnterpiseApi(SimplifiedEnterpriseApi eapiClient) {
        this.eapiClient = eapiClient;
    }


    /**
     * Create the Controller bean to be used for the procession of the user input.
     * The bean is for one time user only.
     *
     * @return
     * @throws ApiException
     */

    private Map<String, AbstractIntentProcessor> processorMap = new HashMap<>();


    @Override
    public AbstractIntentProcessor get(String intentName) throws ApiException {
        if (!processorMap.containsKey(intentName)) {
            AbstractIntentProcessor processor = build(intentName);
            processorMap.put(intentName, processor);
        }

        return processorMap.get(intentName);

    }

    private AbstractIntentProcessor build(String intentName) throws ApiException {
        switch (intentName) {

            case CardRenewIntentProcessor.CARD_RENEW_INTENT_NAME:
                CardRenewIntentProcessor cardProcessor = new CardRenewIntentProcessor();
                cardProcessor.setWorkflow(new CardRenewWorkflow());
                return cardProcessor;
            case InsightsBudgetIntentProcessor.IB_INTENT_NAME:
                InsightsBudgetIntentProcessor budgetProcessor = new InsightsBudgetIntentProcessor();
                budgetProcessor.setWorkflow(new InsightsWorkflow());
                return budgetProcessor;
            case BankFormHelper.BANK_FORM_INTENT_NAME:
                GenericProcesssor genericProcesssor = new GenericProcesssor(new BankFormHelper());
                genericProcesssor.setWorkflow(new GenericLinearWorkflow(new BankFormHelper()));
                return genericProcesssor;
            case BankFormHelper.BANK_FORM_INTENT_NAME_CA_FR:
                BankFormHelper helper = new BankFormHelper();
                helper.setLocale(Locale.CANADA_FRENCH);
                GenericProcesssor bankFormProcessorCaFr = new GenericProcesssor(helper);
                bankFormProcessorCaFr.setWorkflow(new GenericLinearWorkflow(helper));
                return bankFormProcessorCaFr;
            case BaselineHelper.BASELINE_INTENT_NAME:
                GenericProcesssor genericProcesssor2 = new GenericProcesssor(new BaselineHelper());
                genericProcesssor2.setWorkflow(new GenericLinearWorkflow(new BaselineHelper()));
                return genericProcesssor2;
            case BaselineOptionsHelper.BASELINE_OPTIONS_INTENT_NAME:
                GenericProcesssor genericProcesssor3 = new GenericProcesssor(new BaselineOptionsHelper());
                genericProcesssor3.setWorkflow(new GenericLinearWorkflow(new BaselineOptionsHelper()));
                return genericProcesssor3;
            case SurveyHelper.SURVEY_INTENT_NAME:
                GenericProcesssor genericProcesssorSurvey = new GenericProcesssor(new SurveyHelper());
                genericProcesssorSurvey.setWorkflow(new GenericLinearWorkflow(new SurveyHelper()));
                return genericProcesssorSurvey;
            case BaselineWithCustomPromptsHelper.BASELINE_INTENT_CUSTOM_PROMPTS_NAME:
                GenericProcesssor genericProcesssor4 = new GenericProcesssor(new BaselineWithCustomPromptsHelper());
                genericProcesssor4.setWorkflow(new GenericLinearWorkflow(new BaselineWithCustomPromptsHelper()));
                return genericProcesssor4;
            case GUAIIntentProcessor.GUAI_INTENT_NAME:
                GUAIIntentProcessor insightsProcessor = new GUAIIntentProcessor();
                insightsProcessor.setWorkflow(new GUAIWorkflow());
                insightsProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                return insightsProcessor;
            case TransactionInquiryIntentProcessor.TX_INQUIRY_INTENT_NAME:
                TransactionInquiryIntentProcessor txProcessor = new TransactionInquiryIntentProcessor();
                txProcessor.setWorkflow(new TransactionInquiryWorkflow());
                txProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                return txProcessor;
            case PaymentExecutionIntentProcessor.PAYMENT_EXEC_INTENT_NAME:
                PaymentExecutionIntentProcessor peProcessor = new PaymentExecutionIntentProcessor();
                peProcessor.setWorkflow(new PaymentExecutionWorkflow());
                return peProcessor;
            case PaymentCancelIntentProcessor.PAYMENT_CANCEL_INTENT_NAME:
                PaymentCancelIntentProcessor pcProcessor = new PaymentCancelIntentProcessor();
                pcProcessor.setWorkflow(new PaymentExecutionWorkflow());
                return pcProcessor;
            case PaymentBeneficiaryIntentProcessor.PAYMENT_BEN_INTENT_NAME:
                PaymentBeneficiaryIntentProcessor pbProcessor = new PaymentBeneficiaryIntentProcessor();
                pbProcessor.setWorkflow(new PaymentBenficiaryWorkflow());
                return pbProcessor;
            case PaymentFeesIntentProcessor.PAYMENT_FEES_INTENT_NAME:
                PaymentFeesIntentProcessor pfProcessor = new PaymentFeesIntentProcessor();
                pfProcessor.setWorkflow(new PaymentFeesWorkflow());
                return pfProcessor;
            case PaymentProcessingTimeIntentProcessor.PAYMENT_PROCESSING_TIME_INTENT_NAME:
                PaymentProcessingTimeIntentProcessor ppProcessor = new PaymentProcessingTimeIntentProcessor();
                ppProcessor.setWorkflow(new PaymentProcessingTimeWorkflow());
                return ppProcessor;
            case CashPositionIntentProcessor.CP_INTENT_NAME:
                CashPositionIntentProcessor cashPositionIntentProcessor = new CashPositionIntentProcessor();
                cashPositionIntentProcessor.setWorkflow(new CashPositionWorkflow());
                cashPositionIntentProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                return cashPositionIntentProcessor;
            case ThankYouIntentProcessor.THANKYOU_INTENT_NAME:
                ThankYouIntentProcessor thankYouIntentProcessor = new ThankYouIntentProcessor();
                thankYouIntentProcessor.setWorkflow(new SingleStepWorkflow());
                return thankYouIntentProcessor;
            case GreetingsIntentProcessor.GREETINGS_INTENT_NAME:
                GreetingsIntentProcessor greetingsIntentProcessor = new GreetingsIntentProcessor();
                greetingsIntentProcessor.setWorkflow(new SingleStepWorkflow());
                greetingsIntentProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                return greetingsIntentProcessor;
            case HelpIntentProcessor.HELP_INTENT_NAME:
                HelpIntentProcessor helpIntentProcessor = new HelpIntentProcessor();
                helpIntentProcessor.setWorkflow(new SingleStepWorkflow());
                return helpIntentProcessor;
            case CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME:
                CardActivateProcessor cardActivateProcessor = new CardActivateProcessor();
                cardActivateProcessor.setWorkflow(new CardActivateWorkflow());
                cardActivateProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                return cardActivateProcessor;
            case CardBlockProcessor.CARD_BLOCK_INTENT_NAME:
                CardBlockProcessor cardBlockProcessor = new CardBlockProcessor(true);
                cardBlockProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                cardBlockProcessor.setWorkflow(new CardBlockWorkflow());
                return cardBlockProcessor;
            case CardBlockProcessor.CARD_UNBLOCK_INTENT_NAME:
                CardBlockProcessor cardUnBlockProcessor = new CardBlockProcessor(false);
                cardUnBlockProcessor.setSimplifiedEnterpriseApiClient(eapiClient);
                cardUnBlockProcessor.setWorkflow(new CardBlockWorkflow());
                return cardUnBlockProcessor;


        }


        //Specific App FAQ handler - Payments
        if (intentName.toLowerCase().startsWith(ProductDynFaqHelper.DYNFAQ_PREFIX.toLowerCase())) {
            //Process this intent as a Specific Dynamic FAQ
            GenericDynFaqProcesssor faqProcesssor = new GenericDynFaqProcesssor(new DynFaqGenericHelper(ProductDynFaqHelper.DYNFAQ_PREFIX));
            faqProcesssor.setWorkflow(new GenericDynFaqWorkflow());
            return faqProcesssor;

        }
        //Specific App FAQ handler - Baseline
        if (intentName.toLowerCase().startsWith(BaselineDynFaqHelper.DYNFAQ_PREFIX.toLowerCase())) {
            //Process this intent as a Specific Dynamic FAQ
            GenericDynFaqProcesssor faqProcesssor = new GenericDynFaqProcesssor(new DynFaqGenericHelper(BaselineDynFaqHelper.DYNFAQ_PREFIX));
            faqProcesssor.setWorkflow(new GenericDynFaqWorkflow());
            return faqProcesssor;

        }

        //Default (Generic) FAQ handler  (DYNFAQ.properties)
        if (intentName.toLowerCase().startsWith(GenericDynFaqProcesssor.DYNFAQ_PREFIX.toLowerCase())) {
            //Process this intent as a Generic Dynamic FAQ
            GenericDynFaqProcesssor faqProcesssor = new GenericDynFaqProcesssor(new DynFaqGenericHelper(GenericDynFaqProcesssor.DYNFAQ_PREFIX));
            faqProcesssor.setWorkflow(new GenericDynFaqWorkflow());
            return faqProcesssor;

        }

        throw new ApiException(ApiException.SERVER_ERROR, "No such intent exists");
    }
}
