package com.kasisto.iapi.webhook.apps.bankform;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.*;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;


/**
 *
 */
public class BankFormHelper implements GenericProcessorHelper {


    private Log log = LogFactory.getLog(getClass());

    public static final String BANK_FORM_INTENT_NAME = "BankApplication_form";
    public static final String BANK_FORM_INTENT_NAME_CA_FR = "BankApplication_form_ca_fr";

    public static final List<RequestUserInput> userInputs;


    public static final String PARAM_FIRSTNAME = "firstname";
    public static final String PARAM_OVER18 = "over18";
    public static final String PARAM_ACCOUNTNUM = "accountnumber";


    private ResourceBundle promptResource = ResourceBundle.getBundle(BANK_FORM_INTENT_NAME, Locale.US);

    public void setLocale(Locale locale) {
        promptResource = ResourceBundle.getBundle(BANK_FORM_INTENT_NAME, locale);
    }


    static {
        //the parameters to collect in what order
        userInputs = new ArrayList<>();
        userInputs.add(new RequestUserInput(PARAM_FIRSTNAME, RequestUserInput.UserInputType.STRING));
        userInputs.add(new RequestUserInput(PARAM_OVER18, RequestUserInput.UserInputType.BOOLEAN));
        userInputs.add(new RequestUserInput(PARAM_ACCOUNTNUM, RequestUserInput.UserInputType.NUMBER));

    }


    @Override
    public List<RequestUserInput> getInputParams() {
        return userInputs;
    }

    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {
        log.info("submitting form result..." + accumulatedInputs.toString());
    }

    @Override
    public boolean isValid(String paramName, String paramValue) {
        if (paramName.equals(PARAM_FIRSTNAME) && paramValue.length() < 3) {
            return false;
        } else {
            return !paramName.equals(PARAM_ACCOUNTNUM) || !(Double.parseDouble(paramValue) < 100);
        }

    }

    @Override
    public MessageContent getPromptForInput(RequestUserInput paramName) {


        if(paramName.name.equals(PARAM_OVER18)){

            MessageContentCard.Button[] buttons = new MessageContentCard.Button[2];
            buttons[0] = new MessageContentCard.Button("Bank Age Restrictions FAQ", MessageContentCard.Button.ButtonType.HYPERLINK.name(),"http://www.bankagerules.com");
            buttons[1] = new MessageContentCard.Button("Call The Bank",MessageContentCard.Button.ButtonType.CALL.name(),"910-981-1212");

            MessageContent mc = new  MessageContentCard(promptResource.getString("PROMPT_" + paramName.name), "",Arrays.asList(buttons)) ;
            return mc;



        }else {

            return new MessageContentText(promptResource.getString("PROMPT_" + paramName.name));
        }
    }

    @Override
    public MessageContent getRetryPromptForInput(RequestUserInput paramName) {
        return null;
    }

    @Override
    public MessageContent getEndPrompt() {
        return new MessageContentText(promptResource.getString("PROMPT_DONE"));
    }

}
