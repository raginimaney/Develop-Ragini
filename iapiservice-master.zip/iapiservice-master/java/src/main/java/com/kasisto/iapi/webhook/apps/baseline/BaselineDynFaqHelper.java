package com.kasisto.iapi.webhook.apps.baseline;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.DynFaqGenericHelper;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.GenericDynFaqProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;


/**
 *
 */
public class BaselineDynFaqHelper extends DynFaqGenericHelper implements GenericDynFaqProcessorHelper {

    private Log log = LogFactory.getLog(getClass());
    public static String DYNFAQ_PREFIX = "BaselineDynFaq";

    public BaselineDynFaqHelper(String dynFaqPrefix) {
        super(dynFaqPrefix);
    }

    @Override
    public String getDisambigPromptForIntent(String intentName) {
        return super.getDisambigPromptForIntent(intentName);
    }

    @Override
    public List<RequestUserInput.QuickReplyOption> getDisambigQuickRepliesTextForIntent(String intentName){
        return super.getDisambigQuickRepliesTextForIntent(intentName);
    }

    @Override
    public String getFinalPromptForIntent(String intentName, String resourceKeyBase) {
        return super.getFinalPromptForIntent(intentName, resourceKeyBase);
    }
}
