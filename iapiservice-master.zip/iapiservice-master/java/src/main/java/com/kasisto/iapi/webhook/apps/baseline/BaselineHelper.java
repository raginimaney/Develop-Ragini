package com.kasisto.iapi.webhook.apps.baseline;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


/**
 *
 */
public class BaselineHelper implements GenericProcessorHelper {


    private Log log = LogFactory.getLog(getClass());

    public static final String BASELINE_INTENT_NAME = "BaselineIntent_form";

    public static final List<RequestUserInput> userInputs;

    // Basic parameter types
    public static final String PARAM_BOOL = "boolean_param";
    public static final String PARAM_NUM = "number_param";
    public static final String PARAM_DATETIME = "datetime_param";
    public static final String PARAM_PATTERN = "pattern_param";
    public static final String PARAM_CURRENCY = "currency_param";
    public static final String PARAM_EMAIL = "email_param";
    public static final String PARAM_STRING = "string_param";
    public static final String PARAM_OPTION = "option_param";

    // Basic normalizer types
    public static final String NORM_DATE = "norm_date_param";


    static {
        //the parameters to collect in what order
        userInputs = new ArrayList<>();
        userInputs.add(new RequestUserInput(PARAM_BOOL, RequestUserInput.UserInputType.BOOLEAN));
        userInputs.add(new RequestUserInput(PARAM_NUM, RequestUserInput.UserInputType.NUMBER));
        userInputs.add(new RequestUserInput(PARAM_DATETIME, RequestUserInput.UserInputType.DATE));
        userInputs.add(new RequestUserInput(PARAM_PATTERN, RequestUserInput.UserInputType.PATTERN, "\\d\\d\\d-\\d\\d\\d"));
        userInputs.add(new RequestUserInput(PARAM_CURRENCY, RequestUserInput.UserInputType.CURRENCY_AMOUNT));
        userInputs.add(new RequestUserInput(PARAM_EMAIL, RequestUserInput.UserInputType.EMAIL));
        userInputs.add(new RequestUserInput(PARAM_STRING, RequestUserInput.UserInputType.STRING));

        RequestUserInput.QuickReplyOption[] qr = new RequestUserInput.QuickReplyOption[]{
                new RequestUserInput.QuickReplyOption("optionone", "optionone"),
                new RequestUserInput.QuickReplyOption("optiontwo", "optiontwo"),
                new RequestUserInput.QuickReplyOption("optionthree", "optionthree", true, Arrays.asList("trois", "tre")),

        };

        List<RequestUserInput.QuickReplyOption> options = Arrays.asList(qr);
        RequestUserInput requestUserInputOption = new RequestUserInput(PARAM_OPTION, RequestUserInput.UserInputType.STRING, options);
        userInputs.add(requestUserInputOption);

        // Normalizers
        userInputs.add(new RequestUserInput(NORM_DATE, RequestUserInput.UserInputType.DATE));


    }


    @Override
    public List<RequestUserInput> getInputParams() {

        return userInputs;
    }

    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {
        log.trace("submitting form result..." + accumulatedInputs.toString());
    }

    @Override
    public boolean isValid(String paramName, String paramValue) {

        return true;

    }

    @Override
    public MessageContent getPromptForInput(RequestUserInput paramName) {
        return new MessageContentText("get a value for " + paramName.name);
    }

    @Override
    public MessageContent getRetryPromptForInput(RequestUserInput paramName) {
        return null;
    }

    @Override
    public MessageContent getEndPrompt() {
        return new MessageContentText("success");
    }


}
