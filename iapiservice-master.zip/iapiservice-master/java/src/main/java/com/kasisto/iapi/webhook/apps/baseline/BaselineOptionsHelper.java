package com.kasisto.iapi.webhook.apps.baseline;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 */
public class BaselineOptionsHelper implements GenericProcessorHelper {

    public static final String BASELINE_OPTIONS_INTENT_NAME = "BaselineOptionType_intent_jk";
    public static final List<RequestUserInput> userInputs;
    private Log log = LogFactory.getLog(getClass());


    // Option types
    public static final String QUICK_REPLY = "quick_replies";


    static {
        userInputs = new ArrayList<>();

        List<RequestUserInput.QuickReplyOption> qrOptions = new ArrayList<RequestUserInput.QuickReplyOption>();
        qrOptions.add(new RequestUserInput.QuickReplyOption("option1", "option1"));
        qrOptions.add(new RequestUserInput.QuickReplyOption("option2", "option2"));
        qrOptions.add(new RequestUserInput.QuickReplyOption("option3", "option3"));


        userInputs.add(new RequestUserInput(QUICK_REPLY, RequestUserInput.UserInputType.STRING, qrOptions));

    }


    @Override
    public List<RequestUserInput> getInputParams() {
        return userInputs;
    }


    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {
        log.info("submitting form result..." + accumulatedInputs.toString());
    }

    @Override
    public boolean isValid(String paramName, String paramValue) {
        return true;
    }

    @Override
    public MessageContent getPromptForInput(RequestUserInput paramName) {
        return null;
    }

    @Override
    public MessageContent getRetryPromptForInput(RequestUserInput paramName) {
        return null;
    }

    @Override
    public MessageContent getEndPrompt() {
        return null;
    }


}
