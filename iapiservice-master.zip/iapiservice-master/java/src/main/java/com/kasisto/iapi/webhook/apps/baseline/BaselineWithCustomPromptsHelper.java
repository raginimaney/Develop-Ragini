package com.kasisto.iapi.webhook.apps.baseline;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.DefaultMessageTemplates;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 *
 */
public class BaselineWithCustomPromptsHelper implements GenericProcessorHelper {

    private Log log = LogFactory.getLog(getClass());

    public static final String BASELINE_INTENT_CUSTOM_PROMPTS_NAME = "BaselineIntentWithCustomPrompts_form";

    public static final List<RequestUserInput> userInputs;
    //public static final List<RequestUserMessage> userMessages;

    // Basic parameter types
    public static final String PARAM_BOOL = "boolean_param";
    public static final String PARAM_NUM = "number_param";
    public static final String PARAM_STRING = "string_param";


    static {
        // Create MessageTemplates
        //MessageTemplate paramBoolMessageTemplate = new MessageTemplate(DefaultMessageTemplates.DEFAULT_CURRENT_TIME);

        // jon fix
        //paramBoolMessageTemplate.concatPromptsTemplates("True or False?");

        //MessageTemplate paramNumMessageTemplate = new MessageTemplate(DefaultMessageTemplates.DEFAULT);
        //MessageTemplate paramNumMessageTemplate = new MessageTemplate(DefaultMessageTemplates.DEFAULT_CURRENT_TIME);
        // jon fix
        //paramNumMessageTemplate.concatPromptsTemplates("A number between 1 and 2^63?");

        //MessageTemplate paramStringMessageTemplate = new MessageTemplate(new ArrayList<String>(
        //       Arrays.asList("${now}. Please tell me your name",  "As yoda would say, . Time to tell me your name")));

        //the parameters to collect in what order
        userInputs = new ArrayList<>();
        userInputs.add(new RequestUserInput(PARAM_BOOL, RequestUserInput.UserInputType.BOOLEAN));
        userInputs.add(new RequestUserInput(PARAM_NUM, RequestUserInput.UserInputType.NUMBER));
        userInputs.add(new RequestUserInput(PARAM_STRING, RequestUserInput.UserInputType.STRING));

    }

    @Override
    public List<RequestUserInput> getInputParams() {
        return userInputs;
    }

    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {
        log.info("submitting form result..." + accumulatedInputs.toString());
    }


    @Override
    public boolean isValid(String paramName, String paramValue) {
        return true;
    }

    @Override
    public MessageContent getPromptForInput(RequestUserInput paramName) {

        if (paramName.name.equals(PARAM_BOOL)) {
            return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT_CURRENT_TIME) + " True or False?");
        } else if (paramName.name.equals(PARAM_NUM)) {
            return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT_CURRENT_TIME) + " A number between 1 and 2^63?");
        } else if (paramName.name.equals(PARAM_STRING)) {
            return new MessageContentText("The time it is ${now}. What is the new string");
        }
        return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT));
    }

    @Override
    public MessageContent getRetryPromptForInput(RequestUserInput paramName) {
        return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT_RETRY));
    }

    @Override
    public MessageContent getEndPrompt() {
        return new MessageContentText("**** Done ****");
    }


}
