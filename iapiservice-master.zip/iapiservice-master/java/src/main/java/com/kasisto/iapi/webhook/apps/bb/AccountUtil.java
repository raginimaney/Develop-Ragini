package com.kasisto.iapi.webhook.apps.bb;


import com.kasisto.api.model.Account;
import com.kasisto.model.MetaField;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * Utility classes for doing account-filtering
 * Candidates for being moved into a shared 'bal-like' client with caching and filtering responsbilities.
 */

public class AccountUtil {

    static private Log log = LogFactory.getLog(AccountUtil.class);

    //meta.bank_name
    public static final String BANK_NAME_FIELD = "bank_name";


    public static List<String> getAccountNumbers(List<Account> accounts, String bankname) {


        List<Account> filteredAccounts = accountFilterByAccountType(accounts, Account.AccountTypeEnum.CASH_POSITION, null, null, bankname);

        List<String> accountNums = new ArrayList<>();
        for (Account account : filteredAccounts) {
            accountNums.add(account.getAccountNumber());
        }
        return accountNums;
    }


    //accountType = cash_position_summary
    public static List<Account> accountFilterByAccountType(List<Account> accounts, Account.AccountTypeEnum accountType, String accountNum, String currencyCode, String bankName) {


        log.trace("filtering " + accounts.size() + " accounts: get accounts: accountType=" + accountType + ",accountNum=" + accountNum + ",code=" + currencyCode + "," + bankName);
        List<Account> filteredAccounts = new ArrayList<Account>();

        Stream<Account> accountStream = accounts.stream();

        //if account-type is summary, only show active accounts
        if (accountType != null && accountType.equals(Account.AccountTypeEnum.CASH_POSITION_SUMMARY)) {
            accountStream = accountStream.filter(x -> x.getAccountStatus() != null && x.getAccountStatus().equals(Account.AccountStatusEnum.ACTIVE));
        }

        if (currencyCode != null) {
            accountStream = accountStream.filter(x -> x.getForeignCurrencyCode().equals(currencyCode));
        }
        if (accountType != null) {
            accountStream = accountStream.filter(x -> x.getAccountType().equals(accountType));
        }
        if (accountNum != null) {
            accountStream = accountStream.filter(x -> x.getAccountNumber().endsWith(accountNum));
        }
        if (bankName != null) {
            accountStream = accountStream.filter(x -> metaHasFieldValue(x.getMeta(), BANK_NAME_FIELD, bankName, true));
        }

        filteredAccounts = accountStream.collect(Collectors.toList());

        log.trace("found " + filteredAccounts.size() + " filteredAccounts");

        return filteredAccounts;
    }


    private static boolean metaHasFieldValue(List<MetaField> metaFields, String fieldName, String fieldValue, boolean fuzzy) {

        for (MetaField metaField : metaFields) {

            if (fuzzy) {
                if (metaField.getName().equals(fieldName) && metaField.getValue().toLowerCase().startsWith(fieldValue.toLowerCase())) {
                    return true;
                }
            } else {
                if (metaField.getName().equals(fieldName) && metaField.getValue().equals(fieldValue)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static String getFieldValue(List<MetaField> metaFields, String fieldName) {

        for (MetaField metaField : metaFields) {

            if (metaField.getName().equals(fieldName)) {
                return metaField.getValue();
            }
        }
        return null;
    }


}
