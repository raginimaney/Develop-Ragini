package com.kasisto.iapi.webhook.apps.bb;

import com.kasisto.api.model.AccountsRequest;
import com.kasisto.api.model.Transaction;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.model.MetaField;
import domain.lola.user.bb.MyDateTime;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTimeComparator;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class TransactionUtil {
    static private Log log = LogFactory.getLog(TransactionUtil.class);

    private static final String TX_REF_NUM = "transaction_reference_no";

    // plus/minus percent off to allow match
    public static final float percentOffAmountMatch = 10.0f;

    public static List<Transaction> transactionFilter(List<Transaction> txs, String refNum, String accountId, Date date, Double amount, SimplifiedEnterpriseApi eapiClient) {
        log.info("filtering " + txs.size() + " accounts: get accounts: refNum=" + refNum + ",accountNum=" + accountId + ",date=" + date + ",amount=" + amount);
        log.info(txs);
        List<Transaction> filterTransactions = new ArrayList<Transaction>();

        Stream<Transaction> txStream = txs.stream();


        if (refNum != null) {
            txStream = txStream.filter(x -> metaHasFieldValue(x.getMeta(), TX_REF_NUM, refNum, false));
        }

        if (accountId != null) {
            txStream = txStream.filter(x -> accountsMatch(x.getAccountId(), accountId));
        }

        if (date != null) {
            txStream = txStream.filter(x -> datesMatch(x.getTransactionDate(), date));
        }

        if (amount != null) {
            txStream = txStream.filter(x -> amountMatchesNearby(x.getAmount(), amount, percentOffAmountMatch, percentOffAmountMatch));
        }


        filterTransactions = txStream.collect(Collectors.toList());

        log.info("found " + filterTransactions.size() + " filteredAccounts");

        return filterTransactions;
    }


    private static boolean amountMatches(double amount1, Double amount2) {
      return Math.abs(amount1 - amount2) < 2;
    }

    private static boolean amountMatchesNearby(double amount1, Double amount2, float percentAboveAmount, float percentBelowAmount) {
        final float SENSITIVITY_HIGH = percentAboveAmount / 100;
        final float SENSITIVITY_LOW = percentBelowAmount / 100;
        return (Math.abs(amount2) <= Math.abs(amount1 * (1 + SENSITIVITY_HIGH)) && Math.abs(amount2) >= Math.abs(amount1 * (1 - SENSITIVITY_LOW)));
    }

    private static boolean datesMatch(MyDateTime mdtdate1, Date date2) {
        LocalDateTime ldt = mdtdate1.getDateTime();
        Date date1 = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
        //compare Dates
        int match = DateTimeComparator.getDateOnlyInstance().compare(date1, date2);

        System.out.println("date match:"+mdtdate1+","+date2+"===>"+match);
        return match == 0;
    }


    private static boolean datesMatchNearby(MyDateTime mdtdate1, Date date2, int daysPlusMinus) {
        LocalDateTime ldt = mdtdate1.getDateTime();
        Date date1 = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());

        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        // manipulate date
        cal1.add(Calendar.DAY_OF_MONTH, -1 * daysPlusMinus);
        // convert calendar to date
        Date d1 = cal1.getTime();

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date1);
        // manipulate date
        cal2.add(Calendar.DAY_OF_MONTH, 1 * daysPlusMinus);
        // convert calendar to date
        Date d2 = cal2.getTime();

        //compare date2 - see if its between d1/d2
        return (d1.compareTo(date2) * date2.compareTo(d2) >= 0);
    }


    private static boolean accountsMatch(String accountId1, String accountId2) {
        return accountId1.equals(accountId2);
    }

    private static boolean metaHasFieldValue(List<MetaField> metaFields, String fieldName, String fieldValue, boolean fuzzy) {

        for (MetaField metaField : metaFields) {

            if (fuzzy) {
                if (metaField.getName().equals(fieldName) && metaField.getValue().toLowerCase().startsWith(fieldValue.toLowerCase())) {
                    return true;
                }
            } else {
                if (metaField.getName().equals(fieldName) && metaField.getValue().equals(fieldValue)) {
                    return true;
                }
            }
        }
        return false;
    }

}
