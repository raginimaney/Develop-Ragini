package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.api.model.Account;
import com.kasisto.iapi.webhook.core.TemplateUtil;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.model.MetaField;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class AccountCtaGenerator {


    /**
     * Static Templates that will use variable substitution to populate the final response
     */


    /**
     * All all the metafields to be substituted in the template AND specific top-level fields (e.g. currency)
     *
     * @param template
     * @param account
     * @return
     */
    public static String generateMessage(String template, Account account) {

        Map<String, String> vars = new HashMap<String, String>();

        for (MetaField aField : account.getMeta()) {
            vars.put(aField.getName(), aField.getValue());
        }
        vars.put("fcy_currency_code", account.getForeignCurrencyCode());

        return TemplateUtil.genText(template, vars);

    }


    public static MessageContent getDebitDebitCta(List<Account> accounts, CashPositionIntentProcessor.CP_TYPE accountType, ResourceBundle prompts) {

        String msg;
        if (accountType == CashPositionIntentProcessor.CP_TYPE.debit) {
            msg = generateMessage(prompts.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_DEBIT.name()), accounts.get(0));
        } else {
            msg = generateMessage(prompts.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_CREDIT.name()), accounts.get(0));
        }
        MessageContent mc = new MessageContentText(msg);
        return mc;
    }


    public static MessageContent getAccountsCta(List<Account> accounts,
                                                CashPositionIntentProcessor.CP_PERIOD selectedPeriod,
                                                CashPositionIntentProcessor.CP_CURRENCY selectedCurrency,
                                                ResourceBundle resourceBundle
                ) {


        /*compose a template with an initial top-level message and the specific message based on
        whether it's projected or priorday/currentday
         */

        String msg;

        if (accounts == null || accounts.size() < 1) {
            msg = resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_NO_ACTS.name());
        } else {


            StringBuilder sb = new StringBuilder();

            sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_ACT_SUMMARY.name())+"\n");


            if (selectedPeriod == CashPositionIntentProcessor.CP_PERIOD.projected) {

                sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_PROJECTED.name())+"\n");

            } else {
                if (selectedPeriod == CashPositionIntentProcessor.CP_PERIOD.currentday) {
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_CURRENT_OPENING.name())+"\n");
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_CURRENT_CLOSING.name())+"\n");
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_CURRENT_AVAILABLE.name())+"\n");

                } else {
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_PRIOR_OPENING.name())+"\n");
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_PRIOR_CLOSING.name())+"\n");
                    sb.append(resourceBundle.getString(CashPositionIntentProcessor.PROMPTS.CASHPOSITION_PROMPT_PRIOR_AVAILABLE.name())+"\n");
                }
            }


            //TODO validate if it is possible to have multiple accounts
            msg = generateMessage(sb.toString(), accounts.get(0));
        }

        MessageContent mc = new MessageContentText(msg);

        return mc;
    }


}
