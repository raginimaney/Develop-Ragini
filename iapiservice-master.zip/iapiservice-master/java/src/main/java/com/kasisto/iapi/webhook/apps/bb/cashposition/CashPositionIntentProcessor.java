package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.api.model.Account;
import com.kasisto.api.model.AccountsRequest;
import com.kasisto.iapi.webhook.apps.bb.AccountUtil;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.*;

public class CashPositionIntentProcessor extends AbstractIntentProcessor {

    public static final String CP_INTENT_NAME = "cashposition";


    public static final String FIELD_GUAI_CONSTRAINTS = "guai_constraints";

    public static final String FIELD_PERIOD = "CP_period";
    public static final String FIELD_CURRENCY = "CP_currency";
    public static final String FIELD_TYPE = "CP_type";
    public static final String FIELD_BANKNAME = "CP_bankname";
    public static final String FIELD_ACTNUM = "CP_accountnum";

    //not to be used according to narrative
    public static final String FIELD_REGION = "CP_region";

    private static String defaultEapiToken;

    private String eapiSecret;


    public enum PROMPTS {
        CASHPOSITION_PROMPT_CURRENCY,
        CASHPOSITION_PROMPT_NO_ACTS,
        CASHPOSITION_PROMPT_SELECT_ACT,
        CASHPOSITION_PROMPT_ACT_SUMMARY,
        CASHPOSITION_PROMPT_CREDIT,
        CASHPOSITION_PROMPT_DEBIT,
        CASHPOSITION_PROMPT_PROJECTED,
        CASHPOSITION_PROMPT_CURRENT_OPENING,
        CASHPOSITION_PROMPT_CURRENT_CLOSING,
        CASHPOSITION_PROMPT_CURRENT_AVAILABLE,
        CASHPOSITION_PROMPT_PRIOR_OPENING,
        CASHPOSITION_PROMPT_PRIOR_CLOSING,
        CASHPOSITION_PROMPT_PRIOR_AVAILABLE
    }


    ResourceBundle promptResource = ResourceBundle.getBundle(CP_INTENT_NAME);



    public enum CP_PERIOD {
        currentday("Current"), projected("Projected"), priorday("PriorDay");

        private String label;

        CP_PERIOD(String label) {
            this.label = label;
        }
    }

    //TODO how to maintain consistency between the intent definitions and the code-level enumerations
    public enum CP_CURRENCY {
        USD, EUR, GBP, AUD, NOK
    }

    //not to be used according to narrative

    public enum CP_REGION {US, China, Thailand}

    public enum CP_TYPE {
        credit("Credit"), debit("Debit");

        private String label;

        CP_TYPE(String label) {
            this.label = label;
        }
    }


    public SimplifiedEnterpriseApi eapiClient;


    @Override
    public boolean isLoginRequired() {
        return false;
    }

    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {


        if (token == null) {
            token = defaultEapiToken;
        }

        accumulatedInputs = translateConstraints(accumulatedInputs);


        List<Account> accounts = null;
        AccountsRequest request = new AccountsRequest();


        try {
            accounts = eapiClient.accounts(eapiSecret, token, request, new HashMap<String, String>());

        } catch (ApiException e) {
            e.printStackTrace();
        }

        ConversationResponse cr = new ConversationResponse();
        cr.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        if (action.equals(CashPositionWorkflow.Actions.GET_CURRENCY)) {

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CASHPOSITION_PROMPT_CURRENCY.name())));
            cr.request_user_input = generateCurrencyInput();
        }
        //the core action at 'end of the intent' where
        else if (action.equals(CashPositionWorkflow.Actions.GET_BALANCE)) {


            CP_PERIOD selectedPeriod = CP_PERIOD.currentday;
            if (accumulatedInputs.containsKey(FIELD_PERIOD)) {
                selectedPeriod = CP_PERIOD.valueOf(accumulatedInputs.get(FIELD_PERIOD).value);
            }

            CP_TYPE selectedType = null;
            if (accumulatedInputs.containsKey(FIELD_TYPE)) {
                selectedType = CP_TYPE.valueOf(accumulatedInputs.get(FIELD_TYPE).value);
            }


            if (accumulatedInputs.containsKey(FIELD_CURRENCY)) {

                CP_CURRENCY selectedCurrency = CP_CURRENCY.USD;
                if (accumulatedInputs.containsKey(FIELD_CURRENCY)) {
                    selectedCurrency = CP_CURRENCY.valueOf(accumulatedInputs.get(FIELD_CURRENCY).value);
                }


                //get the actual accounts
                List<Account> filteredAccount = AccountUtil.accountFilterByAccountType(accounts, Account.AccountTypeEnum.CASH_POSITION_SUMMARY, null, selectedCurrency.name(), null);

                if (selectedType != null) {
                    cr.message_contents.add(AccountCtaGenerator.getDebitDebitCta(filteredAccount, selectedType,promptResource));
                } else {
                    cr.message_contents.add(AccountCtaGenerator.getAccountsCta(filteredAccount, selectedPeriod, selectedCurrency,promptResource));
                }
                cr.request_user_input = generateRequestUserInput();

            } else if (accumulatedInputs.containsKey(FIELD_ACTNUM)) {

                String accountNum = accumulatedInputs.get(FIELD_ACTNUM).value;

                //get the actual accounts
                List<Account> filteredAccount = AccountUtil.accountFilterByAccountType(accounts, Account.AccountTypeEnum.CASH_POSITION, accountNum, null, null);
                cr.message_contents.add(AccountCtaGenerator.getAccountsCta(filteredAccount, selectedPeriod, null,promptResource));
                cr.request_user_input = generateRequestUserInput();
            }

            //prompt user to select account-number after use specifies the bank-name
        } else if (action.equals(CashPositionWorkflow.Actions.GET_ACCOUNT_NUM)) {

            String bankName = accumulatedInputs.get(FIELD_BANKNAME).value;
            List<String> accountNums = AccountUtil.getAccountNumbers(accounts, bankName);

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CASHPOSITION_PROMPT_SELECT_ACT.name())));
            cr.request_user_input = generateRequestAccountNumber(accountNums);
        }


        return cr;
    }


    /**
     * Translate from the GUAI_Constraints quick-reply into specific parameters.  If those constraints
     * replace existing ones, remove those constraints.
     *
     * @param inputs
     * @return
     */
    private static Map<String, UserInput> translateConstraints(Map<String, UserInput> inputs) {


        for (String key : inputs.keySet()) {
            if (key.equals(FIELD_GUAI_CONSTRAINTS)) {

                String val = inputs.get(key).value;
                if (val.equals(CP_PERIOD.projected.name())) {
                    inputs.put(FIELD_PERIOD, new UserInput(FIELD_PERIOD, CP_PERIOD.projected.name()));
                } else if (val.equals(CP_PERIOD.currentday.name())) {
                    inputs.put(FIELD_PERIOD, new UserInput(FIELD_PERIOD, CP_PERIOD.currentday.name()));
                } else if (val.equals(CP_PERIOD.priorday.name())) {
                    inputs.put(FIELD_PERIOD, new UserInput(FIELD_PERIOD, CP_PERIOD.priorday.name()));
                } else if (val.equals(CP_TYPE.credit.name())) {
                    inputs.put(FIELD_TYPE, new UserInput(FIELD_TYPE, CP_TYPE.credit.name()));
                } else if (val.equals(CP_TYPE.debit.name())) {
                    inputs.put(FIELD_TYPE, new UserInput(FIELD_TYPE, CP_TYPE.debit.name()));
                }
            }
        }
        return inputs;
    }

    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi client) {

        this.eapiSecret = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_SECRET_PROPERTY_NAME);
        this.eapiClient = client;
        this.defaultEapiToken = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_TOKEN_PROPERTY_NAME);
    }


    public RequestUserInput generateRequestAccountNumber(List<String> accountNums) {

        List<RequestUserInput.QuickReplyOption> options = new ArrayList<>();
        for (String accountNum : accountNums) {
            options.add(new RequestUserInput.QuickReplyOption(accountNum, "account " + accountNum));
        }

        RequestUserInput requestUserInput = new RequestUserInput(FIELD_ACTNUM, RequestUserInput.UserInputType.NUMBER, options);
        return requestUserInput;
    }


    /**
     * Generate the quick reply for all the constraints
     *
     * @return
     */
    public RequestUserInput generateRequestUserInput() {


        RequestUserInput.QuickReplyOption[] qr = new RequestUserInput.QuickReplyOption[]{
                new RequestUserInput.QuickReplyOption("Cancel", "Cancel"),
                new RequestUserInput.QuickReplyOption(CP_PERIOD.priorday.name(), CP_PERIOD.priorday.label),
                new RequestUserInput.QuickReplyOption(CP_PERIOD.currentday.name(), CP_PERIOD.currentday.label),
                new RequestUserInput.QuickReplyOption(CP_PERIOD.projected.name(), CP_PERIOD.projected.label),
                new RequestUserInput.QuickReplyOption(CP_TYPE.credit.name(), CP_TYPE.credit.label),
                new RequestUserInput.QuickReplyOption(CP_TYPE.debit.name(), CP_TYPE.debit.label)

        };


        List<RequestUserInput.QuickReplyOption> options = Arrays.asList(qr);
        RequestUserInput requestUserInput = new RequestUserInput(FIELD_GUAI_CONSTRAINTS, RequestUserInput.UserInputType.STRING, options);
        return requestUserInput;
    }

    public RequestUserInput generateCurrencyInput() {

        List<RequestUserInput.QuickReplyOption> options = new ArrayList<>();
        for (CP_CURRENCY currency : CP_CURRENCY.values()) {
            RequestUserInput.QuickReplyOption qr = new RequestUserInput.QuickReplyOption(currency.name(), currency.name());
            options.add(qr);
        }

        RequestUserInput requestUserInput = new RequestUserInput(FIELD_CURRENCY, RequestUserInput.UserInputType.STRING, options);
        return requestUserInput;
    }


}
