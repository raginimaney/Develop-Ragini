package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFState;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;

import java.util.ArrayList;
import java.util.List;


/**
 * The workflow for CashPosition
 * See ./docs/cashposition.png to see the high-level workflow
 */
public class CashPositionWorkflow extends Workflow {

    enum States implements WFState {
        START, CURRENCY, ACTNUM, BALANCE, END
    }

    enum Actions implements WFAction {
        GET_CURRENCY, GET_BALANCE, GET_ACCOUNT_NUM
    }


    @Override
    public List<WFTransition> generateTransitions() {


        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.GET_CURRENCY, States.START, States.CURRENCY, event -> {

            return !event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_CURRENCY)
                    && !event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_BANKNAME)
                    && !event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_ACTNUM);

        }));


        transitions.add(new WFTransition(Actions.GET_BALANCE, States.START, States.BALANCE, event -> {

            //path 2
            //test if a valid account number
            if (event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_CURRENCY)) {
                String currency = "";

                currency = event.getCurrentUserInputs().get(CashPositionIntentProcessor.FIELD_CURRENCY).value;
                return validCurrency(currency);
            } else {
                return event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_ACTNUM);
            }

        }));

        transitions.add(new WFTransition(Actions.GET_BALANCE, States.CURRENCY, States.BALANCE, event -> {

            String currency = "";
            if (event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_CURRENCY)) {
                currency = event.getCurrentUserInputs().get(CashPositionIntentProcessor.FIELD_CURRENCY).value;
            }

            return validCurrency(currency);

        }));


        transitions.add(new WFTransition(Actions.GET_BALANCE, States.BALANCE, States.BALANCE, event -> {
            return true;

        }));


        transitions.add(new WFTransition(Actions.GET_ACCOUNT_NUM, States.START, States.ACTNUM, event -> {

            //if a bank name and matches user accounts?
            return event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_BANKNAME);

        }));


        transitions.add(new WFTransition(Actions.GET_BALANCE, States.ACTNUM, States.BALANCE, event -> {

            //if a bank name and matches user accounts?
            return event.getCurrentUserInputs().containsKey(CashPositionIntentProcessor.FIELD_ACTNUM);

        }));


        return transitions;
    }


    @Override
    public WFState getOrigin() {
        return States.START;
    }


    //redundant validation with what the NLU side will perform?

    public boolean validCurrency(String currency) {

        try {
            CashPositionIntentProcessor.CP_CURRENCY.valueOf(currency);
            //yes
        } catch (IllegalArgumentException ex) {
            return false;
        }
        return true;
    }
}
