package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.api.model.*;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.OfferRequest;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.model.MetaField;
import domain.lola.user.bb.Offer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Mock for EAPI as used in unit-tests.
 * Has small number of static accounts defined in code.  Use the node-mock for integration-testing.
 */
public class MockBusinessBankEAPI implements SimplifiedEnterpriseApi {

    public static Account ac;
    public static Account ac2;
    public static Account ac3;

    static {

        ac = new Account();
        ac.setAccountType(Account.AccountTypeEnum.CASH_POSITION_SUMMARY);
        ac.setForeignCurrencyCode("NZD");
        ac.setAccountId("eyks3y6vv2fzd6ilnkom49ddgfb6faqhci1puyji17cxfybilgm5r89uvkauhbfl");
        ac.setAccountName("IRIS_CP_ACCT");
        ac.setAccountNickname("IRIS_CP_ACCT");
        ac.accountNumber("79484514");
        ac.setCanTransferFrom(false);
        ac.setCanTransferTo(false);
        ac.setCanPayPayee(false);
        ac.setCurrentBalance(3128d);
        ac.setInterestRate(23.1d);
        ac.setAvailableBalance(2814.89d);
        ac.setAvailableBalance(2147d);
        ac.setAccountStatus(Account.AccountStatusEnum.ACTIVE);
        ac.setForeignCurrencyAvailableBalance(37483075.239999995d);
        ac.setForeignCurrencyCurrentBalance(37483075.239999995d);

        List<MetaField> metaFields = new ArrayList<>();
        metaFields.add(makeMetaField("country_code", "TH"));
        metaFields.add(makeMetaField("country", "THAILAND"));

        metaFields.add(makeMetaField("balances_currentday_asofdate", "2018-02-23"));
        metaFields.add(makeMetaField("balances_currentday_openingledger", "1648"));
        metaFields.add(makeMetaField("balances_currentday_currentorclosingledger", "457"));
        metaFields.add(makeMetaField("balances_currentday_currentorclosingavailable", "2764"));
        metaFields.add(makeMetaField("balances_currentday_totalcreditsamount", "600.62"));
        metaFields.add(makeMetaField("balances_currentday_totalcreditscount", "82081"));
        metaFields.add(makeMetaField("balances_currentday_totaldebitsamount", "452.46"));
        metaFields.add(makeMetaField("balances_currentday_totaldebitscount", "99911"));
        metaFields.add(makeMetaField("balances_currentday_totalday1floatamount", "2492"));
        metaFields.add(makeMetaField("balances_currentday_totalday2plusfloatamount", "461"));
        metaFields.add(makeMetaField("balances_priorday_asofdate", "2018-02-22"));
        metaFields.add(makeMetaField("balances_priorday_openingledger", "4222"));
        metaFields.add(makeMetaField("balances_priorday_currentorclosingledger", "833"));
        metaFields.add(makeMetaField("balances_priorday_currentorclosingavailable", "1818"));
        ac.setMeta(metaFields);

        ac2 = new Account();
        ac2.setAccountType(Account.AccountTypeEnum.CASH_POSITION_SUMMARY);
        ac2.setForeignCurrencyCode("EUR");
        ac2.setAccountId("eyks3y6vv2fzd6ilnkom49ddgfb6hci1puyji17cxfybilgm5r89uvkauhbfl");
        ac2.setAccountName("XRIS_CP_ACCT");
        ac2.setAccountNickname("XRIS_CP_ACCT");
        ac2.accountNumber("38484514");
        ac2.setCanTransferFrom(false);
        ac2.setCanTransferTo(false);
        ac2.setCanPayPayee(false);
        ac2.setCurrentBalance(2128d);
        ac2.setInterestRate(23.1d);
        ac2.setAvailableBalance(1814.89d);
        ac2.setAvailableBalance(3147d);
        ac2.setAccountStatus(Account.AccountStatusEnum.ACTIVE);
        ac2.setForeignCurrencyAvailableBalance(87483075.239999995d);
        ac2.setForeignCurrencyCurrentBalance(87483075.239999995d);

        List<MetaField> metaFields2 = new ArrayList<>();
        metaFields2.add(makeMetaField("country_code", "FR"));
        metaFields2.add(makeMetaField("country", "FRANCE"));

        metaFields2.add(makeMetaField("balances_currentday_asofdate", "2018-02-23"));
        metaFields2.add(makeMetaField("balances_currentday_openingledger", "148"));
        metaFields2.add(makeMetaField("balances_currentday_currentorclosingledger", "2457"));
        metaFields2.add(makeMetaField("balances_currentday_currentorclosingavailable", "2764"));
        metaFields2.add(makeMetaField("balances_currentday_totalcreditsamount", "1200.62"));
        metaFields2.add(makeMetaField("balances_currentday_totalcreditscount", "8081"));
        metaFields2.add(makeMetaField("balances_currentday_totaldebitsamount", "152.46"));
        metaFields2.add(makeMetaField("balances_currentday_totaldebitscount", "89911"));
        metaFields2.add(makeMetaField("balances_currentday_totalday1floatamount", "2492"));
        metaFields2.add(makeMetaField("balances_currentday_totalday2plusfloatamount", "461"));
        metaFields2.add(makeMetaField("balances_priorday_asofdate", "2018-02-22"));
        metaFields2.add(makeMetaField("balances_priorday_openingledger", "122"));
        metaFields2.add(makeMetaField("balances_priorday_currentorclosingledger", "733"));
        metaFields2.add(makeMetaField("balances_priorday_currentorclosingavailable", "2818"));
        ac2.setMeta(metaFields2);


        ac3 = new Account();
        ac3.setAccountType(Account.AccountTypeEnum.CASH_POSITION);
        ac3.setForeignCurrencyCode("NGN");
        ac3.setAccountId("s4ja5u6h1og8qw0y5vkbvzltxn3333oz4gelkhw70kys73cphtrk9idbfmhwfdvb");
        ac3.setAccountName("IRIS_CP_ACCT");
        ac3.setAccountNickname("XRIS_CP_ACCT");
        ac3.accountNumber("37186278");
        ac3.setCanTransferFrom(false);
        ac3.setCanTransferTo(false);
        ac3.setCanPayPayee(false);
        ac3.setCurrentBalance(423d);
        ac3.setInterestRate(7.2d);
        ac3.setAvailableBalance(250.57d);
        ac3.setAvailableBalance(3147d);
        ac3.setAccountStatus(Account.AccountStatusEnum.ACTIVE);
        ac3.setForeignCurrencyAvailableBalance(3336590.12d);
        ac3.setForeignCurrencyCurrentBalance(5632668d);

        List<MetaField> metaFields3 = new ArrayList<>();
        metaFields3.add(makeMetaField("country_code", "NL"));
        metaFields3.add(makeMetaField("country", "NETHERLANDS"));
        metaFields3.add(makeMetaField("bank_name", "JPMorgan"));
        metaFields3.add(makeMetaField("balances_currentday_asofdate", "2018-02-23"));
        metaFields3.add(makeMetaField("balances_currentday_openingledger", "4588"));
        metaFields3.add(makeMetaField("balances_currentday_currentorclosingledger", "82"));
        metaFields3.add(makeMetaField("balances_currentday_currentorclosingavailable", "4017"));
        metaFields3.add(makeMetaField("balances_currentday_totalcreditsamount", "1200.62"));
        metaFields3.add(makeMetaField("balances_currentday_totalcreditscount", "8081"));
        metaFields3.add(makeMetaField("balances_currentday_totaldebitsamount", "152.46"));
        metaFields3.add(makeMetaField("balances_currentday_totaldebitscount", "89911"));
        metaFields3.add(makeMetaField("balances_currentday_totalday1floatamount", "2492"));
        metaFields3.add(makeMetaField("balances_currentday_totalday2plusfloatamount", "461"));
        metaFields3.add(makeMetaField("balances_priorday_asofdate", "2018-02-22"));
        metaFields3.add(makeMetaField("balances_priorday_openingledger", "122"));
        metaFields3.add(makeMetaField("balances_priorday_currentorclosingledger", "616"));
        metaFields3.add(makeMetaField("balances_priorday_currentorclosingavailable", "2818"));
        ac3.setMeta(metaFields3);
    }

    private static MetaField makeMetaField(String name, String val) {
        MetaField mf = new MetaField();
        mf.setName(name);
        mf.setValue(val);

        return mf;
    }


    @Override
    public List<Account> accounts(String secret, String token, AccountsRequest accountsRequest, Map<String, String> responseHeaders) throws ApiException {

        List<Account> accountList = new ArrayList<>();
        accountList.add(ac);
        accountList.add(ac2);

        return accountList;
    }

    @Override
    public Customer customer(String secret, String token, CustomerRequest customerRequest, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public List<Payee> payees(String secret, String token, PayeesRequest payeesRequest, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public List<Category> categories(String secret, String token, CategoriesRequest categoriesRequest, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public List<Merchant> merchants(String secret, String token, MerchantsRequest merchantsRequest, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public List<Transaction> transactions(String secret, String token, TransactionCriteria transactionCriteria, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public CustomerActionResponse customerAction(HeaderData hData, CustomerActionRequest actionRequest, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }

    @Override
    public List<Offer> bankOffers(String secret, String token, OfferRequest request, Map<String, String> responseHeaders) throws ApiException {
        return null;
    }
}
