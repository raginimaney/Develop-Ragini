package com.kasisto.iapi.webhook.apps.bb.transactioninquiry;

import com.kasisto.iapi.webhook.core.workflow.WFCondition;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;

public class NoTransactionFoundWFCondition implements WFCondition {


    @Override
    public boolean conditionMet(WFEvent event) {

        return event.getCurrentUserInputs().containsKey(TransactionInquiryIntentProcessor.FIELD_REFNUM)
                && (!event.getCurrentUserInputs().containsKey(TransactionInquiryIntentProcessor.FIELD_ACTNUM) &&
                !event.getCurrentUserInputs().containsKey(TransactionInquiryIntentProcessor.FIELD_AMOUNT) &&
                !event.getCurrentUserInputs().containsKey(TransactionInquiryIntentProcessor.FIELD_DATE) &&
                event.getSystemInputs().containsKey(TransactionInquiryIntentProcessor.FIELD_HAS_TX_FOR_REFNUM) &&
                !event.getSystemInputs().get(TransactionInquiryIntentProcessor.FIELD_HAS_TX_FOR_REFNUM).value.toLowerCase().equals("true"));

    }


}
