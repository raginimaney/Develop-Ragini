package com.kasisto.iapi.webhook.apps.bb.transactioninquiry;

import com.kasisto.api.model.Account;
import com.kasisto.api.model.AccountsRequest;
import com.kasisto.api.model.Transaction;
import com.kasisto.api.model.TransactionCriteria;
import com.kasisto.iapi.webhook.apps.bb.AccountUtil;
import com.kasisto.iapi.webhook.apps.bb.TransactionUtil;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TransactionInquiryIntentProcessor extends AbstractIntentProcessor {


    private Log log = LogFactory.getLog(getClass());
    public static final String TX_INQUIRY_INTENT_NAME = "transactioninquiry";

    public SimplifiedEnterpriseApi eapiClient;

    public static final String FIELD_ACTNUM = "TI_accountnum";
    public static final String FIELD_REFNUM = "TI_txrefnum";
    public static final String FIELD_DATE = "TI_txdate";
    public static final String FIELD_AMOUNT = "TI_txamount";
    public static final String FIELD_SEEMORE = "TI_seemore";


    //a system input that is generated if user has at least one transaction for a refnum
    public static final String FIELD_HAS_TX_FOR_REFNUM = "TI_SYS_has_tx_for_refnum";

    //the page of transactions that user is on;
    public static final String FIELD_TX_PAGE="TI_SYS_tx_page";
    public static final String FIELD_TX_TX_REMAIN="TI_SYS_tx_remain";

    private static final int PAGE_SIZE = 2;

    private static String eapiSecret;


    private enum PROMPTS {
        TRANSACTION_INQUIRY_PROMPT_REF_NUM,
        TRANSACTION_INQUIRY_PROMPT_AMOUNT,
        TRANSACTION_INQUIRY_PROMPT_DATE,

        TRANSACTION_INQUIRY_PROMPT_ACCOUNT_NUM,
        TRANSACTION_INQUIRY_PROMPT_UNKNOWN,
                TRANSACTION_INQUIRY_PROMPT_NOTXS,
        TRANSACTION_INQUIRY_PROMPT_NOTXS_REPROMPT_ACCOUNT,

        TRANSACTION_INQUIRY_PROMPT_BREAKDOWN,
        TRANSACTION_INQUIRY_PROMPT_GOODBYE,
        TRANSACTION_INQUIRY_PROMPT_TRANSACTION_END;
    }


    //Dialog Prompts
    ResourceBundle promptResource = ResourceBundle.getBundle(TX_INQUIRY_INTENT_NAME);


    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {


        ConversationResponse cr = new ConversationResponse();
        cr.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        if (action == TransactionInquiryWorkflow.Actions.GET_REF) {

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_REF_NUM.name())));
            cr.request_user_input = new RequestUserInput(FIELD_REFNUM, RequestUserInput.UserInputType.STRING);

        } else if (action == TransactionInquiryWorkflow.Actions.GET_MISSING_PARAM) {


            if (accumulatedInputs.containsKey(FIELD_ACTNUM) && accumulatedInputs.containsKey(FIELD_DATE)) {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_AMOUNT.name())));
                cr.request_user_input = new RequestUserInput(FIELD_AMOUNT, RequestUserInput.UserInputType.CURRENCY_AMOUNT);
            } else if (accumulatedInputs.containsKey(FIELD_ACTNUM) && accumulatedInputs.containsKey(FIELD_AMOUNT)) {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_DATE.name())));
                cr.request_user_input = new RequestUserInput(FIELD_DATE, RequestUserInput.UserInputType.DATE);
            } else if (accumulatedInputs.containsKey(FIELD_ACTNUM)) {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_AMOUNT.name())));
                cr.request_user_input = new RequestUserInput(FIELD_AMOUNT, RequestUserInput.UserInputType.CURRENCY_AMOUNT);
            } else if (accumulatedInputs.containsKey(FIELD_AMOUNT)) {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_ACCOUNT_NUM.name())));
                cr.request_user_input = new RequestUserInput(FIELD_ACTNUM, RequestUserInput.UserInputType.NUMBER);
            } else {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_UNKNOWN.name())));
                cr.request_user_input = new RequestUserInput(FIELD_AMOUNT, RequestUserInput.UserInputType.CURRENCY_AMOUNT);
            }

        } else if (action == TransactionInquiryWorkflow.Actions.SHOW_TX) {



            List<Transaction> filteredTxs = this.getTransactionsForSession(null,token,accumulatedInputs,systemInputs);

            if (filteredTxs != null && filteredTxs.size() > 0) {
                cr.message_contents.add(TxCtaGenerator.ctaForTx(filteredTxs));


                if(systemInputs.containsKey(FIELD_TX_TX_REMAIN) && systemInputs.get(FIELD_TX_TX_REMAIN).value.equals("true")
                        && filteredTxs.size() >= PAGE_SIZE) {
                    cr.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

                    cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_BREAKDOWN.name())));
                    cr.request_user_input = new RequestUserInput(FIELD_SEEMORE, RequestUserInput.UserInputType.BOOLEAN);
                }else{

                    cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_TRANSACTION_END.name())));
                    cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;
                }
            } else {
                cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_NOTXS.name())));

            }



        } else if (action == TransactionInquiryWorkflow.Actions.GOODBYE) {

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_GOODBYE.name())));
            cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;

        } else if (action == TransactionInquiryWorkflow.Actions.INVALID_REF) {

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.TRANSACTION_INQUIRY_PROMPT_NOTXS_REPROMPT_ACCOUNT.name())));
            cr.request_user_input = new RequestUserInput(FIELD_ACTNUM, RequestUserInput.UserInputType.NUMBER);


        }

        return cr;
    }


    /**
     * (1) Increment the page number for transactions if in the TX_Review
     * (2) Set the tx-remain status
     * @param action
     * @param session
     */
    @Override
    public void updatePostConditions(WFAction action,ConversationSession session) {


        if(action == TransactionInquiryWorkflow.Actions.SHOW_TX) {
            setTransactionsRemainStatus(session,true);
        }
    }

    private void setTransactionsRemainStatus(ConversationSession session, boolean incrementPage){
        List<Transaction> transactions = getTransactionsForSession(session,null,null,null);


        if(transactions.size() < 1){
            session.getSystemInputs().put(FIELD_TX_TX_REMAIN, new SystemInput(FIELD_TX_TX_REMAIN,"false"));
        }else{
            session.getSystemInputs().put(FIELD_TX_TX_REMAIN, new SystemInput(FIELD_TX_TX_REMAIN,"true"));
        }

        if(incrementPage) {
            int page = 0;
            if (session.getSystemInputs().containsKey(FIELD_TX_PAGE)) {
                page = Integer.parseInt(session.getSystemInputs().get(FIELD_TX_PAGE).value);
            }
            page++;

            session.getSystemInputs().put(FIELD_TX_PAGE, new SystemInput(FIELD_TX_PAGE,""+page));
        }


    }

    @Override
    public void updatePreconditions(ConversationSession session) {


        WFEvent wfEvent = new WFEvent();

        SystemInput systemInput = new SystemInput();
        systemInput.name = FIELD_HAS_TX_FOR_REFNUM;
        systemInput.value = Boolean.FALSE.toString();

        String token = session.token;


        //if the current user is asking for refnum then check if they have transactions
        if (session.getCurrentUserInputs().containsKey(FIELD_REFNUM)) {
            List<Transaction> txs = getTransactions(session.getCurrentUserInputs().get(FIELD_REFNUM).value, token, null, null, null);

            if (txs != null && txs.size() > 0) {
                systemInput.value = Boolean.TRUE.toString();

            }
        }


        wfEvent.addToSystemInputs(systemInput);


        log.info("Found WF EVENT:" + wfEvent.toString());
        session.getSystemInputs().put(FIELD_HAS_TX_FOR_REFNUM, systemInput);


        this.setTransactionsRemainStatus(session,false);

    }

    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi eapiClient) {

        this.eapiSecret = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_SECRET_PROPERTY_NAME);
        this.eapiClient = eapiClient;
    }

    public SimplifiedEnterpriseApi getSimplifiedEnterpriseApiClient() {
        return this.eapiClient;
    }


    public List<Transaction> getTransactionsForSession(ConversationSession session,String tok, Map<String, UserInput> accumInputs, Map<String, SystemInput> sysInputs ){




       Map<String, UserInput> accumulatedInputs = accumInputs;
        Map<String, SystemInput> systemInputs = sysInputs;

        String token = tok;

        if(session != null){
            accumulatedInputs = session.getAccumulatedUserInput();
            systemInputs = session.getSystemInputs();
            token =session.token;
        }

        if(accumulatedInputs.containsKey(FIELD_DATE)){
            System.out.println("date==>"+accumulatedInputs.get(FIELD_DATE).value);
        }else{
            System.out.println("no date found");
        }


        List<Transaction> filteredTxs = new ArrayList<>();
        int page = 0;

            if(systemInputs != null && systemInputs.containsKey(FIELD_TX_PAGE)){
                page = Integer.parseInt(systemInputs.get(FIELD_TX_PAGE).value);
            }

            if(accumulatedInputs != null) {

                if (!accumulatedInputs.containsKey(FIELD_DATE) && accumulatedInputs.containsKey(FIELD_REFNUM)) {
                    filteredTxs = getTransactions(accumulatedInputs.get(FIELD_REFNUM).value, token, null, null, null, page);
                } else {

                    double currency = -1;

                    if (accumulatedInputs.containsKey(FIELD_AMOUNT) && accumulatedInputs.get(FIELD_AMOUNT).value.contains(" ")) {
                        currency = Double.parseDouble(accumulatedInputs.get(FIELD_AMOUNT).value.split("\\s")[1]);
                    } else if (accumulatedInputs.containsKey(FIELD_AMOUNT)) {
                        currency = Double.parseDouble(accumulatedInputs.get(FIELD_AMOUNT).value);
                    }

                    if( accumulatedInputs.containsKey(FIELD_ACTNUM) && accumulatedInputs.containsKey(FIELD_DATE)) {
                        filteredTxs = getTransactions(null, token, accumulatedInputs.get(FIELD_ACTNUM).value,
                                strToDate(accumulatedInputs.get(FIELD_DATE).value), //eg parse 2018-09-13T00:00:00
                                currency, page); //e.g parse "USD 100"
                    }
                }
            }

            return filteredTxs;
    }


    public List<Transaction> getTransactions(String refNum, String token, String accountNum, Date date, Double amount, int page){

        List<Transaction> transactions = getTransactions(refNum,token,accountNum,date,amount);



        int min = page*PAGE_SIZE;
        int max = Math.min(transactions.size(),(page+1)*PAGE_SIZE);

        log.info("get transactions in the range of"+min+ " to "+max + " of transactions "+transactions.size());

        if(min > transactions.size() || max > transactions.size()){
            return new ArrayList<Transaction>();
        }

        List<Transaction> transactionSubList = transactions.subList(min,max);
        return transactionSubList;

    }




    public List<Transaction> getTransactions(String refNum, String token, String accountNum, Date date, Double amount) {


        TransactionCriteria criteria = new TransactionCriteria();

        Map<String, String> headers = new HashMap<>();

        List<Transaction> filteredTxs = new ArrayList<>();

        String accountId = null;

        try {
            List<Transaction> txs = eapiClient.transactions(eapiSecret, token, criteria, headers);

            if(accountNum != null){
                AccountsRequest accountCriteria = new AccountsRequest();
                List<Account> account = eapiClient.accounts(eapiSecret, token, accountCriteria, headers);
                List<Account> filterAccount = AccountUtil.accountFilterByAccountType(account,null,accountNum,null,null);
                //if no account for a particular account-num, then set account-id to a placeholder id that will ensure we filter out all transactions
                if(filterAccount.size() > 0){
                    accountId = filterAccount.get(0).getAccountId();
                }else{
                    accountId = "missing_account_id";
                }
            }

            filteredTxs = TransactionUtil.transactionFilter(txs, refNum, accountId, date, amount, eapiClient);

        } catch (ApiException e) {
            e.printStackTrace();
        }
        return filteredTxs;
    }

    private Date strToDate(String sDate) {
      //  SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = df.parse(sDate);
            return date;
        } catch (ParseException pe) {
            log.error("could not parse date"+pe.toString());
            Date date = null;
            return date;
        }


    }

}
