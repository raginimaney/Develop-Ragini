package com.kasisto.iapi.webhook.apps.bb.transactioninquiry;

import com.kasisto.iapi.webhook.core.workflow.*;

import java.util.ArrayList;
import java.util.List;

import static com.kasisto.iapi.webhook.apps.bb.transactioninquiry.TransactionInquiryIntentProcessor.*;

public class TransactionInquiryWorkflow extends Workflow {

    enum States implements WFState {
        START, COLLECT_REFNUM, COLLECT_OTHER_PARAM, END
    }

    enum Actions implements WFAction {
        GET_REF, GET_MISSING_PARAM, INVALID_REF, SHOW_TX,GOODBYE;
    }


    @Override
    public List<WFTransition> generateTransitions() {

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.GET_REF, States.START, States.COLLECT_REFNUM, event -> {

            return !event.hasUserInput(FIELD_ACTNUM) && !event.hasUserInput(FIELD_REFNUM)
                    && !event.hasUserInput(FIELD_AMOUNT) && !event.hasUserInput(FIELD_DATE);

        }));

        transitions.add(new WFTransition(Actions.GET_MISSING_PARAM, States.START, States.COLLECT_OTHER_PARAM, event -> {

            return !event.hasUserInput(FIELD_REFNUM) && (event.hasUserInput(FIELD_ACTNUM) ||
                    event.hasUserInput(FIELD_AMOUNT) || event.hasUserInput(FIELD_DATE));

        }));

        transitions.add(new WFTransition(Actions.GET_MISSING_PARAM, States.COLLECT_OTHER_PARAM, States.COLLECT_OTHER_PARAM, event -> {


            return

                    !event.getCurrentUserInputs().containsKey(FIELD_REFNUM)
                            &&
                            //has an input
                            hasAInput(event, new String[]{FIELD_ACTNUM,FIELD_AMOUNT,FIELD_DATE})
                            &&
                            //but not all three.  if all three are satisified, should go to end
                            !hasAllInputs(event, new String[]{FIELD_ACTNUM,FIELD_AMOUNT, FIELD_DATE});
        }));


        transitions.add(new WFTransition(Actions.SHOW_TX, States.COLLECT_OTHER_PARAM, States.END, event -> {
            return !event.getCurrentUserInputs().containsKey(FIELD_REFNUM)
                    && hasAllInputs(event, new String[]{FIELD_ACTNUM,FIELD_AMOUNT, FIELD_DATE});

        }));

        transitions.add(new WFTransition(Actions.SHOW_TX, States.COLLECT_REFNUM, States.END, event -> {


            return event.hasUserInput(FIELD_REFNUM) &&
                    event.getSysInputVal(FIELD_HAS_TX_FOR_REFNUM).toLowerCase().equals("true")
                    && (!event.hasUserInput(FIELD_ACTNUM) &&
                    !event.hasUserInput(FIELD_AMOUNT) && !event.hasUserInput(FIELD_DATE));
        }));

        transitions.add(new WFTransition(Actions.SHOW_TX, States.END, States.END, event -> {

            return event.getSysInputVal(FIELD_TX_TX_REMAIN).toLowerCase().equals("true")
                    && event.getVal(FIELD_SEEMORE).toLowerCase().equals("yes");
        }));

        transitions.add(new WFTransition(Actions.GOODBYE, States.END, States.END, event -> {


            return  event.getSysInputVal(FIELD_TX_TX_REMAIN).toLowerCase().equals("false") ||
                    event.getVal(FIELD_SEEMORE).toLowerCase().equals("no");
        }));


        transitions.add(new WFTransition(Actions.INVALID_REF, States.COLLECT_REFNUM, States.COLLECT_OTHER_PARAM,
                new NoTransactionFoundWFCondition()));

        return transitions;
    }

    private boolean hasAllInputs(WFEvent event, String[] params) {

        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
            } else {
                return false;
            }
        }
        return true;
    }


    private boolean hasAInput(WFEvent event, String[] params) {

        boolean hasAInput = false;
        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
                hasAInput = true;
            } else {

            }
        }
        return hasAInput;
    }


    @Override
    public WFState getOrigin() {
        return States.START;
    }
}
