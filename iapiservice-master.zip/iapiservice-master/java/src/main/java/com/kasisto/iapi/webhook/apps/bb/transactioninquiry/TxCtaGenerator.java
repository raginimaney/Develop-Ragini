package com.kasisto.iapi.webhook.apps.bb.transactioninquiry;

import com.kasisto.api.model.Transaction;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentCard;
import com.kasisto.iapi.webhook.core.model.response.MessageContentContainer;

import java.util.ArrayList;
import java.util.List;

public class TxCtaGenerator {


    public static MessageContent ctaForTx(List<Transaction> txs) {

        List<MessageContent> options = new ArrayList<>();

        for (int i = 0; i < txs.size(); i++) {
            options.add(new MessageContentCard(txs.get(i).getTransactionDate().toString(), "Amount: " + txs.get(i).getAmount(), new MessageContentCard.Medium("https://www.wpclipart.com/office/chart_graph/bar_chart_2.png")));
        }


        MessageContentContainer container = new MessageContentContainer(MessageContentContainer.MSG_CONTAINER_CAROUSEL, options);
        return container;

    }

}

