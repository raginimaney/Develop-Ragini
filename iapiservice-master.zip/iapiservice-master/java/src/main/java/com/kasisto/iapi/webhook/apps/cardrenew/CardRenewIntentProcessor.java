package com.kasisto.iapi.webhook.apps.cardrenew;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This class contains a very Basic sample Controller for a Dynamic guided
 * conversation on Card Renewal.
 * <p>
 * The intent requires the user to be authenticated.
 * <p>
 * It needs 2 input fields: 1) the last 4 digits of the card 2) the expiration
 * date of the card
 * <p>
 * When all the required data is collected, the intent asks the user for a
 * confirmation before the final submission.
 *
 * @author olivier
 * @author jon (updated 10/11 for the updated workflow-model)
 */
public class CardRenewIntentProcessor extends AbstractIntentProcessor {

    public static final String CARD_RENEW_INTENT_NAME = "Card_Renew";
    /**
     * The list of fields to be captured by the intent
     */
    public static final String FIELD_CARD_NUMBER = "card_number";
    public static final String FIELD_CARD_EXPIRATION = "card_expiry_date";
    public static final String CONFIRM_SUBMISSION = "confirm_submission";
    public static final String CONFIRM_RENEW_OTHER_CARD = "confirm_renew_other_card";


    /**
     * The intent asks for the user confirmation before the final submission
     */


    /**
     * Method to check if the user needs to be authenticated to start the intent
     * input.
     */
    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction wfAction, String userId, String token, Map<String, UserInput> userInputs, Map<String, SystemInput> systemInputs, Context context) {


        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        if (wfAction == CardRenewWorkflow.Actions.LIST_CARD) {

            List<CreditCard> creditCards = CreditCardApi.getCreditCards("1");

            List<RequestUserInput.CardOption> options = new ArrayList<>();
            for (CreditCard creditCard : creditCards) {
                options.add(new RequestUserInput.CardOption(creditCard.lastLastFourDigits, creditCard.active, "Renew card" + creditCard.lastLastFourDigits, new RequestUserInput.Medium("https://kasisto.com/wp-content/themes/Divi/images/logo.png"), "Credit card" + creditCard.lastLastFourDigits, "Expiring" + creditCard.expirationDate));
            }
            response.message_contents.add(new MessageContentText(genText("What are the last 4 digits of your card ?", userInputs.values())));
            response.request_user_input = new RequestUserInput(FIELD_CARD_NUMBER, RequestUserInput.UserInputType.NUMBER, RequestUserInput.RequestUserInputMode.CAROUSEL, options);

        } else if (wfAction == CardRenewWorkflow.Actions.CONFIRM_DATE) {

            response.request_user_input = new RequestUserInput(FIELD_CARD_EXPIRATION, RequestUserInput.UserInputType.DATE);
            response.message_contents.add(new MessageContentText(
                    genText("Please enter the expiration date of your card ${" + FIELD_CARD_NUMBER + "} ", userInputs.values())));

        } else if (wfAction == CardRenewWorkflow.Actions.GET_CONFIRMATION) {

            response.message_contents.add(new MessageContentText(genText("Let's confirm, you want to renew your card ${" + FIELD_CARD_NUMBER
                    + "} that expires ${" + FIELD_CARD_EXPIRATION + "}", userInputs.values())));
            response.request_user_input = new RequestUserInput(CONFIRM_SUBMISSION, RequestUserInput.UserInputType.BOOLEAN);
        } else if (wfAction == CardRenewWorkflow.Actions.GOODBYE) {

            //submit the renewal request
            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
            response.message_contents.add(new MessageContentText(genText("I submitted the renewal of your card ${"
                    + FIELD_CARD_NUMBER + "} expiring ${" + FIELD_CARD_EXPIRATION + "}", userInputs.values())));
        } else if (wfAction == CardRenewWorkflow.Actions.CANCEL) {

            //submit the renewal request
            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
            response.message_contents.add(new MessageContentText("I canceled your card renewel request"));
        }

        return response;
    }


}
