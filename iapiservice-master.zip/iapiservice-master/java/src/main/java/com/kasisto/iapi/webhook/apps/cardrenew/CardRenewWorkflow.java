package com.kasisto.iapi.webhook.apps.cardrenew;


import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFState;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;

import java.util.ArrayList;
import java.util.List;

public class CardRenewWorkflow extends Workflow {


    public enum States implements WFState {
        START, END, CARDS, EXPIRE, CONFIRM
    }

    enum Actions implements WFAction {

        GOODBYE, CANCEL, LIST_CARD, GET_CONFIRMATION, CONFIRM_DATE
    }


    @Override
    public WFState getOrigin() {
        return States.START;
    }


    @Override
    public List<WFTransition> generateTransitions() {
        List<WFTransition> transitions = new ArrayList<>();

        //go from start to cards state with action=list-cards if no card number is provided
        transitions.add(new WFTransition(Actions.LIST_CARD, States.START, States.CARDS, event -> {
            String cardNum = event.getVal(CardRenewIntentProcessor.FIELD_CARD_NUMBER);
            return cardNum == null;

        }));

        //if a card number is provided go to the expire state
        transitions.add(new WFTransition(Actions.CONFIRM_DATE, States.START, States.EXPIRE, event -> {
            String cardNum = event.getVal(CardRenewIntentProcessor.FIELD_CARD_NUMBER);
            return cardNum != null;

        }));

        transitions.add(new WFTransition(Actions.CONFIRM_DATE, States.CARDS, States.EXPIRE, event -> {
            String cardNum = event.getVal(CardRenewIntentProcessor.FIELD_CARD_NUMBER);
            return cardNum != null && !isValidCardNumber(cardNum);

        }));

        transitions.add(new WFTransition(Actions.CONFIRM_DATE, States.CARDS, States.EXPIRE, event -> {
            String cardNum = event.getVal(CardRenewIntentProcessor.FIELD_CARD_NUMBER);
            return cardNum != null && isValidCardNumber(cardNum);
        }));

        transitions.add(new WFTransition(Actions.GET_CONFIRMATION, States.EXPIRE, States.CONFIRM, event -> {
            String date = event.getVal(CardRenewIntentProcessor.FIELD_CARD_EXPIRATION);
            return date != null && isValidExpirationDate(date);
        }));

        transitions.add(new WFTransition(Actions.GOODBYE, States.CONFIRM, States.END, event -> {
            String confirm = event.getVal(CardRenewIntentProcessor.CONFIRM_SUBMISSION);
            return (confirm.equals("yes"));
        }));

        transitions.add(new WFTransition(Actions.CANCEL, States.CONFIRM, States.END, event -> {
            String confirm = event.getVal(CardRenewIntentProcessor.CONFIRM_SUBMISSION);
            return (confirm.equals("no"));
        }));

        return transitions;
    }

    /*
    Should we do back-end validation at this.  It may complicate workflow if there are external dependencies
    May need to introduce a cleaner architectural separation between validation and workflow
     */
    private boolean isValidCardNumber(String cardNum) {

        return Integer.parseInt(cardNum) > 10;
    }

    private boolean isValidExpirationDate(String date) {

        return true;
    }

}
