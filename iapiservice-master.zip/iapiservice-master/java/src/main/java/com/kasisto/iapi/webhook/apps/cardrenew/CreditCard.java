package com.kasisto.iapi.webhook.apps.cardrenew;


public class CreditCard {

    public String lastLastFourDigits;
    public String expirationDate;
    public String imageUrl;

    public boolean active;


    public CreditCard(String lastLastFourDigits, boolean active, String expirationDate, String imageUrl) {
        this.lastLastFourDigits = lastLastFourDigits;
        this.expirationDate = expirationDate;
        this.imageUrl = imageUrl;
        this.active = active;
    }


}
