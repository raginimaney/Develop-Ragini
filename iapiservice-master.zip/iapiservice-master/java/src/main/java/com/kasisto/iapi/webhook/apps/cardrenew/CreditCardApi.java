package com.kasisto.iapi.webhook.apps.cardrenew;

import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder for a API-backed source for CreditCard data
 */
public class CreditCardApi {

    private static List<CreditCard> creditCards;

    static {
        creditCards = new ArrayList<CreditCard>();

        creditCards.add(new CreditCard("1234", true, "20/03/2019", "https://kasisto.com/wp-content/themes/Divi/images/logo.png"));
        creditCards.add(new CreditCard("2345", false, "20/02/2019", "https://kasisto.com/wp-content/themes/Divi/images/logo.png"));
        creditCards.add(new CreditCard("4567", false, "20/01/2019", "https://kasisto.com/wp-content/themes/Divi/images/logo.png"));

    }

    public static List<CreditCard> getCreditCards(String userId) {
        return creditCards;
    }


}
