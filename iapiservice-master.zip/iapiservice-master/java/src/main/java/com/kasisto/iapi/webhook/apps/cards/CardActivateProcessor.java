package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.WFAction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;


public class CardActivateProcessor extends AbstractIntentProcessor {

    private Log log = LogFactory.getLog(getClass());
    public static final String CARD_ACTIVATE_INTENT_NAME = "Card_Activate";
    //Fields
    public static final String FIELD_CARDNUM = "card_number";
    public static final String FIELD_CCV = "card_ccv";
    public static final String FIELD_EXPIRY = "card_expiry";
    public static final String PATTERN_EXPIRY = "\\b(([0-9][1-2][0-9][0-9])|((([1-9])|(0[1-9]|1[0-2]))(\\/|-)([0-9]{4}|[0-9]{2})))\\b";
    public static final String PATTERN_CCV = "\\d{3}";

    //Global Vars
    public static final int MAX_RETRY_COUNT = 1;

    public static final String GLOBAL_ISCARDACTIVATED = "GLOBAL_isCardActivated";
    public static final String GLOBAL_ISCARDVALID = "GLOBAL_isCardValid";
    public static final String GLOBAL_RETRY_COUNT = "GLOBAL_retryCount";


    //Dialog Prompts
    ResourceBundle promptResource = ResourceBundle.getBundle("CardActivate");

    public CardActivateProcessor(){
        minimalApiVersion = "2.1.1";
    }

    enum PROMPTS {
        CARD_ACTIVATE_PROMPT_DEFAULT_ERROR,
        CARD_ACTIVATE_PROMPT_CARDNUM_GET,
        CARD_ACTIVATE_PROMPT_CARDNUM_GET_ERROR_VALIDATION,
        CARD_ACTIVATE_PROMPT_CCV_GET,
        CARD_ACTIVATE_PROMPT_CCV_GET_ERROR_VALIDATION,
        CARD_ACTIVATE_PROMPT_EXPIRY_GET,
        CARD_ACTIVATE_PROMPT_EXPIRY_GET_ERROR_VALIDATION,
        CARD_ACTIVATE_PROMPT_ACTIVATED,
        CARD_ACTIVATE_PROMPT_RETRY,
        CARD_ACTIVATE_PROMPT_RETRY_ERROR,
        CARD_ACTIVATE_PROMPT_RETRY_ERROR_VALIDATION,
        CARD_ACTIVATE_PROMPT_FATAL
    }


    //EAPI
    public SimplifiedEnterpriseApi eapiClient;
    CardApi cardApi = null;


    @Override
    public boolean isLoginRequired() {
        return true;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {
        ConversationResponse cr = new ConversationResponse();
        cr.conversation_state = ConversationResponse.ConversationState.PENDING_USER;
        cr.request_user_input = new RequestUserInput(FIELD_CARDNUM, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER);


        if (action == CardActivateWorkflow.Actions.CARDNUM_GET_INIT) {
            //Init System Vars

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CARDNUM_GET.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CARDNUM_GET_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_CARDNUM, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, optionalParams);


        } else if (action == CardActivateWorkflow.Actions.CCV_GET_INIT) {
            //Init System Vars

            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CCV_GET.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CCV_GET_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_CCV, RequestUserInput.UserInputType.PATTERN, PATTERN_CCV, optionalParams);

        } else if (action == CardActivateWorkflow.Actions.CARDNUM_GET) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CARDNUM_GET.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CARDNUM_GET_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_CARDNUM, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, optionalParams);


        } else if (action == CardActivateWorkflow.Actions.CCV_GET) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CCV_GET.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_CCV_GET_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_CCV, RequestUserInput.UserInputType.PATTERN, PATTERN_CCV, optionalParams);

        } else if (action == CardActivateWorkflow.Actions.EXPIRY_GET) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_EXPIRY_GET.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_EXPIRY_GET_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_EXPIRY, RequestUserInput.UserInputType.PATTERN, PATTERN_EXPIRY, optionalParams);


        } else if (action == CardActivateWorkflow.Actions.ACTIVATED) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_ACTIVATED.name())));
            cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;

        } else if (action == CardActivateWorkflow.Actions.RETRY) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_RETRY.name())));
            HashMap optionalParams = new HashMap();
            optionalParams.put(RequestUserInput.OptionalParams.ValidationErrorPatternDoesNotMatch, promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_RETRY_ERROR_VALIDATION.name()));
            cr.request_user_input = new RequestUserInput(FIELD_CARDNUM, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, optionalParams);

        } else if (action == CardActivateWorkflow.Actions.FATAL) {
            cr.message_contents.add(new MessageContentText(promptResource.getString(PROMPTS.CARD_ACTIVATE_PROMPT_FATAL.name())));
            cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;
        }


        return cr;
    }


    private void updateSystemInputs(Map<String, SystemInput> systemInputs, String key, String val) {
        systemInputs.replace(key, new SystemInput(key, val));
    }

    private void putSystemInputs(Map<String, SystemInput> systemInputs, String key, String val) {
        systemInputs.put(key, new SystemInput(key, val));
    }


    private Boolean eapiCreditCardActivate(String token, String cardno, String ccv, String exp) throws ApiException {
        Boolean status = cardApi.eapiCreditCardActivate(token, cardno, ccv, exp);
        log.info("eapiCreditCardActivate - status:" + status.toString());
        return status;
    }


    private Boolean eapiIsCreditCardValid(String token, String cardno) {
        Boolean status = cardApi.eapiIsCreditCardValid(token, cardno);
        log.info("eapiIsCreditCardValid - status:" + status.toString());
        return status;
    }


    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi eapiClient) {
        this.eapiClient = eapiClient;
        cardApi = new CardApi(this.eapiClient);
    }


    @Override
    public void updatePostConditions(WFAction action, ConversationSession session) {

        Map<String, SystemInput> systemInputs = session.getSystemInputs();

        if (action == CardActivateWorkflow.Actions.CARDNUM_GET_INIT) {
            //Init System Vars
            putSystemInputs(systemInputs, GLOBAL_ISCARDVALID, "false");
            putSystemInputs(systemInputs, GLOBAL_ISCARDACTIVATED, "false");
            putSystemInputs(systemInputs, GLOBAL_RETRY_COUNT, "0");


        } else if (action == CardActivateWorkflow.Actions.CCV_GET_INIT) {
            //Init System Vars
            putSystemInputs(systemInputs, GLOBAL_ISCARDVALID, "false");
            putSystemInputs(systemInputs, GLOBAL_ISCARDACTIVATED, "false");
            putSystemInputs(systemInputs, GLOBAL_RETRY_COUNT, "0");


        } else if (action == CardActivateWorkflow.Actions.RETRY) {
            int retries = Integer.parseInt(systemInputs.get(GLOBAL_RETRY_COUNT).value) + 1;
            updateSystemInputs(systemInputs, GLOBAL_RETRY_COUNT, new Integer(retries).toString());
        }
    }


    @Override
    public void updatePreconditions(ConversationSession session) {

        //update EAPI token

        String token = session.token;

        String ccnum = null;
        if (session.getCurrentUserInputs().containsKey(FIELD_CARDNUM)) {
            ccnum = session.getCurrentUserInputs().get(FIELD_CARDNUM).value;

        }

        if (session.getAccumulatedUserInput().containsKey(FIELD_CARDNUM) &&
                session.getAccumulatedUserInput().containsKey(FIELD_CCV) &&
                session.getAccumulatedUserInput().containsKey(FIELD_EXPIRY)) {

            //validate
            ccnum = session.getAccumulatedUserInput().get(FIELD_CARDNUM).value;
            //Check if the Card Valid and process
            //System.out.println("ccnum=" + ccnum);

            Boolean isvalid = eapiIsCreditCardValid(token, ccnum);
            updateSystemInputs(session.getSystemInputs(), GLOBAL_ISCARDVALID, isvalid.toString());
            updateSystemInputs(session.getSystemInputs(), GLOBAL_ISCARDACTIVATED, Boolean.FALSE.toString());
            if (isvalid) {
                //Activate the card
                try {
                    String result = eapiCreditCardActivate(token, ccnum, session.getAccumulatedUserInput().get(FIELD_CCV).value, session.getAccumulatedUserInput().get(FIELD_EXPIRY).value).toString();
                    updateSystemInputs(session.getSystemInputs(), GLOBAL_ISCARDACTIVATED, result);
                } catch (ApiException ex) {
                    log.warn("WF EXCEPTION:" + ex.toString());
                    updateSystemInputs(session.getSystemInputs(), GLOBAL_ISCARDACTIVATED, Boolean.FALSE.toString());
                }
            }

        }


    }


}
