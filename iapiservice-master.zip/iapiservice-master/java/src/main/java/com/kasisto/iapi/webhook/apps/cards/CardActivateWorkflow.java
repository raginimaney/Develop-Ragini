package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.iapi.webhook.core.workflow.*;

import java.util.ArrayList;
import java.util.List;

public class CardActivateWorkflow extends Workflow {
    enum States implements WFState {
        START,
        INIT,
        CARDNUM,
        CARDNUM_RETRY,
        EXPIRY,
        CCV,
        END
    }

    enum Actions implements WFAction {
        CARDNUM_GET,
        CARDNUM_GET_INIT,
        CCV_GET,
        CCV_GET_INIT,
        EXPIRY_GET,
        ACTIVATED,
        RETRY,
        FATAL


    }


    @Override
    public List<WFTransition> generateTransitions() {

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.CARDNUM_GET_INIT, CardActivateWorkflow.States.START, States.CARDNUM, event -> {
            return !hasAInput(event, new String[]{CardActivateProcessor.FIELD_CARDNUM});
        }));

        transitions.add(new WFTransition(Actions.CCV_GET_INIT, CardActivateWorkflow.States.START, CardActivateWorkflow.States.CCV, event -> {
            return !event.hasUserInput(CardActivateProcessor.FIELD_CCV) &&
                    hasAInput(event, new String[]{CardActivateProcessor.FIELD_CARDNUM});
        }));

        transitions.add(new WFTransition(CardActivateWorkflow.Actions.CCV_GET, CardActivateWorkflow.States.CARDNUM, States.CCV, event -> {
            return event.hasUserInput(CardActivateProcessor.FIELD_CARDNUM);
        }));


        transitions.add(new WFTransition(Actions.EXPIRY_GET, States.CCV, States.EXPIRY, event -> {
            return !event.hasUserInput(CardActivateProcessor.FIELD_EXPIRY) &&
                    hasAInput(event, new String[]{CardActivateProcessor.FIELD_CARDNUM, CardActivateProcessor.FIELD_CCV});

        }));

        //VALID CARD, EXPIRY & CCV -> activate
        transitions.add(new WFTransition(CardActivateWorkflow.Actions.ACTIVATED, States.EXPIRY, CardActivateWorkflow.States.END, event -> {
            return event.hasUserInput(CardActivateProcessor.FIELD_EXPIRY) &&
                    event.getSysInputVal(CardActivateProcessor.GLOBAL_ISCARDACTIVATED).equals("true") &&
                    hasAInput(event, new String[]{CardActivateProcessor.FIELD_CARDNUM, CardActivateProcessor.FIELD_EXPIRY});
        }));

        //INVALID CARD -> retry
        transitions.add(new WFTransition(Actions.RETRY, States.EXPIRY, CardActivateWorkflow.States.CARDNUM, event -> {
            return event.getCurrentUserInputs().containsKey(CardActivateProcessor.FIELD_EXPIRY) &&
                    !event.getSysInputVal(CardActivateProcessor.GLOBAL_ISCARDACTIVATED).equals("true") &&
                    event.getSysInputVal(CardActivateProcessor.GLOBAL_RETRY_COUNT).equals("0") &&
                    hasAInput(event, new String[]{CardActivateProcessor.FIELD_CARDNUM, CardActivateProcessor.FIELD_EXPIRY});

        }));

        //INVALID CARD -> fatal
        transitions.add(new WFTransition(CardActivateWorkflow.Actions.FATAL, States.EXPIRY, CardActivateWorkflow.States.END, event -> {
            return !event.getSysInputVal(CardActivateProcessor.GLOBAL_RETRY_COUNT).equals("0");

        }));


        return transitions;
    }


    private boolean hasAllInputs(WFEvent event, String[] params) {

        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
            } else {
                return false;
            }
        }
        return true;
    }


    private boolean hasAInput(WFEvent event, String[] params) {

        boolean hasAInput = false;
        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
                hasAInput = true;
            } else {

            }
        }
        return hasAInput;
    }


    @Override
    public WFState getOrigin() {
        return CardActivateWorkflow.States.START;
    }
}
