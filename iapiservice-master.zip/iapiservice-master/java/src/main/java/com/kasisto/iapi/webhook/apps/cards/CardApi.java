package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.api.model.*;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.model.MetaField;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CardApi {


    private Log log = LogFactory.getLog(getClass());
    private SimplifiedEnterpriseApi eapiClient;

    private String LOCALE = "";

    private static final String EAPI_ACTION_META_CARDNUM = "meta_cc_number";
    private static final String EAPI_ACTION_META_CCV = "meta_ccv";
    private static final String EAPI_ACTION_META_EXPIRY_MONTH = "meta_exp_mm";
    private static final String EAPI_ACTION_META_EXPIRY_YEAR = "meta_exp_yy";

    private String eapiSecret;

    enum EAPI_CUSTOM_ACTIONS {
        CREDIT_CARD_ACTIVATE,
        CREDIT_CARD_BLOCK,
        CREDIT_CARD_UNBLOCK
    }


    public CardApi(SimplifiedEnterpriseApi client) {

        this.eapiSecret = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_SECRET_PROPERTY_NAME);
        eapiClient = client;
    }


    private String normalizeCreditCard(String cardno) {
        cardno = cardno.replaceAll("-", ""); //remove hyphens
        cardno = cardno.replaceAll(" ", ""); //remove spaces
        return cardno;
    }

    private Date normalizeExpiryDate(String exp) {
        Date expDate = null;
        String format = null;

        String tmp = exp.replaceAll("[0-9]", "1");

        if (tmp.equals("1-11")) {
            format = "0M-yy";
        } else if (tmp.equals("11-11")) {
            format = "MM-yy";
        } else if (tmp.equals("11-1111")) {
            format = "MM-yyyy";
        } else if (tmp.equals("1-1111")) {
            format = "0M-yyyy";
        } else if (tmp.equals("1/11")) {
            format = "0M/yy";
        } else if (tmp.equals("11/11")) {
            format = "MM/yy";
        } else if (tmp.equals("11/1111")) {
            format = "MM/yyyy";
        } else if (tmp.equals("1/1111")) {
            format = "0M/yyyy";
        } else if (tmp.equals("1111")) {
            format = "MMyy";
        }

        SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.ENGLISH);
        try {
            expDate = formatter.parse(exp);
        } catch (ParseException pex) {
            expDate = null;
            log.error("Error parsing Expiry Date - Invalid Pattern" + pex.getMessage());
        }

        return expDate;
    }


    public Boolean eapiCreditCardActivate(String token, String cardno, String ccv, String exp) throws ApiException {
        Date expDate = normalizeExpiryDate(exp);
        Calendar cal = Calendar.getInstance();
        cal.setTime(expDate);
        int year = cal.get(Calendar.YEAR);
        int day = cal.get(Calendar.MONTH);

        Map<String, String> responseHeaders = new HashMap<String, String>();

        HeaderData hd = new HeaderData();
        hd.setSecret(eapiSecret);
        hd.setToken(token);
        hd.setLocale(LOCALE);

        CustomerActionRequest req = new CustomerActionRequest();
        req.setAction(EAPI_CUSTOM_ACTIONS.CREDIT_CARD_ACTIVATE.name().toLowerCase());
        List<MetaField> reqparams = new ArrayList<>();
        reqparams.add(new MetaField(EAPI_ACTION_META_CARDNUM, cardno));
        reqparams.add(new MetaField(EAPI_ACTION_META_CCV, ccv));
        reqparams.add(new MetaField(EAPI_ACTION_META_EXPIRY_YEAR, Integer.toString(cal.get(Calendar.YEAR)))); //CCYY
        reqparams.add(new MetaField(EAPI_ACTION_META_EXPIRY_MONTH, Integer.toString(cal.get(Calendar.MONTH) + 1))); //1 = January
        req.setParameters(reqparams);

        //log.info("EAPI Request [eapiCreditCardActivate] - Request Params:" + reqparams.toString());
        CustomerActionResponse resp = eapiClient.customerAction(hd, req, responseHeaders);


        //TODO remove the path_ref_status once the tokens are fixed
        if (resp.getStatus().equals("processed")) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }

    }

    public Boolean eapiCreditCardBlock(String token, String cardno) throws ApiException {
        Map<String, String> responseHeaders = new HashMap<String, String>();
        HeaderData hd = new HeaderData();
        hd.setSecret(eapiSecret);
        hd.setToken(token);
        hd.setLocale(LOCALE);

        CustomerActionRequest req = new CustomerActionRequest();
        req.setAction(EAPI_CUSTOM_ACTIONS.CREDIT_CARD_BLOCK.name().toLowerCase());
        List<MetaField> reqparams = new ArrayList<>();
        reqparams.add(new MetaField(EAPI_ACTION_META_CARDNUM, cardno));
        req.setParameters(reqparams);
        CustomerActionResponse resp = eapiClient.customerAction(hd, req, responseHeaders);

        if (resp.getStatus().equals("processed")) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }

    }

    public Boolean eapiCreditCardBlockByAccountId(String token, String accountId) throws ApiException {
        //TODO - get Card Number from Account Id
        String cardno = "";
        // TODO
        return eapiCreditCardBlock(token, cardno);

    }


    public Boolean eapiCreditCardUnBlock(String token, String cardno) throws ApiException {

        Map<String, String> responseHeaders = new HashMap<String, String>();
        HeaderData hd = new HeaderData();
        hd.setSecret(eapiSecret);
        hd.setToken(token);
        hd.setLocale(LOCALE);

        CustomerActionRequest req = new CustomerActionRequest();
        req.setAction(EAPI_CUSTOM_ACTIONS.CREDIT_CARD_UNBLOCK.name().toLowerCase());
        List<MetaField> reqparams = new ArrayList<>();
        reqparams.add(new MetaField(EAPI_ACTION_META_CARDNUM, cardno));
        req.setParameters(reqparams);
        CustomerActionResponse resp = eapiClient.customerAction(hd, req, responseHeaders);

        if (resp.getStatus().equals("processed")) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }

    }

    public Boolean eapiCreditCardUnBlockByAccountId(String token, String accountId) throws ApiException {
        //TODO - get Card Number from Account Id
        String cardno = "";
        // TODO
        return eapiCreditCardUnBlock(token, cardno);

    }


    public Boolean eapiIsCreditCardValid(String token, String cardno) {
        Boolean foundValidCard = Boolean.FALSE;

        String regex = "^(?:(?<visa>4[0-9]{12}(?:[0-9]{3})?)|" +
                "(?<mastercard>5[1-5][0-9]{14})|" +
                "(?<discover>6(?:011|5[0-9]{2})[0-9]{12})|" +
                "(?<amex>3[47][0-9]{13})|" +
                "(?<diners>3(?:0[0-5]|[68][0-9])?[0-9]{11})|" +
                "(?<jcb>(?:2131|1800|35[0-9]{3})[0-9]{11}))$";

        Pattern pattern = Pattern.compile(regex);

        //normalize
        cardno = normalizeCreditCard(cardno);

        //Match the card
        Matcher matcher = pattern.matcher(cardno);

        if (matcher.matches()) {
            Account.AccountTypeEnum accountType = Account.AccountTypeEnum.CREDIT_CARD;
            List<Account> accounts = getAccounts(token, accountType, null, null);

            for (Account account : accounts) {
                if (account.getAccountNumber().equals(cardno) && !account.getAccountStatus().equals(Account.AccountStatusEnum.ACTIVE)) {
                    foundValidCard = Boolean.TRUE;
                }

            }
        }
        return foundValidCard;

    }






    public List<Account> getAccounts(String token, Account.AccountTypeEnum accountType, Account.AccountStatusEnum accountStatus, String accountNumSuffix) {


        AccountsRequest ar = new AccountsRequest();

        Map<String, String> responseHeaders = new HashMap<String, String>();


        List<Account> accounts = new ArrayList<>();
        try {

            accounts = eapiClient.accounts(eapiSecret, token, ar, responseHeaders);
        } catch (ApiException e) {
            e.printStackTrace();
        }


        if (accountType == Account.AccountTypeEnum.UNSPECIFIED) {
            return accounts;
        }

        Stream<Account> aStream = accounts.stream();


        if (accountType != null) {
            aStream = aStream.filter(x -> x.getAccountType().equals(accountType));
        }

        if (accountStatus != null) {

            aStream = aStream.filter(x -> x.getAccountStatus().equals(accountStatus));
        }

        if (accountNumSuffix != null) {
            aStream = aStream.filter(x -> x.getAccountNumber().endsWith(accountNumSuffix));
        }

        List<Account> filterAccounts = aStream
                .collect(Collectors.toList());
        return filterAccounts;

    }




}
