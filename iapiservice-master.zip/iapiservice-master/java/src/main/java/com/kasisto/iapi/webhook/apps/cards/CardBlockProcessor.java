package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.api.model.Account;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.WFAction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.NumberFormat;
import java.util.*;

public class CardBlockProcessor extends AbstractIntentProcessor {

    private Log log = LogFactory.getLog(getClass());


    public static final String CARD_BLOCK_INTENT_NAME = "Card_Block";
    public static final String CARD_UNBLOCK_INTENT_NAME = "Card_UnBlock";


    public static final String FIELD_CARD_NUM = "card_number";
    public static final String FIELD_CARD_CONFIRM = "card_confirm";

    public static final String SYSTEM_EVENT_SELECT_VALID_CARD = "SELECT_CARD_VALID";
    public static final String SYSTEM_EVENT_VALID_CARD_FOR_TOKEN = "SELECT_CARD_VALID_FOR_TOKEN";


    //as used in resource messages with ${x} parameter substitution
    private static final String CARD_LABEL_PARAM = "card_label";
    private static final String BALANCEDUE_PARAM = "balancedue";


    //EAPI
    public SimplifiedEnterpriseApi eapiClient;
    private CardApi cardApi = null;

    public static String OPERATION_BLOCK = "CardBlock";
    public static String OPERATION_UNBLOCK = "CardUnblock";
    private final String operation;
    private final Account.AccountStatusEnum targetAccountType;


    enum PROMPTS {
        PROMPT_CARD_NUM,
        PROMPT_CONFIRM,
        PROMPT_DONE,
        PROMPT_CANCEL,
        PROMPT_CARD_NUM_INVALID_INPUT,
        PROMPT_CARD_NOT_FOUND,
        PROMPT_CARD_ONE_CARD,
        PROMPT_CONFIRM_DIRECT,
        PROMPT_FAIL,
        PROMPT_NO_CARDS
    }


    public CardBlockProcessor(boolean blockMode) {
        if (blockMode) {
            operation = OPERATION_BLOCK;
            targetAccountType = Account.AccountStatusEnum.ACTIVE;
        } else {
            operation = OPERATION_UNBLOCK;
            targetAccountType = Account.AccountStatusEnum.INACTIVE;
        }

        promptResource = ResourceBundle.getBundle(operation);
    }


    private ResourceBundle promptResource;


    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi eapiClient) {
        this.eapiClient = eapiClient;
        cardApi = new CardApi(this.eapiClient);
    }


    @Override
    public boolean isLoginRequired() {
        return false;
    }

    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {

        ConversationResponse cr = new ConversationResponse();
        cr.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        if (action == CardBlockWorkflow.Actions.NO_CARDS) {

            List<MessageContent> messageContentList = new ArrayList<>();
            String responseText = getPrompt(PROMPTS.PROMPT_NO_CARDS);
            MessageContent mc = new MessageContentText(responseText);
            messageContentList.add(mc);

            cr.message_contents = messageContentList;

            if (operation == OPERATION_UNBLOCK) {
                cr.quick_replies.add(new ConversationResponse.QuickReply(ConversationResponse.QuickReply.QUICK_REPLY_TYPE_TEXT, "Block Card", "i want to block my card"));
            } else {
                cr.quick_replies.add(new ConversationResponse.QuickReply(ConversationResponse.QuickReply.QUICK_REPLY_TYPE_TEXT, "Unblock Card", "i want to unblock my card"));

            }

            cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;

        } else if (action == CardBlockWorkflow.Actions.PROMPT_GET_NUM) {

            List<MessageContent> messageContentList = new ArrayList<>();


            //number provided but value not good
            if (!accumulatedInputs.containsKey(FIELD_CARD_NUM)) {
                MessageContent mc = new MessageContentText(getPrompt(PROMPTS.PROMPT_CARD_NUM));
                messageContentList.add((mc));
            } else {
                MessageContent mc = new MessageContentText(getPrompt(PROMPTS.PROMPT_CARD_NUM_INVALID_INPUT));
                messageContentList.add((mc));
            }

            List<Account> cards = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, null);
            RequestUserInput userInput = this.generateCardsQuickReplies(cards);
            cr.request_user_input = userInput;


            cr.message_contents = messageContentList;

        } else if (action == CardBlockWorkflow.Actions.SHOW_CONFIRM) {

            List<MessageContent> messageContentList = new ArrayList<>();


            List<Account> cards = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, accumulatedInputs.get(FIELD_CARD_NUM).value);

            Map<String, String> properties = new HashMap<String, String>();

            if (cards.size() > 0) {
                properties.put(CARD_LABEL_PARAM, getAccountLabel(cards.get(0)));
            }


            String responseText = genText(getPrompt(PROMPTS.PROMPT_CONFIRM), properties);
            MessageContent mc = new MessageContentText(responseText);


            cr.request_user_input = new RequestUserInput(FIELD_CARD_CONFIRM, RequestUserInput.UserInputType.BOOLEAN);
            messageContentList.add((mc));

            cr.message_contents = messageContentList;
        } else if (action == CardBlockWorkflow.Actions.SHOW_CONFIRM_DIRECT) {

            List<MessageContent> messageContentList = new ArrayList<>();


            List<Account> cards = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, accumulatedInputs.get(FIELD_CARD_NUM).value);

            Map<String, String> properties = new HashMap<String, String>();

            if (cards.size() > 0) {
                properties.put(CARD_LABEL_PARAM, getAccountLabel(cards.get(0)));
            }


            String responseText = genText(getPrompt(PROMPTS.PROMPT_CONFIRM_DIRECT), properties);
            MessageContent mc = new MessageContentText(responseText);


            cr.request_user_input = new RequestUserInput(FIELD_CARD_CONFIRM, RequestUserInput.UserInputType.BOOLEAN);
            messageContentList.add((mc));

            cr.message_contents = messageContentList;


        } else if (action == CardBlockWorkflow.Actions.SHOW_CONFIRM_ONE_VALID_NO_INPUT) {
            List<MessageContent> messageContentList = new ArrayList<>();


            List<Account> cards = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, null);

            Map<String, String> properties = new HashMap<String, String>();

            if (cards.size() > 0) {
                properties.put(CARD_LABEL_PARAM, getAccountLabel(cards.get(0)));
            }


            String responseText = genText(getPrompt(PROMPTS.PROMPT_CARD_ONE_CARD), properties);
            MessageContent mc = new MessageContentText(responseText);

            cr.request_user_input = new RequestUserInput(FIELD_CARD_CONFIRM, RequestUserInput.UserInputType.BOOLEAN);
            messageContentList.add((mc));

            cr.message_contents = messageContentList;

        } else if (action == CardBlockWorkflow.Actions.SHOW_CONFIRM_ONE_VALID) {

            List<MessageContent> messageContentList = new ArrayList<>();


            List<Account> cards = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, null);

            //substitute in the available card to block
            Map<String, String> properties = new HashMap<>();
            if (cards.size() > 0) {
                properties.put(CARD_LABEL_PARAM, getAccountLabel(cards.get(0)));
            }

            String responseText = genText(getPrompt(PROMPTS.PROMPT_CARD_NOT_FOUND), properties);
            MessageContent mc = new MessageContentText(responseText);


            cr.request_user_input = new RequestUserInput(FIELD_CARD_CONFIRM, RequestUserInput.UserInputType.BOOLEAN);
            messageContentList.add((mc));

            cr.message_contents = messageContentList;

        } else if (action == CardBlockWorkflow.Actions.SHOW_DONE_OR_CANCEL) {


            List<MessageContent> messageContentList = new ArrayList<>();

            double balanceDue = 0;

            Map<String, String> properties = new HashMap<>();


            if (accumulatedInputs.get(FIELD_CARD_CONFIRM).value.toLowerCase().equals("yes")) {


                boolean cardBlockSuccess = false;
                try {


                    String cardNumToBlock = "";

                    if (accumulatedInputs.containsKey(FIELD_CARD_NUM)) {
                        cardNumToBlock = accumulatedInputs.get(FIELD_CARD_NUM).value;
                    } else {
                        //in situation where user does not provide a card but there is only one card
                        List<Account> accounts = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, null);

                        if (accounts.size() == 1) {
                            cardNumToBlock = accounts.get(0).getAccountNumber();
                        }
                    }


                    if (operation.equals(OPERATION_BLOCK)) {
                        cardBlockSuccess = cardApi.eapiCreditCardBlock(token, cardNumToBlock);
                    } else {
                        cardBlockSuccess = cardApi.eapiCreditCardUnBlock(token, cardNumToBlock);
                    }

                    List<Account> account = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, cardNumToBlock);
                    if (account.size() == 1) {
                        balanceDue = account.get(0).getCurrentBalance();
                    }

                    properties.put(BALANCEDUE_PARAM, "" + getCurrency(balanceDue));

                } catch (ApiException ex) {

                }


                String responseText = null;
                if (cardBlockSuccess) {
                    responseText = genText(getPrompt(PROMPTS.PROMPT_DONE), properties);
                } else {
                    responseText = genText(getPrompt(PROMPTS.PROMPT_FAIL), properties);
                }
                MessageContent mc = new MessageContentText(responseText);

                messageContentList.add(mc);
            } else {
                MessageContent mc = new MessageContentText(getPrompt(PROMPTS.PROMPT_CANCEL));
                messageContentList.add((mc));
            }


            cr.message_contents = messageContentList;
            cr.conversation_state = ConversationResponse.ConversationState.COMPLETED;
        }

        return cr;
    }


    public RequestUserInput generateCardsQuickReplies(List<Account> cards) {

        List<RequestUserInput.QuickReplyOption> options = new ArrayList<>();
        for (Account card : cards) {
            options.add(new RequestUserInput.QuickReplyOption(card.getAccountNumber(), getAccountLabel(card)));
        }

        RequestUserInput requestUserInput = new RequestUserInput(FIELD_CARD_NUM, RequestUserInput.UserInputType.NUMBER, options);
        return requestUserInput;
    }


    @Override
    public void updatePreconditions(ConversationSession session) {


        //populate with information about cards not existing


        String token = session.token;

        Map<String, SystemInput> systemInputs = session.getSystemInputs();


        List<Account> allCardsForToken = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, null);


        systemInputs.put(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN, new SystemInput(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN, "" + allCardsForToken.size()));

        if (session.getCurrentUserInputs().containsKey(FIELD_CARD_NUM)) {

            List<Account> cardForNumber = cardApi.getAccounts(token, Account.AccountTypeEnum.CREDIT_CARD, targetAccountType, session.getCurrentUserInputs().get(FIELD_CARD_NUM).value);

            if (cardForNumber.size() > 0) {

                systemInputs.put(SYSTEM_EVENT_SELECT_VALID_CARD, new SystemInput(SYSTEM_EVENT_SELECT_VALID_CARD, "true"));

            } else {
                systemInputs.put(SYSTEM_EVENT_SELECT_VALID_CARD, new SystemInput(SYSTEM_EVENT_SELECT_VALID_CARD, "false"));

            }


        }

    }


    public String getAccountLabel(Account account) {
        return account.getAccountName() + "(" + account.getAccountNumber().substring(account.getAccountNumber().length() - 4) + ")";
    }

    public String getCurrency(double money) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
        String moneyString = formatter.format(money);
        return moneyString;
    }

    public String getPrompt(PROMPTS aprompt) {

        String promptName = operation.toUpperCase() + "_" + aprompt.name();

        return promptResource.getString(promptName);

    }

}
