package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFState;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;

import java.util.ArrayList;
import java.util.List;

import static com.kasisto.iapi.webhook.apps.cards.CardBlockProcessor.*;

public class CardBlockWorkflow extends Workflow {


    public enum States implements WFState {
        START, END, PROMPT_NUM, CONFIRM
    }

    public enum Actions implements WFAction {

        PROMPT_GET_NUM, SHOW_CONFIRM,
        SHOW_DONE_OR_CANCEL,
        //user only has one valid card, but user *provides* a different input
        SHOW_CONFIRM_ONE_VALID,
        //user only has one valid card, but user does not ask for a specific card
        SHOW_CONFIRM_ONE_VALID_NO_INPUT,
        SHOW_CONFIRM_DIRECT,
        NO_CARDS
    }

    @Override
    public List<WFTransition> generateTransitions() {
        List<WFTransition> transitions = new ArrayList<>();

        //no user input (assumes there is a card for user) OR
        //user provides an invalid number but there are multiple cards
        transitions.add(new WFTransition(Actions.PROMPT_GET_NUM, States.START, States.PROMPT_NUM, event ->
        {
            return

                    (!event.hasUserInput(FIELD_CARD_NUM) && Integer.parseInt(event.getSysInputVal(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN)) > 1)
                            ||
                            (event.hasUserInput(FIELD_CARD_NUM) &&
                                    (event.getSysInputVal(SYSTEM_EVENT_SELECT_VALID_CARD).equals("false") &&
                                            Integer.parseInt(event.getSysInputVal(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN)) > 1
                                    ));
        }));

        //user provides a card number and it is a valid card
        transitions.add(new WFTransition(Actions.SHOW_CONFIRM_DIRECT, States.START, States.CONFIRM, event ->
        {
            return
                    (event.hasUserInput(FIELD_CARD_NUM) && (
                            (event.getSysInputVal(SYSTEM_EVENT_SELECT_VALID_CARD).equals("true"))
                    ));


        }));


        //user provides a card number and it is a valid card
        transitions.add(new WFTransition(Actions.SHOW_CONFIRM_ONE_VALID, States.START, States.CONFIRM, event ->
        {
            return
                    (event.hasUserInput(FIELD_CARD_NUM) && (
                            (event.getSysInputVal(SYSTEM_EVENT_SELECT_VALID_CARD).equals("false") &&
                                    Integer.parseInt(event.getSysInputVal(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN)) == 1)

                    ));


        }));

        //user provides a card number and it is a valid card
        transitions.add(new WFTransition(Actions.SHOW_CONFIRM_ONE_VALID_NO_INPUT, States.START, States.CONFIRM, event ->
        {
            return
                    (!event.hasUserInput(FIELD_CARD_NUM) && (
                            (Integer.parseInt(event.getSysInputVal(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN)) == 1)

                    ));
        }));


        transitions.add(new WFTransition(Actions.SHOW_CONFIRM, States.PROMPT_NUM, States.CONFIRM, event ->
        {
            return event.hasUserInput(FIELD_CARD_NUM) && event.getSysInputVal(SYSTEM_EVENT_SELECT_VALID_CARD).equals("true");
        }));
        transitions.add(new WFTransition(Actions.SHOW_DONE_OR_CANCEL, States.CONFIRM, States.END, event ->
        {
            return event.hasUserInput(FIELD_CARD_CONFIRM);
        }));

        transitions.add(new WFTransition(Actions.NO_CARDS, States.START, States.END, event ->
        {
            return (Integer.parseInt(event.getSysInputVal(SYSTEM_EVENT_VALID_CARD_FOR_TOKEN)) < 1);
        }));

        return transitions;

    }

    @Override
    public WFState getOrigin() {
        return States.START;
    }
}
