package com.kasisto.iapi.webhook.apps.greetings;

import com.kasisto.api.model.Customer;
import com.kasisto.api.model.CustomerRequest;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.workflow.SingleStepWorkflow;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.*;

public class GreetingsIntentProcessor extends AbstractIntentProcessor {

    public static final String GREETINGS_INTENT_NAME = "greetings";

    public SimplifiedEnterpriseApi eapiClient;


    private static final String FIRST_NAME = "first_name";

    //Dialog Prompts
    private static ResourceBundle promptResource = ResourceBundle.getBundle(GREETINGS_INTENT_NAME);
    private static List<String> prompts;
    private String eapiSecret;
    private Random rand = new Random();

    static {
        prompts = new ArrayList<String>();
        for (String akey : promptResource.keySet()) {
            prompts.add(promptResource.getString(akey));
        }
    }


    @Override
    public boolean isLoginRequired() {
        return false;
    }

    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi client) {
        this.eapiClient = client;
        this.eapiSecret = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_SECRET_PROPERTY_NAME);
    }

    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {

        CustomerRequest custRequest = new CustomerRequest();
        Customer customer = null;

        try {
            customer = eapiClient.customer(eapiSecret, token, custRequest, new HashMap<>());
        } catch (ApiException e) {
            e.printStackTrace();
        }


        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        Map<String, String> properties = new HashMap<>();
        if (action == SingleStepWorkflow.Actions.SHOW_ANSWER) {
            String name = "";
            if (customer != null) {
                name = customer.getFirstName();
                properties.put(FIRST_NAME, name);
            }

            String arandomPrompt = prompts.get(rand.nextInt(prompts.size()));
            response.message_contents.add(new MessageContentText(genText(arandomPrompt, properties)));
        }

        return response;
    }
}