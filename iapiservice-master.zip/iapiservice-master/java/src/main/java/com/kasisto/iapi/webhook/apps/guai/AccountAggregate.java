package com.kasisto.iapi.webhook.apps.guai;

public class AccountAggregate {

    public double getCreditTotal() {
        return creditTotal;
    }

    public void setCreditTotal(double creditTotal) {
        this.creditTotal = creditTotal;
    }

    public double getDebitTotal() {
        return debitTotal;
    }

    public void setDebitTotal(double debitTotal) {
        this.debitTotal = debitTotal;
    }


    private double creditTotal;
    private double debitTotal;


}
