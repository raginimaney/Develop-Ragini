package com.kasisto.iapi.webhook.apps.guai;

import com.kasisto.api.model.Account;
import com.kasisto.api.model.Account.AccountTypeEnum;
import com.kasisto.api.model.AccountsRequest;
import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.IapiEnvConf;
import com.kasisto.iapi.webhook.core.eapi.ApiException;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.*;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * A controller for GUAI Intent
 *
 * @author jon.phillips
 */
public class GUAIIntentProcessor extends AbstractIntentProcessor {

    public static final String GUAI_INTENT_NAME = "GUAI";
    /**
     * The list of fields to be captured by the intent
     */
    public static final String FIELD_ACCOUNT_NICK_NAME = "GUAI_AccountNickName";
    public static final String FIELD_ACCOUNT_BANK_NAME = "GUAI_AccountBankName";
    public static final String FIELD_ACCOUNT_ID = "GUAI_AccountId";
    public static final String FIELD_AGG = "GUAI_Agg";

    public static final String VAL_FIELD_AGG_TOTAL = "total";


    public static final String FIELD_ACCOUNT_TYPE = "GUAI_AccountType";

    static final String CONFIRM_SUBMISSION = "confirm_submission";
    public static final String CONFIRM_BREAKDOWN = "confirm_breakdown";

    private SimplifiedEnterpriseApi eapiClient;

    private String eapiSecret;

    public void setSimplifiedEnterpriseApiClient(SimplifiedEnterpriseApi client) {

        this.eapiSecret = IapiEnvConf.getInstance().getPropertyOrDefault(IapiEnvConf.EAPI_SECRET_PROPERTY_NAME);
        this.eapiClient = client;
    }

    /**
     * The intent asks for the user confirmation before the final submission
     */

    /**
     * Constructor of the intent
     */
    public GUAIIntentProcessor() {

    }

    /**
     * Method to check if the user needs to be authenticated to start the intent
     * input.
     */
    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction wfAction, String userId, String token, Map<String, UserInput> userInputs, Map<String, SystemInput> systemInputs, Context context) {


        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        if (wfAction == GUAIWorkflow.Actions.ACCOUNT_LIST) {

            AccountTypeEnum accountType = AccountTypeEnum.UNSPECIFIED;

            if (userInputs.containsKey(FIELD_ACCOUNT_TYPE)) {
                accountType = AccountTypeEnum.valueOf(userInputs.get(FIELD_ACCOUNT_TYPE).value.toUpperCase());
            }

            List<Account> accounts = getAccounts(userId, token, accountType);
            response = constructAccountResponse(accounts);

        } else if (wfAction == GUAIWorkflow.Actions.BREAKDOWN) {


            AccountTypeEnum accountType = AccountTypeEnum.UNSPECIFIED;

            if (userInputs.containsKey(FIELD_ACCOUNT_TYPE)) {
                accountType = AccountTypeEnum.valueOf(userInputs.get(FIELD_ACCOUNT_TYPE).value.toUpperCase());
            }

            List<Account> accounts = getAccounts(userId, token, accountType);
            response = constructAggregate(accounts);

        } else if (wfAction == GUAIWorkflow.Actions.GOODBYE) {

            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
            response.message_contents.add(new MessageContentText("Okay.  I won't break it down"));
        }

        return response;

    }

    private ConversationResponse constructAggregate(
            List<Account> accounts) {

        AccountAggregate agg = GUAIIntentProcessor.doAccountAggregation(accounts);

        List<MessageContent> options = new ArrayList<>();

        options.add(new MessageContentCard("You have:", "" + agg.getCreditTotal()));
        options.add(new MessageContentCard("You owe:", "" + agg.getDebitTotal()));

        MessageContentContainer container = new MessageContentContainer(MessageContentContainer.MSG_CONTAINER_LIST,
                options);
        RequestUserInput input = new RequestUserInput(CONFIRM_BREAKDOWN, RequestUserInput.UserInputType.BOOLEAN);

        ConversationResponse response = new ConversationResponse();
        response.message_contents.add(container);
        response.message_contents.add(new MessageContentText("Do you want to break it down?"));
        response.request_user_input = input;

        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        return response;
    }

    /**
     * build the carousel for the accounts
     *
     * @param accounts
     * @return
     */
    private ConversationResponse constructAccountResponse(
            List<Account> accounts) {


        ConversationResponse response = new ConversationResponse();
        if (accounts.size() == 0) {
            response.message_contents.add(new MessageContentText("No accounts match."));
        } else {
            List<MessageContent> options = new ArrayList<>();

            for (Account account : accounts) {
                options.add(new MessageContentCard(account.getAccountName(), "" + account.getCurrentBalance()));
            }

            MessageContentContainer container = new MessageContentContainer(MessageContentContainer.MSG_CONTAINER_LIST,
                    options);
            response.message_contents.add(container);
        }

        response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
        return response;
    }


    public static AccountAggregate doAccountAggregation(List<Account> accounts) {

        double creditTotal = accounts.stream()
                .mapToDouble(x -> x.getAvailableBalance() != null ? x.getAvailableBalance() : 0).sum();
        double debitTotal = accounts.stream()
                .mapToDouble(x -> x.getPaymentDueAmount() != null ? x.getPaymentDueAmount() : 0).sum();

        AccountAggregate agg = new AccountAggregate();
        agg.setCreditTotal(creditTotal);
        agg.setDebitTotal(debitTotal);

        return agg;
    }

    /*
     * Note, this filtering must account at the app/webhook level because the EAPI
     * is not responsible for account filtering
     */
    public List<Account> getAccounts(String userid, String token, AccountTypeEnum accountType) {

        AccountsRequest ar = new AccountsRequest();
        Map<String, String> responseHeaders = new HashMap<String, String>();

        List<Account> accounts = new ArrayList<>();
        try {
            accounts = eapiClient.accounts(eapiSecret, token, ar, responseHeaders);
        } catch (ApiException e) {
            e.printStackTrace();
        }

        if (accountType == AccountTypeEnum.UNSPECIFIED) {
            return accounts;
        }

        List<Account> filterAccounts = accounts.stream().filter(x -> x.getAccountType().equals(accountType))
                .collect(Collectors.toList());
        return filterAccounts;
    }


}
