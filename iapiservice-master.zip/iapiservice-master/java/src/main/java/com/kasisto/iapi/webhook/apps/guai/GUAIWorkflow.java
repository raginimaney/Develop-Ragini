package com.kasisto.iapi.webhook.apps.guai;


import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFState;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;

import java.util.ArrayList;
import java.util.List;

public class GUAIWorkflow extends Workflow {


    enum States implements WFState {
        START, END, AGGREGATE
    }

    enum Actions implements WFAction {

        GOODBYE, ACCOUNT_LIST, BREAKDOWN
    }


    @Override
    public WFState getOrigin() {
        return States.START;
    }


    @Override
    public List<WFTransition> generateTransitions() {

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.BREAKDOWN, States.START, States.AGGREGATE, event -> {

            String agg = event.getVal(GUAIIntentProcessor.FIELD_AGG);
            return agg != null && agg.equals(GUAIIntentProcessor.VAL_FIELD_AGG_TOTAL);

        }));


        transitions.add(new WFTransition(Actions.ACCOUNT_LIST, States.START, States.START, event -> {

            String agg = event.getVal(GUAIIntentProcessor.FIELD_AGG);
            return (agg == null);

        }));


        transitions.add(new WFTransition(Actions.ACCOUNT_LIST, States.START, States.END, event -> {

            //if not aggregate then go here
            String agg = event.getVal(GUAIIntentProcessor.FIELD_AGG);
            return (agg == null);

        }));

        //list the break down of accounts
        transitions.add(new WFTransition(Actions.ACCOUNT_LIST, States.AGGREGATE, States.END, event -> {

            String confirm = event.getVal(GUAIIntentProcessor.CONFIRM_BREAKDOWN);
            return confirm != null && (confirm.equals("yes"));
        }));


        //don't break it down, just say goodbye
        transitions.add(new WFTransition(Actions.GOODBYE, States.AGGREGATE, States.END, event -> {

            String confirm = event.getVal(GUAIIntentProcessor.CONFIRM_BREAKDOWN);
            return confirm != null && (confirm.equals("no"));
        }));


        return transitions;
    }


}
