package com.kasisto.iapi.webhook.apps.insights;

import java.util.List;


/***
 * Corresponds to an interface to the insights.  implementations could be backed by MoneyThor
 *
 * Open question is whether this API should sit in front of EAPI (/customer_action)
 * @author jon
 *
 */
public interface InsightsApi {


    List<InsightsBudget> getBudgets(String userid, String category);

    List<InsightsGoal> getGoals(String userid);

    InsightsForecast getForecasts(String userid);

    boolean addBudget(InsightsBudget budget);


}
