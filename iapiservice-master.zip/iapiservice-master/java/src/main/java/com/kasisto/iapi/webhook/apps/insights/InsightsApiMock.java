package com.kasisto.iapi.webhook.apps.insights;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class InsightsApiMock implements InsightsApi {

    static List<InsightsBudget> budgets;
    static List<InsightsGoal> goals;
    static List<InsightsForecast> forecasts;


    static {
        budgets = new ArrayList<InsightsBudget>();
        budgets.add(new InsightsBudget("1", "1", "100%", "900", "200", InsightsBudget.ENTERTAINMENT_CATEGORY));
        budgets.add(new InsightsBudget("2", "1", "100%", "900", "100", InsightsBudget.FOOD_CATEGORY));
        budgets.add(new InsightsBudget("3", "2", "10%", "120", "700", InsightsBudget.ENTERTAINMENT_CATEGORY));
        budgets.add(new InsightsBudget("4", "2", "20%", "320", "500", InsightsBudget.FOOD_CATEGORY));

        goals = new ArrayList<InsightsGoal>();
        goals.add(new InsightsGoal("1", "1", "100%", "900", "1/20/2019"));
        goals.add(new InsightsGoal("2", "1", "100%", "900", "3/4/2019"));
        goals.add(new InsightsGoal("3", "2", "10%", "120", "10/1/2019"));
        goals.add(new InsightsGoal("4", "2", "20%", "320", "11/2/2019"));

        forecasts = new ArrayList<InsightsForecast>();
        forecasts.add(new InsightsForecast("1", "1", "active", 100, 900));
        forecasts.add(new InsightsForecast("2", "1", "active", 100, 900));
        forecasts.add(new InsightsForecast("3", "2", "active", 100, 900));
        forecasts.add(new InsightsForecast("4", "2", "active", 100, 900));


    }


    @Override
    public List<InsightsBudget> getBudgets(String userid, String category) {


        List<InsightsBudget> filterBudgets = new ArrayList<InsightsBudget>();

        if (category != null) {
            filterBudgets = budgets.stream().filter(x -> x.user_id.equals(userid)).filter(x -> x.category.equals(category)).collect(Collectors.toList());
        } else {
            filterBudgets = budgets.stream().filter(x -> x.user_id.equals(userid)).collect(Collectors.toList());
        }
        return filterBudgets;
    }


    @Override
    public List<InsightsGoal> getGoals(String userid) {
        List<InsightsGoal> filterGoals = goals.stream().filter(x -> x.user_id.equals(userid)).collect(Collectors.toList());
        return filterGoals;
    }

    @Override
    public boolean addBudget(InsightsBudget budget) {

        budgets.add(budget);
        return true;
    }


    @Override
    public InsightsForecast getForecasts(String userid) {

        //only return the first forecast that matches the user
        //there should only be one forecast
        List<InsightsForecast> filterForecasts = forecasts.stream().filter(x -> x.user_id.equals(userid)).collect(Collectors.toList());
        return filterForecasts.get(0);
    }


}
