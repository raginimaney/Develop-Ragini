package com.kasisto.iapi.webhook.apps.insights;

import java.util.HashSet;
import java.util.Set;

public class InsightsBudget {

    String id;
    String user_id;
    String status;
    String amount;
    String amountSpent;
    String category;

    public static final String FOOD_CATEGORY = "food";
    public static final String ENTERTAINMENT_CATEGORY = "entertainment";


    public static Set<String> validCategories = new HashSet<String>();

    static {
        validCategories.add(FOOD_CATEGORY);
        validCategories.add(ENTERTAINMENT_CATEGORY);
    }

    public InsightsBudget(String id, String user_id, String status, String amount, String amountSpent, String category) {
        super();
        this.id = id;
        this.user_id = user_id;
        this.status = status;
        this.amount = amount;
        this.category = category;
        this.amountSpent = amountSpent;
    }

    @Override
    public String toString() {
        return "\n[InsightsBudget\n" + "\tid: $id\n" + "\tuser_id: $id\n" + "\tcategory: $category\n"
                + "\tamount: $amount\n" + "\tamount_spent: $amountSpent\n" + "\tstatus: $status\n]";
    }
}
