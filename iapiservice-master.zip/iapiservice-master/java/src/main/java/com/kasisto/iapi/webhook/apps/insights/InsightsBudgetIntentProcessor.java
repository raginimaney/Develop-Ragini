package com.kasisto.iapi.webhook.apps.insights;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentRef;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * A controller for Insights for Budget usecase:
 * <p>
 * 1) Category (food, entertainment) 2) Amount
 *
 * @author jon.phillips
 */
public class InsightsBudgetIntentProcessor extends AbstractIntentProcessor {

    public static final String IB_INTENT_NAME = "Insights_Budget";
    /**
     * The list of fields to be captured by the intent
     */
    public static final String FIELD_CATEGORY = "IB_Category";
    public static final String FIELD_AMOUNT = "IB_Amount";
    public static final String FIELD_ACTION = "IB_Action";


    public static final String ACTION_SET = "set";
    public static final String ACTION_VIEW = "view";

    public static final String CONFIRM_SUBMISSION = "confirm_submission";

    private InsightsApi insightsApi;

    public InsightsBudgetIntentProcessor() {
        this.insightsApi = new InsightsApiMock();
    }

    /**
     * Method to check if the user needs to be authenticated to start the intent
     * input.
     */
    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction wfAction, String userId, String token, Map<String, UserInput> userInput, Map<String, SystemInput> systemInputs, Context context) {


        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        if (wfAction == InsightsWorkflow.Actions.SELECT_ACTION) {

            RequestUserInput.QuickReplyOption[] qr = new RequestUserInput.QuickReplyOption[]{new RequestUserInput.QuickReplyOption(ACTION_VIEW, "View"),
                    new RequestUserInput.QuickReplyOption(ACTION_SET, "Set")};

            List<RequestUserInput.QuickReplyOption> options = Arrays.asList(qr);

            response.request_user_input = new RequestUserInput(FIELD_ACTION, RequestUserInput.UserInputType.STRING, options);
            response.message_contents.add(new MessageContentText(genText("Do you want to set or view budgets?", userInput.values())));

        } else if (wfAction == InsightsWorkflow.Actions.GET_BUDGETID) {

            String category = null;
            if (userInput.containsKey(FIELD_CATEGORY)) {
                category = userInput.get(FIELD_CATEGORY).value;
            }

            // replace fixed token with
            List<InsightsBudget> budgets = insightsApi.getBudgets("1", category);

            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;

            response.message_contents.add(InsightsCtaGenerator.ctaFromBudgetsMessageOnly(budgets));

        } else if (wfAction == InsightsWorkflow.Actions.SHOW_BUDGET) {

            String category = null;
            if (userInput.containsKey(FIELD_CATEGORY)) {
                category = userInput.get(FIELD_CATEGORY).value;
            }

            // replace fixed token with
            List<InsightsBudget> budgets = insightsApi.getBudgets("1", category);

            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;

            response.message_contents.add(InsightsCtaGenerator.ctaFromBudgetsMessageOnly(budgets));

        } else if (wfAction == InsightsWorkflow.Actions.GET_CATEGORY) {

            //ask user for categories;
            response.request_user_input = new RequestUserInput(FIELD_CATEGORY, RequestUserInput.UserInputType.STRING);
            response.message_contents.add(new MessageContentText(genText("What is the category for the budget", userInput.values())));

        } else if (wfAction == InsightsWorkflow.Actions.GET_CATEGORY_WITH_CORRECTION) {

            //ask user for categories;
            response.request_user_input = new RequestUserInput(FIELD_CATEGORY, RequestUserInput.UserInputType.STRING);
            response.message_contents.add(new MessageContentText(genText("Not a valid category. What is the category for the budget", userInput.values())));

        } else if (wfAction == InsightsWorkflow.Actions.GET_AMOUNT) {

            response.request_user_input = new RequestUserInput(FIELD_AMOUNT, RequestUserInput.UserInputType.NUMBER);
            response.message_contents.add(new MessageContentText(genText("What is the amount you want to set for the budget", userInput.values())));

        } else if (wfAction == InsightsWorkflow.Actions.GET_CONFIRM) {

            //ask user to confirm
            response.request_user_input = new RequestUserInput(CONFIRM_SUBMISSION, RequestUserInput.UserInputType.BOOLEAN);
            response.message_contents.add(new MessageContentText(genText("Let's confirm, you want to set a budget for category ${"
                    + FIELD_CATEGORY + "} for an amount of ${" + FIELD_AMOUNT + "}", userInput.values())));

        } else if (wfAction == InsightsWorkflow.Actions.GOODBYE_NOSAVE) {

            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
            // Submit the form to the backend and build the response
            //use a ctaid
            response.message_contents.add(new MessageContentRef("FAQ1"));
            //  response.message_contents.add(new MessageContentText(genText(
            //        "No Budget Set",
            //      userInput.values())));
        } else if (wfAction == InsightsWorkflow.Actions.GOODBYE) {

            //tell user success or failure
            InsightsBudget newBudget = new InsightsBudget("" + new Random().nextInt(100000), "1", "0%",
                    userInput.get(FIELD_AMOUNT).value, "0", userInput.get(FIELD_CATEGORY).value);

            boolean status = insightsApi.addBudget(newBudget);

            if (!status) {

                response.conversation_state = ConversationResponse.ConversationState.FAILED;
                response.message_contents.add((new MessageContentText(genText("I failed to create a new budget for category ${"
                        + FIELD_CATEGORY + "} for amount of ${" + FIELD_AMOUNT + "}", userInput.values()))));
            } else {
                response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
                // Submit the form to the backend and build the response
                response.message_contents.add(new MessageContentText(genText(
                        "I set a budget for category ${" + FIELD_CATEGORY + "} for amount of ${" + FIELD_AMOUNT + "}",
                        userInput.values())));
            }
        }


        return response;
    }

}
