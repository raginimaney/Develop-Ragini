package com.kasisto.iapi.webhook.apps.insights;

import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentCard;
import com.kasisto.iapi.webhook.core.model.response.MessageContentContainer;

import java.util.ArrayList;
import java.util.List;

public class InsightsCtaGenerator {


    public static MessageContent ctaFromBudgetsMessageOnly(List<InsightsBudget> budgets) {

        List<MessageContent> options = new ArrayList<>();

        for (int i = 0; i < budgets.size(); i++) {
            options.add(new MessageContentCard(budgets.get(i).category, "Budget: " + budgets.get(i).amount + ",+Spent:" + budgets.get(i).amountSpent, new MessageContentCard.Medium("https://www.wpclipart.com/office/chart_graph/bar_chart_2.png")));

        }

        MessageContentContainer container = new MessageContentContainer(MessageContentContainer.MSG_CONTAINER_CAROUSEL, options);
        return container;

    }


}
