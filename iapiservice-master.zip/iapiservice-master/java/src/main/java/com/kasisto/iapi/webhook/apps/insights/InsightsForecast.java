package com.kasisto.iapi.webhook.apps.insights;

public class InsightsForecast {

    String id;
    String user_id;
    double income;
    double payments;

    public InsightsForecast(String id, String user_id, String status, double income, double payments) {
        super();
        this.id = id;
        this.user_id = user_id;
        this.payments = payments;
        this.income = income;
    }

    @Override
    public String toString() {
        return "\n[InsightsBudget\n" + "\tid: $id\n" + "\tuser_id: $id\n" + "\tcategory: $category\n"
                + "\tamount: $amount\n" + "\tstatus: $status\n]";
    }
}
