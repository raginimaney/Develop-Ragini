package com.kasisto.iapi.webhook.apps.insights;

public class InsightsGoal {

    String id;
    String user_id;
    String status;
    String amount;
    String date;


    public InsightsGoal(String id, String user_id, String status, String amount, String date) {
        super();
        this.id = id;
        this.user_id = user_id;
        this.status = status;
        this.amount = amount;
        this.date = date;
    }

    @Override
    public String toString() {
        return "\n[InsightsBudget\n" + "\tid: $id\n" + "\tuser_id: $id\n" + "\tdate: $date\n"
                + "\tamount: $amount\n" + "\tstatus: $status\n]";
    }
}
