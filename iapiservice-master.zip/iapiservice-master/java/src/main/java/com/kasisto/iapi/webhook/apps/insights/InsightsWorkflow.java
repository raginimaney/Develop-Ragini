package com.kasisto.iapi.webhook.apps.insights;

import com.kasisto.iapi.webhook.core.workflow.WFAction;
import com.kasisto.iapi.webhook.core.workflow.WFState;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;

import java.util.ArrayList;
import java.util.List;

public class InsightsWorkflow extends Workflow {


    //the workflow states
    public enum States implements WFState {
        START, END, SELECT_BUDGET, CATEGORY, AMOUNT, CONFIRM
    }


    /*the 'transducer' side-effects, corresponding to the prompt to the user
    note the effects don't have a 1:1 relationship to the wf-states
    including the possibility that you can have two transitions between the same start/end states
    with a different action, depending on the condition(input)
    */
    enum Actions implements WFAction {
        SELECT_ACTION, GET_BUDGETID, GET_CATEGORY, GET_AMOUNT, GET_CONFIRM, GOODBYE, GOODBYE_NOSAVE, SHOW_BUDGET, GET_CATEGORY_WITH_CORRECTION
    }


    public WFState getOrigin() {
        return States.START;
    }


    @Override
    public List<WFTransition> generateTransitions() {

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.SELECT_ACTION, States.START, States.START, event -> {

            //no action specified
            String action = event.getVal(InsightsBudgetIntentProcessor.FIELD_ACTION);
            return action == null;

        }));

        transitions.add(new WFTransition(Actions.GET_CATEGORY, States.START, States.CATEGORY, event -> {


            String action = event.getVal(InsightsBudgetIntentProcessor.FIELD_ACTION);
            String category = event.getVal(InsightsBudgetIntentProcessor.FIELD_CATEGORY);

            return category == null && (action != null && action.equals("set"));

        }));

        transitions.add(new WFTransition(Actions.GET_BUDGETID, States.START, States.SELECT_BUDGET, event -> {

            String action = event.getVal(InsightsBudgetIntentProcessor.FIELD_ACTION);
            return action != null && action.equals("view");

        }));

        transitions.add(new WFTransition(Actions.GET_AMOUNT, States.START, States.AMOUNT, event -> {

            String action = event.getVal(InsightsBudgetIntentProcessor.FIELD_ACTION);
            String category = event.getVal(InsightsBudgetIntentProcessor.FIELD_CATEGORY);
            return action != null && category != null && ((action.equals("set") && InsightsBudget.validCategories.contains(category)));
        }));


        transitions.add(new WFTransition(Actions.GET_AMOUNT, States.CATEGORY, States.AMOUNT, event -> {

            String category = event.getVal(InsightsBudgetIntentProcessor.FIELD_CATEGORY);
            return category != null && (InsightsBudget.validCategories.contains(category));
        }));


        //user enters an invalid category
        transitions.add(new WFTransition(Actions.GET_CATEGORY_WITH_CORRECTION, States.CATEGORY, States.CATEGORY, event -> {

            String category = event.getVal(InsightsBudgetIntentProcessor.FIELD_CATEGORY);
            return category != null && (!InsightsBudget.validCategories.contains(category));
        }));

        transitions.add(new WFTransition(Actions.GET_CONFIRM, States.AMOUNT, States.CONFIRM, event -> {

            double value = event.getValAsDouble(InsightsBudgetIntentProcessor.FIELD_AMOUNT);
            return (value > 0);
        }));

        transitions.add(new WFTransition(Actions.GOODBYE, States.CONFIRM, States.END, event -> {

            String value = event.getVal(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION);
            return (value.equals("yes"));
        }));

        transitions.add(new WFTransition(Actions.GOODBYE_NOSAVE, States.CONFIRM, States.END, event -> {

            String value = event.getVal(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION);
            return (value.equals("no"));
        }));

        return transitions;

    }


}
