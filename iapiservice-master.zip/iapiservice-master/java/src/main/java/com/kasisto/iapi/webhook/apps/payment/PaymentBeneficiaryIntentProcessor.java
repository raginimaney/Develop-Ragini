package com.kasisto.iapi.webhook.apps.payment;

public class PaymentBeneficiaryIntentProcessor extends PaymentGeneralIntentProcessor {


    public static final String PREFIX = "BENEFIT";


    void setAnswers(){
        this.setAnswersForPrefix(PREFIX);
    }

    public static final String PAYMENT_BEN_INTENT_NAME = "payment_beneficiary";
}
