package com.kasisto.iapi.webhook.apps.payment;

public class PaymentBenficiaryWorkflow extends PaymentGeneralWorkflow {
    public static final String PAYMENT_INTENT_NAME = "payment_cancel";
}
