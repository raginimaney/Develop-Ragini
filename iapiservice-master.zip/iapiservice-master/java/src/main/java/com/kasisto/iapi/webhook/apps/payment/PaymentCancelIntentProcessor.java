package com.kasisto.iapi.webhook.apps.payment;

public class PaymentCancelIntentProcessor extends PaymentGeneralIntentProcessor {

    public static final String PAYMENT_CANCEL_INTENT_NAME = "payment_cancel";


    public static final String PREFIX = "CANCEL";

    void setAnswers(){
        this.setAnswersForPrefix(PREFIX);
    }

}