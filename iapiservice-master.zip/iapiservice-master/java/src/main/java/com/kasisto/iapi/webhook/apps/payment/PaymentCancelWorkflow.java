package com.kasisto.iapi.webhook.apps.payment;

public class PaymentCancelWorkflow extends PaymentGeneralWorkflow {
    public static final String PAYMENT_INTENT_NAME = "payment_beneficiary";
}
