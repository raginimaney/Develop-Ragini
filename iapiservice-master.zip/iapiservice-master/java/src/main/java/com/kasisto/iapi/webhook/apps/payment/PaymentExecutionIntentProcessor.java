package com.kasisto.iapi.webhook.apps.payment;

public class PaymentExecutionIntentProcessor extends PaymentGeneralIntentProcessor {


    public static final String PREFIX = "EXEC";

    public static final String PAYMENT_EXEC_INTENT_NAME = "payment_execution";

    void setAnswers(){
        this.setAnswersForPrefix(PREFIX);
    }
}