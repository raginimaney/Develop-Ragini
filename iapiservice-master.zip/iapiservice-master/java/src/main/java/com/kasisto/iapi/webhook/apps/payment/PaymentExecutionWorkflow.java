package com.kasisto.iapi.webhook.apps.payment;

public class PaymentExecutionWorkflow extends PaymentGeneralWorkflow {

    public static final String PAYMENT_INTENT_NAME = "payment_execution";

}
