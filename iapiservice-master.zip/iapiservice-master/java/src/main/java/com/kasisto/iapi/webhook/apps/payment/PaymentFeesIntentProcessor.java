package com.kasisto.iapi.webhook.apps.payment;

public class PaymentFeesIntentProcessor extends PaymentGeneralIntentProcessor {

    public static final String PREFIX = "FEES";


    void setAnswers(){
        this.setAnswersForPrefix(PREFIX);
    }

    public static final String PAYMENT_FEES_INTENT_NAME = "payment_fees";
}
