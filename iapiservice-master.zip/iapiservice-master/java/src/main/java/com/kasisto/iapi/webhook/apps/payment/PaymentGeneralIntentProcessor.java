package com.kasisto.iapi.webhook.apps.payment;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.WFAction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


public abstract class PaymentGeneralIntentProcessor extends AbstractIntentProcessor {
    private Log log = LogFactory.getLog(getClass());

    public static final String FIELD_PAYMENT_TYPE = "PaymentType";
    public static final String FIELD_MERCHANT_TYPE = "MerchantType";
    public static final String FIELD_COUNTRY_TYPE = "CountryType";


    //public static String CLARIFY_CTA = "";
    public static String LOCAL_ANSWER = "";
    public static String INTERNATIONAL_ANSWER = "";
    public static String SOCIAL_ANSWER = "";
    public static String BILL_ANSWER = "";


    public static List<String> DEFAULT_LOCAL_COUNTRIES = Arrays.asList("denmark");
    public static List<String> DEFAULT_ALL_COUNTRIES = Arrays.asList("india", "uae", "spain", "france", "denmark");
    public static List<String> DEFAULT_MERCHANTS = Arrays.asList("abcd", "efgh");

    public List<String> localCountries =DEFAULT_LOCAL_COUNTRIES;
    public List<String> allCountries =DEFAULT_ALL_COUNTRIES;
    public List<String> allMerchants = DEFAULT_MERCHANTS;


    public static final String VALID_INPUT="VALID_INPUT";

    public enum PaymentType{

        LOCAL("Local Transfer", new String[]{"local", "in-country"}), INTERNATIONAL("International Transfer",new String[]{"international"}),
        SOCIAL("Social Transfer",new String[]{"social", "p2p"}), BILL ("Bill Payment", new String[]{"bill"});

        private String label;
        private List<String> aliases;
        PaymentType(String label, String[] aliases){
            this.label = label;
            this.aliases = Arrays.asList(aliases);
        }

    }

    public enum PROMPTS {
        PROMPT_TYPE_PAYMENT
    }

    public void setLocalCountries(List<String> localCountries) {
        this.localCountries = localCountries;
    }

    public void setAllCountries(List<String> allCountries) {
        this.allCountries = allCountries;
    }


    public void setAllMerchants(List<String> merchants){
        this.allMerchants= merchants;
    }


    protected static ResourceBundle promptResource = ResourceBundle.getBundle("Payments", Locale.US);

    @Override
    public boolean isLoginRequired() {
        return false;
    }

    abstract void setAnswers();


    protected void setAnswersForPrefix(String prefix) {
        //CLARIFY_CTA =  promptResource.getString(prefix+"_CLARIFY");
        LOCAL_ANSWER = promptResource.getString(prefix+"_LOCAL");
        INTERNATIONAL_ANSWER =  promptResource.getString(prefix+"_INTERNATIONAL");
        SOCIAL_ANSWER =promptResource.getString(prefix+"_SOCIAL");
        BILL_ANSWER = promptResource.getString(prefix+"_BILL");
    }



    boolean isLocal(String payment_slot, String country_slot) {

        //Payment and Country

        String payment = payment_slot;
        String country = country_slot;

        if (payment != null) {
            return payment.equalsIgnoreCase(PaymentType.LOCAL.name());
        } else {
            if (country != null) {
                return localCountries.contains(country);
//        Map<String, List<String>> countryMap = DomainAppListener.getCountryTable()
//        List<String> matchingCountries = countryMap.get(country.toLowerCase())
//
//        if (matchingCountries != null && !Collections.disjoint(matchingCountries, LOCAL_COUNTRIES)) {
//          /*
//           * International < Local. If we are here, then we did not get 'Outside of UAE'
//           */
//          return true
//        }
            }
        }

        return false;
    }


     boolean isInternational(String payment_slot, String country_slot) {

        /*
         * International if mentions enum value or if a non-UAE country is mentioned
         */

        String payment = payment_slot;
        String country = country_slot;

        if (payment != null) {
            return payment.equalsIgnoreCase(PaymentType.INTERNATIONAL.name());
        } else if (country != null) {
            return !localCountries.contains(country) && allCountries.contains(country);
//      Map<String, List<String>> countryMap = DomainAppListener.getCountryTable()
//      List<String> matchingCountries = countryMap.get(country.toLowerCase())
//
//      /*
//       * We may have lost the country map key, because getCountryTable removes stop-word keys e.g. 'in'
//       */
//      if (matchingCountries == null){
//        matchingCountries = Arrays.asList(DomainAppListener.getCountrySpellingMap().get(country))
//      }
//
//      if (matchingCountries != null && matchingCountries.size() > 0 && Collections.disjoint(matchingCountries, LOCAL_COUNTRIES))
//        return true
        }

        return false;
    }

    static boolean isSocial(String payment_slot) {

        String payment = payment_slot;
        if (payment == null || payment.trim().isEmpty())
            return false;
        return payment.equalsIgnoreCase(PaymentType.SOCIAL.name());
    }


    //TODO: Can we rely on the kai-normalizer to provide a valid merchant value or do we have to do an additional lookup?
    //merchants and countries will be normalized and provided only the trigger sentence
    //also should consider if this should be part of the workflow logic and not the processor logic
    boolean isMerchant(String merchant_slot) {

        String merchant = merchant_slot;
        if (merchant == null || merchant.trim().isEmpty())
            return false;

        return allMerchants.contains(merchant);

//    Map<String, List<String>> merchantMap = DomainAppListener.getMerchantTable()
//    List<String> matchingMerchants = merchantMap.get(merchant.toLowerCase())
//    if (matchingMerchants != null){
//      return true
//    }
    }

    boolean isBillPayment(String payment_slot, String merchant_slot) {

        //Payment

        /*
         * If it's a merchant, then it's a type of bill payment (in liv)
         */
        if (isMerchant(merchant_slot)) {
            return true;
        }

        /*
         * Otherwise, check if the category is a bill payment.
         */

        String payment = payment_slot;
        if (payment == null || payment.trim().isEmpty())
            return false;

        return payment.equalsIgnoreCase(PaymentType.BILL.name());

    }


    static String[] slots(Map<String, UserInput> accumulatedInputs) {
        UserInput payment;
        UserInput merchant;
        UserInput country;
        try {
            payment = (UserInput) ((ConcurrentHashMap) accumulatedInputs).get(FIELD_PAYMENT_TYPE);
            merchant = (UserInput) ((ConcurrentHashMap) accumulatedInputs).get(FIELD_MERCHANT_TYPE);
            country = (UserInput) ((ConcurrentHashMap) accumulatedInputs).get(FIELD_COUNTRY_TYPE);
        } catch (Exception e) {
            payment = (accumulatedInputs).get(FIELD_PAYMENT_TYPE);
            merchant = (accumulatedInputs).get(FIELD_MERCHANT_TYPE);
            country = (accumulatedInputs).get(FIELD_COUNTRY_TYPE);
        }


        String payment_slot = null;
        String country_slot = null;
        String merchant_slot = null;

        if (payment != null) payment_slot = payment.value;
        if (country != null) country_slot = country.value;
        if (merchant != null) merchant_slot = merchant.value;

        return new String[]{payment_slot, country_slot, merchant_slot};
    }

    public boolean validEntry(Map<String, UserInput> accumulatedInputs) {
        String[] sl = slots(accumulatedInputs);
        String payment_slot = sl[0];
        String country_slot = sl[1];
        String merchant_slot = sl[2];

        return isBillPayment(payment_slot, merchant_slot) || isSocial(payment_slot) ||
                isInternational(payment_slot, country_slot) || isLocal(payment_slot, country_slot);
    }


    static void qualifyCTA(Map<String, UserInput> accumulatedInputs, ConversationResponse response) {
        RequestUserInput.QuickReplyOption[] qr = new RequestUserInput.QuickReplyOption[]{


                //TODO change string literals here to use ENUMs?
                new RequestUserInput.QuickReplyOption(PaymentType.LOCAL.name(), PaymentType.LOCAL.label, true,PaymentType.LOCAL.aliases),
                new RequestUserInput.QuickReplyOption(PaymentType.INTERNATIONAL.name(), PaymentType.INTERNATIONAL.label,true,PaymentType.INTERNATIONAL.aliases),
                new RequestUserInput.QuickReplyOption(PaymentType.SOCIAL.name(), PaymentType.SOCIAL.label,true,PaymentType.SOCIAL.aliases),
                new RequestUserInput.QuickReplyOption(PaymentType.BILL.name(), PaymentType.BILL.label,true,PaymentType.BILL.aliases)};

        List<RequestUserInput.QuickReplyOption> options = Arrays.asList(qr);

        response.request_user_input = new RequestUserInput(FIELD_PAYMENT_TYPE, RequestUserInput.UserInputType.STRING, options);

        response.message_contents.add(new MessageContentText(genText(promptResource.getString(PROMPTS.PROMPT_TYPE_PAYMENT.name()), accumulatedInputs.values())));
    }


    @Override
    public void updatePreconditions(ConversationSession session) {



        if(validEntry(session.getCurrentUserInputs())){
          session.getSystemInputs().put(VALID_INPUT, new SystemInput(VALID_INPUT, Boolean.TRUE.toString()));
        }else{
            session.getSystemInputs().put(VALID_INPUT, new SystemInput(VALID_INPUT, Boolean.TRUE.toString()));

        }
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {

        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;


        if (action == PaymentExecutionWorkflow.Actions.QUALIFY_TRANSFER) {

            qualifyCTA(accumulatedInputs, response);

        } else if (action == PaymentExecutionWorkflow.Actions.SHOW_ANSWER) {


            String[] sl = slots(accumulatedInputs);
            String payment_slot = sl[0];
            String country_slot = sl[1];
            String merchant_slot = sl[2];

            setAnswers();

            if (isBillPayment(payment_slot, merchant_slot)) {
                response.message_contents.add(new MessageContentText(genText(BILL_ANSWER, accumulatedInputs.values())));
            } else if (isSocial(payment_slot)) {
                response.message_contents.add(new MessageContentText(genText(SOCIAL_ANSWER, accumulatedInputs.values())));
            } else if (isInternational(payment_slot, country_slot)) {
                response.message_contents.add(new MessageContentText(genText(INTERNATIONAL_ANSWER, accumulatedInputs.values())));
            } else if (isLocal(payment_slot, country_slot)) {
                response.message_contents.add(new MessageContentText(genText(LOCAL_ANSWER, accumulatedInputs.values())));
            } else {
                qualifyCTA(accumulatedInputs, response);
            }
        }

        return response;
    }
}
