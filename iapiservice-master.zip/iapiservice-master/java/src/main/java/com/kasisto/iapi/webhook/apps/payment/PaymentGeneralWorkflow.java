package com.kasisto.iapi.webhook.apps.payment;

import com.kasisto.iapi.webhook.core.workflow.*;

import java.util.ArrayList;
import java.util.List;

public class PaymentGeneralWorkflow extends Workflow {

    public enum States implements WFState {
        START, QUALIFY, END
    }

    enum Actions implements WFAction {
        QUALIFY_TRANSFER, SHOW_ANSWER
    }


    private boolean validInput(WFEvent event){




        boolean isValid = event.getSystemInputs().containsKey(PaymentGeneralIntentProcessor.VALID_INPUT) &&
                event.getSystemInputs().get(PaymentGeneralIntentProcessor.VALID_INPUT).value.equals(Boolean.TRUE.toString());

        return isValid;

    }
    boolean payment_event(WFEvent event) {
        return event.getCurrentUserInputs().containsKey(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE)
                && validInput(event);
    }

    boolean merchant_event(WFEvent event) {
        return event.getCurrentUserInputs().containsKey(PaymentGeneralIntentProcessor.FIELD_MERCHANT_TYPE)
                && validInput(event);
    }

    boolean country_event(WFEvent event) {
        return event.getCurrentUserInputs().containsKey(PaymentGeneralIntentProcessor.FIELD_COUNTRY_TYPE)
                && validInput(event);
    }

    @Override
    public List<WFTransition> generateTransitions() {
        /**
         * FILL in transitions
         */

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.QUALIFY_TRANSFER, States.START, States.QUALIFY,
                event -> (!payment_event(event) && !merchant_event(event) && !country_event(event))));

        transitions.add(new WFTransition(Actions.QUALIFY_TRANSFER, States.QUALIFY, States.QUALIFY,
                event -> (!payment_event(event) && !merchant_event(event) && !country_event(event))));

        transitions.add(new WFTransition(Actions.SHOW_ANSWER, States.START, States.END,
                event -> (payment_event(event) || merchant_event(event) || country_event(event))));

        transitions.add(new WFTransition(Actions.SHOW_ANSWER, States.QUALIFY, States.END,
                event -> ((payment_event(event) && !merchant_event(event) && !country_event(event))
                        || (!payment_event(event) && merchant_event(event) && !country_event(event))
                        || (!payment_event(event) && !merchant_event(event) && country_event(event)))));

        return transitions;
    }

    @Override
    public WFState getOrigin() {
        return States.START;
    }
}
