package com.kasisto.iapi.webhook.apps.payment;

public class PaymentProcessingTimeIntentProcessor extends PaymentGeneralIntentProcessor {



    public static final String PREFIX = "PROCESS";

    void setAnswers(){
        this.setAnswersForPrefix(PREFIX);
    }

    public static final String PAYMENT_PROCESSING_TIME_INTENT_NAME = "payment_processing_time";
}
