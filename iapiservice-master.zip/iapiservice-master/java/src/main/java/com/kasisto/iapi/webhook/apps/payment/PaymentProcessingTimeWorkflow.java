package com.kasisto.iapi.webhook.apps.payment;

public class PaymentProcessingTimeWorkflow extends PaymentGeneralWorkflow {
    public static final String PAYMENT_INTENT_NAME = "payment_processing_time";
}
