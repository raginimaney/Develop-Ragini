package com.kasisto.iapi.webhook.apps.product;

import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.DynFaqGenericHelper;
import com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow.GenericDynFaqProcessorHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;


/**
 *
 */
public class ProductDynFaqHelper extends DynFaqGenericHelper implements GenericDynFaqProcessorHelper {

    private Log log = LogFactory.getLog(getClass());
    public static String DYNFAQ_PREFIX = "product_dynfaq";

    public ProductDynFaqHelper(String dynFaqPrefix) {
        super(dynFaqPrefix);
    }

    @Override
    public String getDisambigPromptForIntent(String intentName) {
        return super.getDisambigPromptForIntent(intentName);
    }

    @Override
    public List<RequestUserInput.QuickReplyOption> getDisambigQuickRepliesTextForIntent(String intentName){
        return super.getDisambigQuickRepliesTextForIntent(intentName);
    }

    @Override
    public String getFinalPromptForIntent(String intentName, String resourceKeyBase) {
        return super.getFinalPromptForIntent(intentName, resourceKeyBase);
    }
}
