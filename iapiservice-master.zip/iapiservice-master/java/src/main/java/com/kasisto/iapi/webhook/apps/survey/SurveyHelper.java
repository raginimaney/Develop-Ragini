package com.kasisto.iapi.webhook.apps.survey;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.DefaultMessageTemplates;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericProcessorHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SurveyHelper implements GenericProcessorHelper {

    public static final String SURVEY_INTENT_NAME = "SimpleSurvey_form";

    static List<RequestUserInput> userInputs;

    private static final String USER_NAME = "user_name";
    private static final String USER_AGE = "user_age";

    static {
        userInputs = new ArrayList<>();

        userInputs.add(new RequestUserInput(USER_NAME, RequestUserInput.UserInputType.STRING));
        userInputs.add(new RequestUserInput(USER_AGE, RequestUserInput.UserInputType.NUMBER));
    }

    @Override
    public boolean isValid(String paramName, String paramValue) {

        if (paramName.equals(USER_NAME)) {
            return paramValue.length() >= 2;
        } else if (paramName.equals(USER_AGE)) {
            //must be 18 years old
            return !(Double.parseDouble(paramValue) < 18);
        }
        return true;
    }

    @Override
    public MessageContent getPromptForInput(RequestUserInput paramName) {
        if (paramName.name.equals(USER_NAME)) {
            return new MessageContentText("what is your name?");
        } else if (paramName.name.equals(USER_AGE)) {
            return new MessageContentText("what is your age?");
        }
        return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT));
    }

    @Override
    public MessageContent getRetryPromptForInput(RequestUserInput paramName) {
        if (paramName.name.equals(USER_NAME)) {
            return new MessageContentText("must be > 2 characters");
        } else if (paramName.name.equals(USER_AGE)) {
            return new MessageContentText("must be over 18");
        }
        return new MessageContentText(DefaultMessageTemplates.getRandomizedMessage(DefaultMessageTemplates.DEFAULT_RETRY));
    }

    @Override
    public MessageContent getEndPrompt() {
        return new MessageContentText("Success!");
    }

    @Override
    public List<RequestUserInput> getInputParams() {
        return userInputs;
    }

    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {

    }


}
