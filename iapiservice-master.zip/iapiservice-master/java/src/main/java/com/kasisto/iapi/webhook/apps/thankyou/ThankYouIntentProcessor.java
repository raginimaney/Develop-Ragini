package com.kasisto.iapi.webhook.apps.thankyou;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.workflow.SingleStepWorkflow;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.util.*;

public class ThankYouIntentProcessor extends AbstractIntentProcessor {

    public static final String THANKYOU_INTENT_NAME = "thank_you";

    @Override
    public boolean isLoginRequired() {
        return false;
    }


    //Dialog Prompts
    private static ResourceBundle promptResource = ResourceBundle.getBundle(THANKYOU_INTENT_NAME);
    private static List<String> prompts;
    private Random rand = new Random();


    static {
        prompts = new ArrayList<String>();
        for (String akey : promptResource.keySet()) {
            prompts.add(promptResource.getString(akey));
        }
    }

    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {


        String arandomPrompt = prompts.get(rand.nextInt(prompts.size()));
        ConversationResponse response = new ConversationResponse();
        response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        if (action == SingleStepWorkflow.Actions.SHOW_ANSWER) {
            response.message_contents.add(new MessageContentText(arandomPrompt));
        }

        return response;
    }
}