package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * The Abstract Processor, given an intent-specific workflow, is responsible for interfacing
 * with backend systems and generating a ConversationResponse from a specific workflow action
 * <p>
 * Generate a valid response (AKA NLG)
 * * Effectively responsible for generating the appropriate response given:
 * * a) Action from workflow
 * * b) User-input parameters (from current and previous requests)
 * * c) Any user-specific data (accounts, insights, etc) available from backend systems like EAPI
 *
 * @author olivier
 * @author jon
 */
public abstract class AbstractIntentProcessor {

    private Log log = LogFactory.getLog(getClass());

    Workflow workflow;

    protected String minimalApiVersion = "1.0.0";

    public String getMinimalVersion(){
        return minimalApiVersion;
    }

    public void setWorkflow(Workflow workflow) {
        this.workflow = workflow;
    }

    /**
     * Checks if the user needs to be authenticated to use this intent
     *
     * @return true if the user needs to login to access the intent; false otherwise.
     */
    public abstract boolean isLoginRequired();


    /**
     * @param action
     * @param token
     * @param accumulatedInputs
     * @param context
     * @return
     */
    public abstract ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context);



    /**
     * Subclasses should override this if they generate a system-event
     *
     * @param session
     * @return
     */
    public void updatePreconditions(ConversationSession session) {
    }


    /**
     * override to create side-effects
     *
     * @param action
     * @param session
     */
    public void updatePostConditions(WFAction action, ConversationSession session) {
    }


    /**
     * Process the user inputs and build an answer.
     *
     * @return
     * @throws ApiException
     */
    public final ConversationResponse process(ConversationSession session) throws ApiException {


        updatePreconditions(session);



        WFEvent event = new WFEvent(session.getCurrentUserInputs(), session.getPreviousUserInputs(), session.getSystemInputs(), session.lastMessageText, session.user_id);


        //use the FS workflow to determine the transition(end state, action, etc)
        WFTransition transition;


        try {
            transition = workflow.getTransition(session.currentWorkflowState, event);
        } catch (NoTransitionFoundException e) {
            log.error(e);
            throw new ApiException(ApiException.SERVER_ERROR, "Not able to process next step");
        }
		/*
		based on the resulting transition, delegate the response to the implementation-specific
		processor
		*/

        ConversationResponse response = generateResponseForAction(transition.getAction(), session.user_id, session.token, session.getAccumulatedUserInput(), session.getSystemInputs(), session.context);

        updatePostConditions(transition.getAction(), session);

        //update the workflow state
        session.currentWorkflowState = transition.getEnd();
        response.conversation_id = session.conversation_id;

        return response;
    }

    /**
     * string replacement of ${var} style templates
     *
     * @param templateString
     * @param userInputs
     * @return
     */
    public static String genText(String templateString, Collection<UserInput> userInputs) {
        Map<String, String> values = new HashMap<>();

        for (UserInput input : userInputs) {
            values.put(input.name, input.value);
        }

        return TemplateUtil.genText(templateString, values);

    }


    public static String genText(String templateString, Map<String, String> properties) {

        return TemplateUtil.genText(templateString, properties);

    }


}
