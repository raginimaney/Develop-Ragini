package com.kasisto.iapi.webhook.core;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * Class for managing access to environment properties.
 */
public class IapiEnvConf {

    private Log log = LogFactory.getLog(getClass());

    private final Properties envProperties = new Properties();

    public static final String EAPI_URL_PROPERTY_NAME = "enterprise.api.url";
    public static final String EAPI_URL_PROPERTY_DEFAULT = "http://kai-en-us-mock-enterprise-api-service-qa.kitsys.net/api";

    public static final String EAPI_SECRET_PROPERTY_NAME = "enterprise.api.secret";
    public static final String EAPI_SECRET_PROPERTY_DEFAULT = "74573e7e-7e24-4b25-a42d-3dabaa4db2d0";


    public static final String EAPI_TOKEN_PROPERTY_NAME = "enterprise.api.token";
    public static final String EAPI_TOKEN_PROPERTY_DEFAULT = "tokenACME";



    //all services will make these env properties available here
    private static final String RESOURCE_PATH = "/etc/kasisto/";

    private static IapiEnvConf instance;


    Map<String,String> propertyToDefault;

    IapiEnvConf() {

        propertyToDefault = new HashMap<>();
        propertyToDefault.put(EAPI_SECRET_PROPERTY_NAME,EAPI_SECRET_PROPERTY_DEFAULT);
        propertyToDefault.put(EAPI_URL_PROPERTY_NAME,EAPI_URL_PROPERTY_DEFAULT);
        propertyToDefault.put(EAPI_TOKEN_PROPERTY_NAME,EAPI_TOKEN_PROPERTY_DEFAULT);

        try {

            File file = new File(RESOURCE_PATH + "/env.properties");
            InputStream is = new FileInputStream(file);
            envProperties.load(is);
        } catch (Throwable throwable) {
            log.error("Unable to init env.properties: " + throwable.getMessage());
        }
    }


    public static IapiEnvConf getInstance() {
        if (instance == null) {
            instance = new IapiEnvConf();
        }
        return instance;
    }

    public Properties getProperties() {
        return envProperties;
    }

    public String getPropertyOrDefault(String propertyName){
       return  envProperties.get(propertyName) != null ? envProperties.getProperty(propertyName) : propertyToDefault.get(propertyName);
    }


}
