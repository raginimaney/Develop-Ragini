package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.session.ConversationSession;

/**
 * Security Manager.
 *
 * @author olivier
 */
public class SecurityManager {
    /**
     * The value of the secret key shared with KAI
     */
    private static final String SECRET = "SHARED_SECRET";

    private static final boolean SECURITY_ENABLED = false;

    /**
     * Method to validate that the secret sent by KAI has the same value as the one
     * 'configured' in the static variable SECRET
     *
     * @param secret: the secret sent by KAI
     * @throws ApiException
     */
    public static void validateSecret(String secret) throws ApiException {
        // Check the secret:

        if (SECURITY_ENABLED && !SECRET.equals(secret)) {
            throw new ApiException(ApiException.ACCESS_DENIED,
                    "The secret is invalid. It is not set to '" + SECRET + "'");
        }

    }

    /**
     * Verify the the user is authorized to access this intent
     *
     * @param session the intent session
     * @param user_id the user id of the user
     * @param token   the access token of the user
     * @throws ApiException error 401 if the user in not authorized
     */
    public static void verifyUserCredentials(ConversationSession session, String user_id, String token) throws ApiException {

        if ("NOT_ALLOWED".endsWith(token)) {
            throw new ApiException(ApiException.AUTH_FAILED, "The user is not allowed.");
        }
    }
}
