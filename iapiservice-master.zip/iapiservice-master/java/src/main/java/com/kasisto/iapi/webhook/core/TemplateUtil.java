package com.kasisto.iapi.webhook.core;

import org.apache.commons.lang3.text.StrSubstitutor;

import java.util.Map;

public class TemplateUtil {

    /**
     * string replacement of ${var} style templates
     *
     * @param templateString
     * @param userInputs
     * @return
     */
    public static String genText(String templateString, Map<String, String> values) {

        StrSubstitutor sub = new StrSubstitutor(values);
        return sub.replace(templateString);
    }
}
