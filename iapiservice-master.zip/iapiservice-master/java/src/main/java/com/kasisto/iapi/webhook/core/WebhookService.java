package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.core.api.Logged;
import com.kasisto.iapi.webhook.core.api.Version;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.ErrorResponse;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.session.SessionStore;
import com.kasisto.iapi.webhook.core.session.SessionStoreFactory;
import com.kasisto.iapi.webhook.core.workflow.AbstractIntentProcessorFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jvnet.hk2.annotations.Service;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Date;
import java.util.UUID;

/**
 * This class is a sample implementation of the KAI Dynamic Conversation Webhook
 * specifications It implements the Webhook operations: 1) start_conversation:
 * This service initiates a new conversation between the User and the Webhook.
 * 2) send_user_input: This service submits a user input to the Webhook to
 * continue an existing conversation.
 *
 * @author olivier
 */
@Path("/intents")
@Produces({"application/json"})
@Service
public class WebhookService {

    private Log log = LogFactory.getLog(getClass());


    @Inject
    private AbstractIntentProcessorFactory intentProcessorFactory;

    private static final String ENV_SESSION_STORE_TYPE = "SESSION_STORE_TYPE";

    static SessionStore sessionStore;

    static {

        if (System.getenv(ENV_SESSION_STORE_TYPE) != null && System.getenv(ENV_SESSION_STORE_TYPE).equals(SessionStoreFactory.StoreType.REDIS.name())) {
            sessionStore = SessionStoreFactory.getSessionStore(SessionStoreFactory.StoreType.REDIS);
        } else {
            sessionStore = SessionStoreFactory.getSessionStore(SessionStoreFactory.StoreType.INMEMORY);
        }
    }

    /**
     * JAX-RS endpoint to receive POST requests to start a dynamic conversation
     *
     * @param secret     the secret key shared with KAI.
     * @param token      the user session token (null if the user is not
     *                   authenticated)
     * @param locale     the locale of the user. It can be used to generate
     *                   localized text it the Webhook support multiple languages.
     * @param request_id the unique id of the request. It can be used to track the
     *                   requests when investigating execution logs.
     * @param date       the date and time that the message was sent (in HTTP-date
     *                   format as defined by RFC 7231)
     * @param request    the Json request
     * @return the JAX-RS response
     */
    @POST
    @Logged
    @Path("/start_conversation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response startConversation(@HeaderParam("secret") String secret, @HeaderParam("token") String token,
                                      @HeaderParam("locale") String locale, @HeaderParam("request_id") String request_id,
                                      @HeaderParam("Date") Date date, StartConversationRequest request) {


        log.info("start_conversation (secret: " + secret + ", token:" + token + ", locale:" + locale + ", request_id:"
                + request_id + ", Date:" + date + ")");

        try {

            return processResponse(handleStartConversation(secret, token, locale, request_id, date, request));

        } catch (ApiException e) {
            log.error("An error occurred processing the request: " + e.getCode() + " - " + e.getMessage());
            return processException(e);
        } catch (SessionStoreException e) {
            log.error("A cache error: " + e.getMessage());
            return processException(e);
        } catch (Exception e) {
            log.error("An unexpected error occurred processing the request!", e);
            return processException(e);
        }


    }

    protected ConversationResponse handleStartConversation(String secret, String token, String locale, String request_id,
                                                           Date date, StartConversationRequest request) throws ApiException, SessionStoreException {

        // 1. Check that the call is allowed
        // check that the shared secret is valid
        // SecurityManager.validateSecret(secret);

        // 2. Create the Intent Session and maintain it for the next calls
        ConversationSession session = new ConversationSession();
        session.conversation_id = UUID.randomUUID().toString();
        if (request.context != null && request.context.user != null ) {
            session.segments = request.context.user.segment_names;
            session.context = request.context;
        }
        session.intentName = request.intent_name;
        if (request.user_message != null) {
            session.lastMessageText = request.user_message.payload.text;
        }

        session.token = token;

        AbstractIntentProcessor processor = intentProcessorFactory.get(session.intentName);


       if(request.context != null && Version.isVersionNewer(processor.getMinimalVersion(), request.context.api_version)){
            throw new ApiException(ApiException.ACCESS_DENIED, "This intent requires API version of at least "+processor.getMinimalVersion());
        }

        // 3. Check if the Intent needs the user to Authenticate
        // If the Intent needs authenticated users and the user is not authenticated,
        // ask
        // the user to authenticate
        if (processor.isLoginRequired()) {
            if (StringUtils.isEmpty(token)) {
                throw new ApiException(ApiException.AUTH_FAILED, "Please authenticate to use this intent");
            } else {
                SecurityManager.verifyUserCredentials(session, session.user_id, token);
            }
        }


        session.setCurrentUserInputs(request.user_inputs);


        ConversationResponse response = processor.process(session);


        if (response.conversation_state != ConversationResponse.ConversationState.PENDING_USER) {
            sessionStore.deleteConversationSession(session);
        } else {
            session.promoteUserInputs();
            sessionStore.saveConversationSession(session);
        }


        return response;
    }

    /**
     * HTTP endpoint to receive POST requests to continue a dynamic conversation
     *
     * @param secret     the secret key shared with KAI.
     * @param token      the user session token (null if the user is not
     *                   authenticated)
     * @param locale     the locale of the user. It can be used to generate
     *                   localized text it the Webhook support multiple languages.
     * @param request_id the unique id of the request. It can be used to track the
     *                   requests when investigating execution logs.
     * @param date       the date and time that the message was sent (in HTTP-date
     *                   format as defined by RFC 7231)
     * @param request    the Json request
     * @return the JAX-RS response
     */
    @POST
    @Path("/send_user_input")
    @Logged
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response sendUserInput(@HeaderParam("secret") String secret, @HeaderParam("token") String token,
                                  @HeaderParam("locale") String locale, @HeaderParam("request_id") String request_id,
                                  @HeaderParam("Date") Date date, SendUserInputRequest request) {

        log.info("send_user_input (secret: " + secret + ", token:" + token + ", locale:" + locale + ", request_id:"
                + request_id + ", Date:" + date + ")");


        try {

            ConversationResponse resp = handleSendUserInput(secret, token, locale, request_id, date, request);

            return processResponse(resp);


        } catch (ApiException e) {
            log.error("An error occurred processing the request: " + e.getCode() + " - " + e.getMessage());
            return processException(e);
        } catch (Exception e) {
            log.error("An unexpected error occurred processing the request!", e);
            return processException(e);
        }
    }


    protected ConversationResponse handleSendUserInput(String secret, String token,
                                                       String locale, String request_id,
                                                       Date date, SendUserInputRequest request) throws ApiException, SessionStoreException {

        // 1. Check that the call is allowed:
        // check that the shared secret is valid
        SecurityManager.validateSecret(secret);

        // 2. Retrieve the intent session
        ConversationSession session = null;
        try {
            session = sessionStore.getConversationSession(request.conversation_id);
        } catch (SessionStoreException ex) {
            throw new ApiException(ApiException.SERVER_ERROR, "Could not get session information");
        }

        if (session == null) {
            throw new ApiException(ApiException.SERVER_ERROR, "No such intent session");
        }
        session.token = token;


        session.setCurrentUserInputs(request.user_inputs);


        // 4. Execute the intent logic
        AbstractIntentProcessor processor = intentProcessorFactory.get(session.intentName);
        ConversationResponse response = processor.process(session);


        // 5. If the intent processing ended, delete the session
        if (response.conversation_state != ConversationResponse.ConversationState.PENDING_USER) {
            sessionStore.deleteConversationSession(session);
        } else {
            session.promoteUserInputs();
            sessionStore.saveConversationSession(session);
        }


        return response;

    }

    /**
     * HTTP endpoint to receive POST requests to cancel a dynamic conversation
     *
     * @param secret     the secret key shared with KAI.
     * @param token      the user session token (null if the user is not
     *                   authenticated)
     * @param locale     the locale of the user. It can be used to generate
     *                   localized text it the Webhook support multiple languages.
     * @param request_id the unique id of the request. It can be used to track the
     *                   requests when investigating execution logs.
     * @param date       the date and time that the message was sent (in HTTP-date
     *                   format as defined by RFC 7231)
     * @param request    the Json request
     * @return the JAX-RS response
     */
    @POST
    @Path("/cancel_user_input")
    @Logged
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response cancelUserInput(@HeaderParam("secret") String secret, @HeaderParam("token") String token,
                                    @HeaderParam("locale") String locale, @HeaderParam("request_id") String request_id,
                                    @HeaderParam("Date") Date date, SendUserInputRequest request) {

        log.info("cancel_user_input (secret: " + secret + ", token:" + token + ", locale:" + locale + ", request_id:"
                + request_id + ", Date:" + date + ")");


        ConversationResponse response;
        try {

            response = handleCancelUserInput(secret, token, locale, request_id, date, request);

        } catch (ApiException e) {
            return processException(e);
        } catch (SessionStoreException e) {
            return processException(e);
        }
        return processResponse(response);


    }

    public ConversationResponse handleCancelUserInput(String secret, String token,
                                                      String locale, String request_id,
                                                      Date date, SendUserInputRequest request) throws ApiException, SessionStoreException {

        // 1. Check that the call is allowed:
        // check that the shared secret is valid
        SecurityManager.validateSecret(secret);

        log.info("cancel session for request " + request_id + " for reason" + request.reason);

        // 2. Retrieve the intent session
        ConversationSession session = sessionStore.getConversationSession(request.conversation_id);
        if (session == null) {
            throw new ApiException(ApiException.SERVER_ERROR, "No such intent session");
        }
        session.token = token;

        // 3. Add intent input in the intent session
        if (request.user_inputs != null) {
            session.setCurrentUserInputs(request.user_inputs);
        }


        // 5. If the intent processing ended, delete the session
        sessionStore.deleteConversationSession(session);
        return new ConversationResponse();
    }

    /**
     * Build a JAX-RS success response that contains the ConversationResonse
     * generated by the intent
     *
     * @param response the Json response to the service call (start_conversation and
     *                 send_user_input use the same response)
     * @return the JAX-RS success response.
     */
    private Response processResponse(ConversationResponse response) {
        return Response.status(200).entity(response).build();
    }

    /**
     * Build a JAX-RS error response that contains the ErrorResponse with the
     * details of the error
     *
     * @return the JAX-RS error response.
     */
    private Response processException(ApiException e) {
        ErrorResponse response = new ErrorResponse();
        response.code = Integer.toString(e.getCode());
        response.message = e.getMessage();

        return Response.status(e.getCode()).entity(response).build();
    }

    /**
     * Build a JAX-RS error response that contains the ErrorResponse for an
     * unexpected error
     *
     * @return the JAX-RS error response.
     */
    private Response processException(Exception e) {
        ErrorResponse response = new ErrorResponse();
        response.code = Integer.toString(ApiException.SERVER_ERROR);
        response.message = "An unexpected error occurred";

        return Response.status(ApiException.SERVER_ERROR).entity(response).build();
    }


    public void setIntentProcessorFactory(AbstractIntentProcessorFactory factory) {
        this.intentProcessorFactory = factory;
    }


    public WebhookService() {

    }
}
