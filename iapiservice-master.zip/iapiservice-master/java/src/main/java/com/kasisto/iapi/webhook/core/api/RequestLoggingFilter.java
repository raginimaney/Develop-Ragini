package com.kasisto.iapi.webhook.core.api;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;


/**
 * Filter for making it easier to login json request
 */
@Logged
@Provider
public class RequestLoggingFilter implements ContainerRequestFilter {

    private Log log = LogFactory.getLog(getClass());


    @Override
    public void filter(ContainerRequestContext request) throws IOException {
        if (isJson(request)) {
            try {

                String json = IOUtils.toString(request.getEntityStream(), Charset.forName("UTF-8"));
                // do whatever you need with json
                log.info(json);

                InputStream in = IOUtils.toInputStream(json, Charset.forName("UTF-8"));
                request.setEntityStream(in);

            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    boolean isJson(ContainerRequestContext request) {
        // define rules when to read body
        return request.getMediaType().toString().contains("application/json");
    }
}
