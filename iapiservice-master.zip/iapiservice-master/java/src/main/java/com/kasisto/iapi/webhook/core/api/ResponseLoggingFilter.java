package com.kasisto.iapi.webhook.core.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;


/**
 * Filter for making it easier to login json response
 */
@Logged
@Provider
public class ResponseLoggingFilter implements ContainerResponseFilter {


    private Log log = LogFactory.getLog(getClass());


    @Override
    public void filter(ContainerRequestContext request,
                       ContainerResponseContext responseContext) throws IOException {


        Object entity = responseContext.getEntity();

        ObjectMapper mapper = new ObjectMapper();

        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        //Object to JSON in String
        String json = mapper.writeValueAsString(entity);

        log.info(json);

    }

}