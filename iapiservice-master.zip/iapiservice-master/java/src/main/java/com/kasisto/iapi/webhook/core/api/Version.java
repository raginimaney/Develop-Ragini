package com.kasisto.iapi.webhook.core.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Utility class for comparing API versions to ensure that API-request is compatible with the intent.
 */
public class Version {


    public static void main(String[] args){

        System.out.println("what"+Version.isVersionNewer("2.6.1", "1.0"));
        System.out.println("what"+Version.isVersionNewer("2.6.1", "2.5.1"));
        System.out.println("what"+Version.isVersionNewer("2.6.1", "2.6.1"));
        System.out.println("what"+Version.isVersionNewer("2.6.1", "3.0"));

    }

    private static int[] getVersionNumbers(String ver) {

        Matcher m3 = Pattern.compile("(\\d+)\\.(\\d+)\\.(\\d+)")
                .matcher(ver);

        Matcher m2 = Pattern.compile("(\\d+)\\.(\\d+)")
                .matcher(ver);

        if (!m2.matches() && !m3.matches())
            throw new IllegalArgumentException("Malformed FW version");

        if(m2.matches() && !m3.matches()){
            return new int[] { Integer.parseInt(m2.group(1)),  // major
                    Integer.parseInt(m2.group(2)),             // minor
                    0};
        }else {
            return new int[] { Integer.parseInt(m3.group(1)),  // major
                    Integer.parseInt(m3.group(2)),             // minor
                    Integer.parseInt(m3.group(3))};
        }
    }

    public static boolean isVersionNewer(String baseVersion, String comparisonVersion) {

        int[] baseVer = getVersionNumbers(baseVersion);
        int[] testVer = getVersionNumbers(comparisonVersion);

        for (int i = 0; i < testVer.length; i++) {
            if (testVer[i] != baseVer[i]) {
                return testVer[i] < baseVer[i];
            }
        }

        return false;
    }
}
