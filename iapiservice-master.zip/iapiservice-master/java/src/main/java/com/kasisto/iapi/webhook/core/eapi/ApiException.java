package com.kasisto.iapi.webhook.core.eapi;


public class ApiException extends Exception {
    public static final int DEFAULT_ERROR_CODE = 400;
    public static final int INVALID_TOKEN = 401;
    public static final int INVALID_CREDENTIALS = 551;
    public static final int AUTHENTICATION_REQUIRED = 402;
    public static final int ACCESS_DENIED = 403;
    public static final int NOT_FOUND = 404;
    public static final int NOT_IMPLEMENTED = 420;
    public static final int INVALID_DESTINATION_ID = 421;
    // one-time password errors
    public static final int OTP_REQUIRED = 450;
    public static final int OTP_INVALID = 451;
    public static final int OTP_EXPIRED = 452;
    public static final int OTP_MAXIMUM_OTP_ENTRY_ERRORS = 453;
    public static final int OTP_MAXIMUM_OTP_GENERATED = 454;

    public static final int REMOTE_SERVER_ERROR = 500;
    public static final int REMOTE_SERVER_NOT_RESPONDING = 550;

    // payment errors
    public static final int INVALID_PAYMENT_ACCOUNT_TOKEN = 10401;
    public static final int INSUFFICIENT_PAYMENT_FUNDS = 10410;
    public static final int PAYMENT_AMOUNT_TOO_SMALL = 10411;
    public static final int PAYMENT_ACCOUNT_FROZEN = 10412;
    public static final int PAYMENT_AMOUNT_TOO_LARGE = 10413;
    public static final int DUPLICATE_PAYMENT = 10414;
    public static final int PAYMENT_ACCOUNT_INVALID = 10415;
    public static final int PAYEE_ACCOUNT_INVALID = 10416;

    public static final int DAILY_PAYMENT_NUMBER_LIMIT_EXHAUSTED = 10417;
    public static final int DAILY_PAYMENT_AMOUNT_LIMIT_EXCEEDED = 10418;
    public static final int PAYMENT_AMOUNT_LIMIT_EXCEEDED = 10419;
    public static final int MONTHLY_PAYMENT_AMOUNT_LIMIT_EXCEEDED = 10420;


    private static final long serialVersionUID = 4140259354654381359L;
    public int code;
    public String serverCode;
    public String message;
    public String displayMessageId;

    public String getDisplayMessageId() {
        return displayMessageId;
    }

    public ApiException() {
        this.code = DEFAULT_ERROR_CODE;
    }

    public ApiException(Exception e) {
        super(e);
        this.code = DEFAULT_ERROR_CODE;
        this.message = e.getMessage();
    }

    public ApiException(int code, Exception e) {
        super(e);
        this.code = code;
        this.message = e.getMessage();
    }

    public ApiException(int code, String message) {
        super(message);
        this.message = message;
        this.code = code;
    }

    public ApiException(int code, String message, String displayMessageId) {
        super(message);
        this.message = message;
        this.displayMessageId = displayMessageId;
        this.code = code;
    }

    public ApiException(int code, String serverCode, String message, String displayMessageId) {
        super(message);
        this.message = message;
        this.displayMessageId = displayMessageId;
        this.code = code;
        this.serverCode = serverCode;
    }

    public int getCode() {
        return this.code;
    }


    @Override
    public String toString() {
        if (code == REMOTE_SERVER_ERROR) {
            return this.code + "." + this.serverCode + " - " + this.getDisplayMessageId() + ": " + this.message;
        } else {
            return this.code + ": " + this.message;
        }
    }

}
