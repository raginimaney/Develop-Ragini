package com.kasisto.iapi.webhook.core.eapi;

import com.fasterxml.jackson.annotation.JsonProperty;
import domain.lola.user.bb.Location;


/**
 * Should be moved into the balaom spec because it is part of the EAPI spec.
 * <p>
 * 1. Add to kai
 * 2. generate new balaom.jar
 * 3. Place jar in iapiservice projects
 */
public class OfferRequest {

    private String user_id;
    private String type;
    private String status;
    private Location location;


    public String getUser_id() {
        return user_id;
    }

    @JsonProperty("user_id")
    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("location")
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}
