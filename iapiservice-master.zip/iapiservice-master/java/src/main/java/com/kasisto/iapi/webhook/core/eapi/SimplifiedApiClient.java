package com.kasisto.iapi.webhook.core.eapi;


import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiPredicate;

//import org.mortbay.log.Log;
//import com.kasisto.api.model.ErrorResponse;
//import com.kasisto.util.CorrelationHelper;
//import com.sri.vpa.util.AppConfig;
//import com.sri.vpa.util.EnvConf;


/**
 * NOTE: DO NOT MODIFY THIS CODE HERE.  IT SHOULD BE MOVED INTO A LIBRARY PUBLISHED OUT OF KAI PROJECT
 * <p>
 * Simplified version of ApiClient (com/kasisto/client/ApiClient.java)
 * <p>
 * with the following changes:
 * 1) Removed dependencies on SRI/vpa ( com.sri.vpa.util.AppConfig, com.sri.vpa.util.EnvConf)
 * 2) Removed core dependency (com.kasisto.util.CorrelationHelper,com.kasisto.api.model.ErrorResponse)
 * <p>
 * Note since configuration is not populated from EnvConf/env.properties, this configuration has to be loaded
 * separately.  It is currently configured in code but should be externalized.
 *
 * @author jon
 */

public class SimplifiedApiClient {

    private static final Logger logger = LoggerFactory.getLogger(SimplifiedApiClient.class);
    private static final Logger tracelog = LoggerFactory.getLogger("com.kasisto.client.trace");
    private static final Logger tracelog_head = LoggerFactory.getLogger("com.kasisto.client.trace.headers");


    static String eapiURL = null;


    public static class RetryStrategy {
        private int maxRetries;
        private int retryIntervalSeconds;
        private BiPredicate<StatusLine, Exception> shouldRetryHandler;

        public int getMaxRetries() {
            return maxRetries;
        }

        public void setMaxRetries(int maxRetries) {
            this.maxRetries = maxRetries;
        }

        public int getRetryIntervalSeconds() {
            return retryIntervalSeconds;
        }

        public void setRetryIntervalSeconds(int retryIntervalSeconds) {
            this.retryIntervalSeconds = retryIntervalSeconds;
        }

        public void setShouldRetryHandler(BiPredicate<StatusLine, Exception> shouldRetryHandler) {
            this.shouldRetryHandler = shouldRetryHandler;
        }

        public BiPredicate<StatusLine, Exception> getShouldRetryHandler() {
            return this.shouldRetryHandler;
        }

        protected boolean shouldRetry(StatusLine statusLine) {
            return (maxRetries > 0 && (shouldRetryHandler == null || shouldRetryHandler.test(statusLine, null)));
        }

        protected boolean shouldRetry(Exception e) {
            return (maxRetries > 0 && (shouldRetryHandler == null || shouldRetryHandler.test(null, e)));
        }

        protected RetryStrategy next() {
            RetryStrategy next = new RetryStrategy();
            // decrement the max retries for the next time
            next.setMaxRetries(Math.max(0, this.getMaxRetries() - 1));
            next.setRetryIntervalSeconds(this.getRetryIntervalSeconds());
            next.setShouldRetryHandler(this.getShouldRetryHandler());
            return next;
        }
    }

    private HttpClient httpClient;
    private ObjectMapper objectMapper;

    Map<String, String> urls = new ConcurrentHashMap<>();

    private static final long DEFAULT_MAX_RESPONSE_SIZE_BYTES = 5000000;

    private RetryStrategy defaultRetryStrategy;


    private String enterpriseApiUrl = null;

    public void setDefaultRetryStrategy(RetryStrategy retryStrategy) {
        this.defaultRetryStrategy = retryStrategy;
    }


    public SimplifiedApiClient(String clientName, String eapiUrl) {

        enterpriseApiUrl = eapiUrl;
        objectMapper = new ObjectMapper();
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
        // dont fail if server returns an unknown field
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        // dont serialize null fields
        objectMapper.setSerializationInclusion(Include.NON_NULL);

        if (logger.isWarnEnabled()) {
            objectMapper.addHandler(new DeserializationProblemHandler() {
                @Override
                public boolean handleUnknownProperty(DeserializationContext context, JsonParser jsonParser,
                                                     JsonDeserializer<?> deserializer, Object obj, String propertyName)
                        throws IOException {

                    String name = null;
                    if (obj != null && obj.getClass() != null) {
                        name = obj.getClass().getName();
                    }
                    final String unknownField = String.format("Ignoring unknown property %s while deserializing %s",
                            propertyName, name);
                    logger.warn(unknownField);

                    // https://fasterxml.github.io/jackson-databind/javadoc/2.2.0/com/fasterxml/jackson/databind/deser/DeserializationProblemHandler.html
                    // states
                    // "version 1.2 added new deserialization feature
                    // (DeserializationConfig.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES).
                    // It will only have effect after handler is called, and only if handler did not
                    // handle the problem." end quote
                    // have to return false here so that the DeserializationFeature is effective.
                    return false;
                }
            });
        }


        this.httpClient = HttpClientBuilder.create().build();


    }

    private JsonNode toJson(String response) throws ApiException {
        JsonNode jsonBody = null;
        try {
            jsonBody = objectMapper.readTree(response);
        } catch (IllegalStateException | IOException e) {
            throw new ApiException(500, e);
        }
        return jsonBody;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private Object toObject(JsonNode jsonBody, Class cls) throws ApiException {
        if (isErrorObject(jsonBody)) {
            throw new ApiException();
        } else {
            return objectMapper.convertValue(jsonBody, cls);
        }
    }


    private boolean isErrorObject(JsonNode jsonBody) {
        // TODO: return true if this JSON is a JSON Object which is an error response
        // object
        return (jsonBody.has("message") || jsonBody.has("display_message_id")) && jsonBody.has("code");
    }

    @SuppressWarnings("rawtypes")
    private Object toList(JsonNode jsonBody, Class cls) throws ApiException {
        if (isErrorObject(jsonBody)) {
            throw new ApiException();
        } else {
            JavaType javaType = objectMapper.getTypeFactory().constructCollectionType(List.class, cls);
            return objectMapper.convertValue(jsonBody, javaType);
        }
    }

    private String parameterToString(Object param) {
        if (param == null) {
            return "";
        } else if (param instanceof Collection) {
            StringBuilder b = new StringBuilder();
            for (Object o : (Collection<?>) param) {
                if (b.length() > 0) {
                    b.append(",");
                }
                b.append(o);
            }
            return b.toString();
        } else {
            return String.valueOf(param);
        }
    }

    public String escapeString(String str) {
        try {
            return URLEncoder.encode(str, "utf8").replaceAll("\\+", "%20");
        } catch (UnsupportedEncodingException e) {
            return str;
        }
    }

    private String getBasePath(String path) {
        if (path.startsWith("http")) {
            return path;
        }

        String url = urls.get(path);
        if (url == null) {


            url = enterpriseApiUrl;
            if (url.endsWith("/")) {
                url = url.substring(0, url.length() - 1);
            }
            url = url + path;

            urls.put(path, url);
        }
        return url;
    }


    private String buildUrl(String path, Map<String, String> queryParams) {
        final StringBuilder url = new StringBuilder();

        url.append(getBasePath(path));

        if (queryParams != null && !queryParams.isEmpty()) {
            // support (constant) query string in `path`, e.g. "/posts?draft=1"
            String prefix = "?"; // path.contains("?") ? "&" : "?";

            for (Entry<String, String> param : queryParams.entrySet()) {
                if (param.getKey() != null) {
                    if (prefix != null) {
                        url.append(prefix);
                        prefix = null;
                    } else {
                        url.append("&");
                    }
                    String value = parameterToString(param.getValue());
                    url.append(escapeString(param.getKey())).append("=").append(escapeString(value));
                }
            }
        }

        return url.toString();
    }

    String toJson(Object object) throws ApiException {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (Exception e) {
            logger.error("Failed to get JSON from object: " + object == null ? "null" : object.toString(), e);
            throw new ApiException(e);
        }
    }

    @SuppressWarnings("rawtypes")
    public Object doPostGetList(String path, Object body, Map<String, String> headers,
                                Map<String, String> responseHeaders, Class returnType) throws ApiException {
        return toList(toJson(doPost(path, body, headers, responseHeaders)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doPostGetObject(String path, Object body, Map<String, String> headers,
                                  Map<String, String> responseHeaders, Class returnType) throws ApiException {
        return toObject(toJson(doPost(path, body, headers, responseHeaders)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doPostGetList(String path, Object body, Map<String, String> headers,
                                Map<String, String> responseHeaders, Class returnType, RetryStrategy retryStrategy) throws ApiException {
        return toList(toJson(doPost(path, body, headers, responseHeaders, retryStrategy)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doPostGetObject(String path, Object body, Map<String, String> headers,
                                  Map<String, String> responseHeaders, Class returnType, RetryStrategy retryStrategy) throws ApiException {
        return toObject(toJson(doPost(path, body, headers, responseHeaders, retryStrategy)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doGetObject(String path, Map<String, String> params, Map<String, String> headers,
                              Map<String, String> responseHeaders, Class returnType) throws ApiException {
        return toObject(toJson(doGet(path, params, headers, responseHeaders)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doGetList(String path, Map<String, String> params, Map<String, String> headers,
                            Map<String, String> responseHeaders, Class returnType) throws ApiException {
        return toList(toJson(doGet(path, params, headers, responseHeaders)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doGetObject(String path, Map<String, String> params, Map<String, String> headers,
                              Map<String, String> responseHeaders, Class returnType, RetryStrategy retryStrategy) throws ApiException {
        return toObject(toJson(doGet(path, params, headers, responseHeaders, retryStrategy)), returnType);
    }

    @SuppressWarnings("rawtypes")
    public Object doGetList(String path, Map<String, String> params, Map<String, String> headers,
                            Map<String, String> responseHeaders, Class returnType, RetryStrategy retryStrategy) throws ApiException {
        return toList(toJson(doGet(path, params, headers, responseHeaders, retryStrategy)), returnType);
    }

    public String doPost(String path, Object body, Map<String, String> headers, Map<String, String> responseHeaders)
            throws ApiException {
        return doPost(path, body, headers, responseHeaders, defaultRetryStrategy);
    }

    private void waitBeforeNextRetry(RetryStrategy retryStrategy, String path, Exception e) {
        logger.warn("Request to " + path + " failed with exception", e);
        waitSeconds(retryStrategy.getRetryIntervalSeconds());
    }

    private void waitBeforeNextRetry(RetryStrategy retryStrategy, String path, StatusLine statusLine) {
        logger.warn("Request to " + path + " failed with status: " + statusLine.getStatusCode() + ": " + statusLine.getReasonPhrase());
        waitSeconds(retryStrategy.getRetryIntervalSeconds());
    }

    private void waitSeconds(int seconds) {
        logger.warn("Waiting " + seconds + " seconds...");
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e1) {
            // if we are interrupted we should throw
            throw new RuntimeException(e1);
        }
    }


    public String doPost(String path, Object body, Map<String, String> headers, Map<String, String> responseHeaders,
                         RetryStrategy retryStrategy) throws ApiException {
        long startTime = System.currentTimeMillis();

        StringBuilder trace = null;

        HttpPost post = new HttpPost(getBasePath(path));

        addHeaders(post, headers);
        post.addHeader("Content-Type", "application/json");


        try {
            String json = toJson(body);

            trace = appendTraceRequest(trace, "POST", path, post.getAllHeaders(), json);

            post.setEntity(new StringEntity(json));
        } catch (UnsupportedEncodingException e) {
            throw new ApiException(e);
        }

        /*
         * TODO: handle 401 for expired token If we get expired token error (and we are
         * NOT calling SessionToken API), we can try to refresh the token here... We'd
         * need to call the SessionToken API and we'd need to pass the long-lived token.
         * Find a way to generalize this so we only need to do this in ONE place, right
         * here.
         *
         */
        try {
            HttpResponse response = httpClient.execute(post);
            // TODO: should we check status code before we read the response payload?
            String responseString = this.getResponseString(response);

            StatusLine statusLine = response.getStatusLine();

            trace = appendTraceResponse(trace, startTime, statusLine, response.getAllHeaders(), responseString);

            if (statusLine.getStatusCode() != 200) {

                if (retryStrategy != null && retryStrategy.shouldRetry(statusLine)) {
                    waitBeforeNextRetry(retryStrategy, path, statusLine);
                    logger.warn("Retrying POST to " + path);
                    return doPost(path, body, headers, responseHeaders, retryStrategy.next());
                }
                throw new ApiException();
            }
            setResponseHeaders(response.getAllHeaders(), responseHeaders);
            return responseString;
        } catch (Exception e) {
            trace = traceAppendException(trace, startTime, e);
            if (retryStrategy != null && retryStrategy.shouldRetry(e)) {
                waitBeforeNextRetry(retryStrategy, path, e);
                logger.warn("Retrying POST to " + path);
                return doPost(path, body, headers, responseHeaders, retryStrategy.next());
            }
            if (e instanceof ApiException) {
                throw (ApiException) e;
            } else {
                throw new ApiException(500, e);
            }
        } finally {
            if (trace != null && tracelog.isDebugEnabled()) {
                tracelog.debug(trace.toString());
            }
        }
    }


    private String getResponseString(HttpResponse response) throws IOException {
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            if (entity.getContentLength() > DEFAULT_MAX_RESPONSE_SIZE_BYTES) {
                throw new IOException("Response too big.");
            }
            // TODO: only read up to max length and throw if too long
            String body = EntityUtils.toString(entity, "UTF-8");
            if (body.length() > DEFAULT_MAX_RESPONSE_SIZE_BYTES) {
                throw new IOException("Response too big.");
            }
            return body;
        } else {
            return null;
        }
    }

    private StringBuilder appendTraceRequest(StringBuilder trace, String method, String path, Header[] headers, String payload) {
        if (tracelog.isDebugEnabled()) {
            if (trace == null) {
                trace = new StringBuilder();
            }
            trace.append("EAPI_" + method + "=").append(getBasePath(path));
            if (tracelog_head.isDebugEnabled()) {
                trace.append("\nEAPI_REQ_HEADER=").append(toMap(headers));
            }
            if (payload != null) {
                trace.append("\nEAPI_REQ_PAYLOAD=").append(payload);
            }
        }
        return trace;
    }

    private Map<String, String> toMap(Header[] headers) {
        Map<String, String> map = new TreeMap<>();
        if (headers != null) {
            for (Header header : headers) {
                map.put(header.getName(), header.getValue());
            }
        }
        return map;
    }

    private StringBuilder appendTraceResponse(StringBuilder trace, long startTime, StatusLine statusLine, Header[] headers, String body) {
        if (tracelog.isDebugEnabled()) {
            if (trace == null) {
                trace = new StringBuilder();
            }
            trace.append("\nEAPI_STATUS=").append(statusLine.getStatusCode()).append(": ")
                    .append(statusLine.getReasonPhrase());
            trace.append("\nEAPI_ELAPSED=").append("" + (System.currentTimeMillis() - startTime)).append("ms");

            if (tracelog_head.isDebugEnabled()) {
                trace.append("\nEAPI_RES_HEADER=").append(toMap(headers));
            }

            trace.append("\nEAPI_RES_PAYLOAD=").append(body);
        }
        return trace;
    }

    private StringBuilder traceAppendException(StringBuilder trace, long startTime, Exception e) {
        if (tracelog.isDebugEnabled()) {
            if (trace == null) {
                trace = new StringBuilder();
            }
            trace.append("\nEAPI_ELAPSED=").append("" + (System.currentTimeMillis() - startTime)).append("ms");
            trace.append("\nEAPI_EXCEPTION=").append(e.getClass().getName()).append(":").append(e.getMessage());
        }
        return trace;
    }

    public String doGet(String path, Map<String, String> params, Map<String, String> headers,
                        Map<String, String> responseHeaders) throws ApiException {
        return doGet(path, params, headers, responseHeaders, defaultRetryStrategy);
    }


    private void setResponseHeaders(Header[] headers, Map<String, String> responseHeaders) {
        if (responseHeaders != null && headers != null) {
            for (Header header : headers) {
                responseHeaders.put(header.getName(), header.getValue());
            }
        }
    }

    public String doGet(String path, Map<String, String> params, Map<String, String> headers,
                        Map<String, String> responseHeaders, RetryStrategy retryStrategy) throws ApiException {
        String url = buildUrl(path, params);

        long startTime = System.currentTimeMillis();

        StringBuilder trace = null;

        HttpGet get = new HttpGet(url);

        addHeaders(get, headers);

        trace = appendTraceRequest(trace, "GET", path, get.getAllHeaders(), null);

        try {
            HttpResponse response = httpClient.execute(get);

            // TODO: should we check status code before we read the response payload?
            String responseString = getResponseString(response);

            StatusLine statusLine = response.getStatusLine();

            trace = appendTraceResponse(trace, startTime, statusLine, response.getAllHeaders(), responseString);

            if (statusLine.getStatusCode() != 200) {

                if (retryStrategy != null && retryStrategy.shouldRetry(statusLine)) {
                    waitBeforeNextRetry(retryStrategy, path, statusLine);
                    logger.warn("Retrying GET to " + path);
                    return doGet(path, params, headers, responseHeaders, retryStrategy.next());
                }

                throw new ApiException();
            }
            setResponseHeaders(response.getAllHeaders(), responseHeaders);
            return responseString;
        } catch (Exception e) {
            trace = traceAppendException(trace, startTime, e);
            if (retryStrategy != null && retryStrategy.shouldRetry(e)) {
                waitBeforeNextRetry(retryStrategy, path, e);
                logger.warn("Retrying GET to " + path);
                return doGet(path, params, headers, responseHeaders, retryStrategy.next());
            }
            if (e instanceof ApiException) {
                throw (ApiException) e;
            } else {
                throw new ApiException(500, e);
            }
        } finally {
            if (trace != null && tracelog.isDebugEnabled()) {
                tracelog.debug(trace.toString());
            }
        }
    }


    void addHeaders(HttpRequestBase request, Map<String, String> headers) {
        for (Entry<String, String> header : headers.entrySet()) {
            request.addHeader(header.getKey(), header.getValue());
        }
        request.addHeader("Accept", "application/json");
        request.addHeader("User-Agent", "Kasisto");
        if (!headers.containsKey("request_id")) {
            request.addHeader("request_id", UUID.randomUUID().toString());
        }
        request.addHeader("Date", DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now(ZoneOffset.UTC)));

    }
}