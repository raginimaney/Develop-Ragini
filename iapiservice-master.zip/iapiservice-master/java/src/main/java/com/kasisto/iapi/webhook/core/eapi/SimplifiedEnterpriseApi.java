package com.kasisto.iapi.webhook.core.eapi;

import com.kasisto.api.model.*;
import domain.lola.user.bb.Offer;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * NOTE: DO NOT MODIFY THIS CODE HERE.  IT SHOULD BE MOVED INTO A LIBRARY PUBLISHED OUT OF KAI PROJECT
 *
 * @author jon
 */
public interface SimplifiedEnterpriseApi {

    List<Account> accounts(String secret, String token, AccountsRequest accountsRequest,
                           Map<String, String> responseHeaders) throws ApiException;

    Customer customer(String secret, String token, CustomerRequest customerRequest, Map<String, String> responseHeaders)
            throws ApiException;

    List<Payee> payees(String secret, String token, PayeesRequest payeesRequest, Map<String, String> responseHeaders)
            throws ApiException;

    List<Category> categories(String secret, String token, CategoriesRequest categoriesRequest,
                              Map<String, String> responseHeaders) throws ApiException;

    List<Merchant> merchants(String secret, String token, MerchantsRequest merchantsRequest,
                             Map<String, String> responseHeaders) throws ApiException;

    List<Transaction> transactions(String secret, String token, TransactionCriteria transactionCriteria,
                                   Map<String, String> responseHeaders) throws ApiException;

    CustomerActionResponse customerAction(HeaderData hData, CustomerActionRequest actionRequest, Map<String, String> responseHeaders)
            throws ApiException;



    List<Offer> bankOffers(String secret, String token, OfferRequest offerRequest, Map<String, String> responseHeaders) throws ApiException;

}