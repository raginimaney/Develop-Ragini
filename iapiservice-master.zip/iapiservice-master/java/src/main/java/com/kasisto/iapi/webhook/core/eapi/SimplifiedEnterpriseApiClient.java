package com.kasisto.iapi.webhook.core.eapi;

import com.kasisto.api.model.*;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedApiClient.RetryStrategy;
import domain.lola.user.bb.BankLocation;
import domain.lola.user.bb.BankLocationCriteria;
import domain.lola.user.bb.Offer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.NoHttpResponseException;
import org.apache.http.conn.HttpHostConnectException;

import java.net.ConnectException;
import java.util.*;


/**
 * NOTE: DO NOT MODIFY THIS CODE HERE.  IT SHOULD BE MOVED INTO A LIBRARY PUBLISHED OUT OF KAI PROJECT
 * <p>
 * Based on EnterpriseApiClient but pared down to remove
 * <p>
 * 1) Dependencies on sri or core (e.g. com.sri.vpa.util.EnvConf or com.kasisto.client.ApiClient)
 * <p>
 * TODO: Make a lean version of this dependency available as a maven dependency across other projects.
 *
 * @author jon
 */
public class SimplifiedEnterpriseApiClient implements SimplifiedEnterpriseApi {

    private static SimplifiedEnterpriseApiClient INSTANCE = null;


    static private Log log = LogFactory.getLog(SimplifiedEnterpriseApiClient.class);
    public static String SUPPORTED_METHODS_LIST = "accounts,transactions,customer,customer_action";

    public synchronized static SimplifiedEnterpriseApi getInstance(String url) {
        if (INSTANCE == null) {

            SimplifiedApiClient apiClient = new SimplifiedApiClient("ent-apiclient", url);

            // setup retry strategy for EAPI
            apiClient.setDefaultRetryStrategy(createDefaultRetryStrategy());

            INSTANCE = new SimplifiedEnterpriseApiClient(apiClient);
            INSTANCE.supportedMethods = loadSupportedMethods();

        }
        return INSTANCE;
    }

    private static Set<String> loadSupportedMethods() {
        Set<String> supported_methods = new HashSet<String>();


        if (SUPPORTED_METHODS_LIST != null && !SUPPORTED_METHODS_LIST.isEmpty()) {
            StringTokenizer st = new StringTokenizer(SUPPORTED_METHODS_LIST, ",");
            while (st.hasMoreTokens()) {
                supported_methods.add(st.nextToken());
            }
        }
        return supported_methods;
    }

    private final static int DEFAULT_RETRY_MAX = 0;
    private final static int DEFAULT_RETRY_INTERVAL_SECONDS = 1;

    private static RetryStrategy createDefaultRetryStrategy() {
        RetryStrategy retryStrategy = new RetryStrategy();
        retryStrategy.setMaxRetries(DEFAULT_RETRY_MAX);
        retryStrategy.setRetryIntervalSeconds(DEFAULT_RETRY_INTERVAL_SECONDS);
        retryStrategy.setShouldRetryHandler((statusLine, exception) -> {
            //TODO: which error codes are appropriate for retry?
            // 429 - too many requests
            //TODO: Handle Retry-After header? https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After

            if (statusLine != null &&
                    (
                            statusLine.getStatusCode() == 502 ||
                                    statusLine.getStatusCode() == 503 ||
                                    statusLine.getStatusCode() == 504
                    )
            ) {
                return true;
            }
            if (exception != null) {
                //TODO: which exception types are appropriate for retry?
                return ((exception instanceof NoHttpResponseException) ||
                        (exception instanceof HttpHostConnectException) ||
                        (exception instanceof ConnectException));
            }
            return false;
        });
        return retryStrategy;
    }

    private SimplifiedApiClient apiClient;
    private Set<String> supportedMethods = null;

    private SimplifiedEnterpriseApiClient(SimplifiedApiClient apiClient) {
        this.apiClient = apiClient;
    }
    

    public SimplifiedApiClient getApiClient() {
        return apiClient;
    }

    private void assertRequired(String name, Object value) throws ApiException {
        if (value == null) {
            if (name.equals("token")) {
                throw new ApiException(ApiException.INVALID_TOKEN, "Missing the required parameter: " + name);
            } else {
                throw new ApiException(ApiException.DEFAULT_ERROR_CODE, "Missing the required parameter: " + name);
            }
        }
    }

    private boolean isMethodSupported(String name) {
        return ((supportedMethods == null || supportedMethods.isEmpty()) || supportedMethods.contains(name));
    }


    private Map<String, String> makeHeaders(String secret, String token) {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("secret", secret);
        if (token != null) {
            headers.put("token", token);
        }
        return headers;
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#accounts(java.lang.String, java.lang.String, com.kasisto.api.model.AccountsRequest, java.util.Map)
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Account> accounts(String secret, String token, AccountsRequest accountsRequest, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);
        assertRequired("accountsRequest", accountsRequest);

        if (isMethodSupported("accounts")) {
            try {
                return (List<Account>) apiClient.doPostGetList("/accounts", accountsRequest, makeHeaders(secret, token), responseHeaders, Account.class);
            } catch (ApiException e) {
                // If no data (204) return an empty list
                if (e.getCode() != 204) {
                    throw e;
                }
            }
        }

        return new ArrayList<Account>();
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#customer(java.lang.String, java.lang.String, com.kasisto.api.model.CustomerRequest, java.util.Map)
     */
    @Override
    public Customer customer(String secret, String token, CustomerRequest customerRequest, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);
        assertRequired("customerRequest", customerRequest);

        if (isMethodSupported("customer")) {
            return (Customer) apiClient.doPostGetObject("/customer", customerRequest, makeHeaders(secret, token), responseHeaders, Customer.class);
        } else {
            Customer customer = new Customer();
            customer.setUserId(customerRequest.getUserId());
            customer.setFirstName(customerRequest.getUserId());
            customer.setFullName(customerRequest.getUserId());
            return customer;
        }
    }

	/*public TokenResponse token(String secret, List<MetaField> metaValues, Map<String,String> responseHeaders) throws ApiException {
		assertRequired("secret", secret);
		if(isMethodSupported("token")) {
			return (TokenResponse) apiClient.doPostGetObject("/token", new TokenRequest(metaValues), makeHeaders(secret,null), responseHeaders,TokenResponse.class);
		} else
			return null;
	}*/

    public TokenResponse sessionToken(String secret, String token, SessionTokenRequest sessionTokenRequest, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("session_token")) {
            return (TokenResponse) apiClient.doPostGetObject("/session_token", sessionTokenRequest, makeHeaders(secret, token), responseHeaders,
                    TokenResponse.class);
        } else {
            return null;
        }
    }

    public TokenResponse revokeToken(String secret, String token, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("revoke_token")) {
            return (TokenResponse) apiClient.doPostGetObject("/revoke_token", token, makeHeaders(secret, token), responseHeaders,
                    TokenResponse.class);
        } else {
            return null;
        }
    }

    public ValidateOtpResponse validateOtp(String secret, String token, ValidateOtpRequest validateOtpRequest, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("validate_otp")) {
            return (ValidateOtpResponse) apiClient.doPostGetObject("/validate_otp", validateOtpRequest, makeHeaders(secret, token), responseHeaders,
                    ValidateOtpResponse.class);
        } else {
            return null;
        }
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#payees(java.lang.String, java.lang.String, com.kasisto.api.model.PayeesRequest, java.util.Map)
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Payee> payees(String secret, String token, PayeesRequest payeesRequest, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("payees")) {
            try {
                return (List<Payee>) apiClient.doPostGetList("/payees", payeesRequest, makeHeaders(secret, token), responseHeaders, Payee.class);
            } catch (ApiException e) {
                // If no data (204) return an empty list
                if (e.getCode() != 204) {
                    throw e;
                }
            }
        }
        return new ArrayList<Payee>();
    }

    public List<BankLocation> bank_locations(String secret, String token, BankLocationCriteria bankLocationCriteria, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        //	assertRequired("token", token);
        if (isMethodSupported("bank_locations")) {
            return (List<BankLocation>) apiClient.doPostGetList("/bank_locations", bankLocationCriteria, makeHeaders(secret, token), responseHeaders, BankLocation.class);
        } else {
            return new ArrayList<BankLocation>();
        }
    }

    @Override
    public List<Offer> bankOffers(String secret, String token, OfferRequest offerRequest, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        //	assertRequired("token", token);
        if (isMethodSupported("offers")) {
            return (List<Offer>) apiClient.doPostGetList("/offers", offerRequest, makeHeaders(secret, token), responseHeaders, Offer.class);
        } else {
            return new ArrayList<Offer>();
        }
    }

    public Payment payment(String secret, String token, PaymentRequest paymentRequest, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("payment")) {
            return (Payment) apiClient.doPostGetObject("/payment", paymentRequest, makeHeaders(secret, token), responseHeaders, Payment.class);
        } else {
            throw new ApiException(ApiException.NOT_IMPLEMENTED, "/payment method not supported.");
        }
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#categories(java.lang.String, java.lang.String, com.kasisto.api.model.CategoriesRequest, java.util.Map)
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Category> categories(String secret, String token, CategoriesRequest categoriesRequest, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("categories")) {
            try {
                return (List<Category>) apiClient.doPostGetList("/categories", categoriesRequest, makeHeaders(secret, token), responseHeaders, Category.class);
            } catch (ApiException e) {
                // If no data (204) return an empty list
                if (e.getCode() != 204) {
                    throw e;
                }
            }
        }
        return new ArrayList<Category>();
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#merchants(java.lang.String, java.lang.String, com.kasisto.api.model.MerchantsRequest, java.util.Map)
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Merchant> merchants(String secret, String token, MerchantsRequest merchantsRequest, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("merchants")) {
            try {
                return (List<Merchant>) apiClient.doPostGetList("/merchants", merchantsRequest, makeHeaders(secret, token), responseHeaders, Merchant.class);
            } catch (ApiException e) {
                // If no data (204) return an empty list
                if (e.getCode() != 204) {
                    throw e;
                }
            }
        }
        return new ArrayList<Merchant>();
    }

    /* (non-Javadoc)
     * @see com.kasisto.guidedconversation.impl.guai.SimplifiedEnterpriseApi#transactions(java.lang.String, java.lang.String, com.kasisto.api.model.TransactionCriteria, java.util.Map)
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Transaction> transactions(String secret, String token, TransactionCriteria transactionCriteria, Map<String, String> responseHeaders)
            throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);
        assertRequired("transactionCriteria", transactionCriteria);

        if (isMethodSupported("transactions")) {
            try {
                return (List<Transaction>) apiClient.doPostGetList("/transactions", transactionCriteria, makeHeaders(secret, token), responseHeaders,
                        Transaction.class);
            } catch (ApiException e) {
                // If no data (204) return an empty list
                if (e.getCode() != 204) {
                    throw e;
                }
            }
        }
        return new ArrayList<Transaction>();
    }

    public Transfer transfer(String secret, String token, TransferRequest transferRequest, Map<String, String> responseHeaders) throws ApiException {
        assertRequired("secret", secret);
        assertRequired("token", token);

        if (isMethodSupported("transfer")) {
            return (Transfer) apiClient.doPostGetObject("/transfer", transferRequest, makeHeaders(secret, token), responseHeaders, Transfer.class);
        } else {
            throw new ApiException(ApiException.NOT_IMPLEMENTED, "/transfer method is not supported.");
        }
    }

    private Map<String, String> getCommonRequestHeaderMap(HeaderData hData) {
        final Map<String, String> rMap = new TreeMap<>();
        rMap.put("secret", hData.getSecret());
        rMap.put("token", hData.getToken());
        rMap.put("locale", hData.getLocale());
        return rMap;
    }

    @Override
    @SuppressWarnings("unchecked")
    public CustomerActionResponse customerAction(HeaderData hData,
                                                 CustomerActionRequest actionRequest, Map<String, String> responseHeaders)
            throws ApiException {

        assertRequired("secret", hData.getSecret());
        assertRequired("token", hData.getToken());

        final Map<String, String> reqHeader = getCommonRequestHeaderMap(hData);

        if (!isMethodSupported("customer_action")) {
            throw new ApiException(ApiException.NOT_IMPLEMENTED, "/customer_action method is not supported.");
        }

        return (CustomerActionResponse) apiClient.doPostGetObject("/customer_action", actionRequest, reqHeader,
                responseHeaders, CustomerActionResponse.class);
    }


}
