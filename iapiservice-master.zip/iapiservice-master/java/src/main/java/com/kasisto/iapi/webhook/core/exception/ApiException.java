package com.kasisto.iapi.webhook.core.exception;

/**
 * This is standard exception raised when something goes wrong with the
 * procession.
 *
 * @author olivier
 */
public class ApiException extends Exception {

    private static final long serialVersionUID = -7733428161815951753L;

    public static final int AUTH_FAILED = 401;
    public static final int ACCESS_DENIED = 403;
    public static final int OTP_REQUIRED = 450;
    public static final int SERVER_ERROR = 500;
    public static final int NOT_IMPLEMENTED = 501;

    private final int code;

    public ApiException(int code, String msg) {
        super(msg);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
