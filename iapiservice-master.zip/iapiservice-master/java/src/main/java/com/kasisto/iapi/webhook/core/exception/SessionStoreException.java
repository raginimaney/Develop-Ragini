package com.kasisto.iapi.webhook.core.exception;

public class SessionStoreException extends Exception {

    public SessionStoreException(String msg) {
        super(msg);
    }
}
