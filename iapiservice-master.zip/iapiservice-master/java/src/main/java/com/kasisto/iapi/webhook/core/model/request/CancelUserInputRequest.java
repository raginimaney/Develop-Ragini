package com.kasisto.iapi.webhook.core.model.request;

import java.util.List;

public class CancelUserInputRequest {

    public Context context;
    public String conversation_id;

    public List<UserInput> user_inputs;
}