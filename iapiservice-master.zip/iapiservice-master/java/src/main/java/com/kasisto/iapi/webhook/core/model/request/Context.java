package com.kasisto.iapi.webhook.core.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Arrays;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Context {

    public Device device;

    public User user;

    public String api_version;

    public class User {
        public String user_id;
        public String session_id;
        public String[] segment_names;
        public String time_zone;
        public Location location;

        public class Location{
            public String latitude;
            public String longitude;
        }
    }

    public class Device {
        public String type;
        public String model;
        public String os;
        public String id;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        if(api_version != null){
            sb.append("api_version="+api_version);
        }
        if (device != null) {
            sb.append("device=" + device + ",");
        }
        if (user != null && user.segment_names != null) {
            sb.append("user" + user.user_id + "," + Arrays.toString(user.segment_names));
        }
        return sb.toString();
    }
}
