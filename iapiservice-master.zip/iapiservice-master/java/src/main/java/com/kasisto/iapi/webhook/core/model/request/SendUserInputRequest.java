package com.kasisto.iapi.webhook.core.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SendUserInputRequest {

    public Context context;
    public String conversation_id;

    public List<UserInput> user_inputs;
    public UserMessage user_message;

    public String exception_message;
    public String reason;

    public SendUserInputRequest() {

    }

    public SendUserInputRequest(List<UserInput> user_inputs) {
        this.user_inputs = user_inputs;
    }

    public SendUserInputRequest(String conversation_id, List<UserInput> user_inputs) {
        this.user_inputs = user_inputs;
        this.conversation_id = conversation_id;
    }

    public SendUserInputRequest(String conversation_id, UserInput user_input) {
        this.user_inputs = new ArrayList<UserInput>();
        this.user_inputs.add(user_input);
        this.conversation_id = conversation_id;
    }
}
