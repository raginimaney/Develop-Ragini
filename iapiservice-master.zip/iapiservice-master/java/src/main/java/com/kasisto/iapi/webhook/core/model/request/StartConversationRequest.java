package com.kasisto.iapi.webhook.core.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)

public class StartConversationRequest {

    public Context context;
    public String intent_name;

    public List<UserInput> user_inputs;
    public UserMessage user_message;

    public StartConversationRequest() {

    }


    public StartConversationRequest(String intent_name) {
        this.intent_name = intent_name;
        this.user_inputs = new ArrayList<UserInput>();
    }

    public StartConversationRequest(String intent_name, UserInput user_inputs) {
        this.intent_name = intent_name;
        this.user_inputs = new ArrayList<UserInput>();
        this.user_inputs.add(user_inputs);
    }

    public StartConversationRequest(String intent_name, List<UserInput> user_inputs) {
        // TODO Auto-generated constructor stub
        this.intent_name = intent_name;
        this.user_inputs = user_inputs;
    }

}
