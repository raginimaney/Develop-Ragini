package com.kasisto.iapi.webhook.core.model.request;

import java.io.Serializable;

public class SystemInput implements Serializable {

    public String name;
    public String value;
    public String currency;

    @Override
    public String toString() {
        return "UserInput [name=" + name + ", value=" + value + "]";
    }

    public SystemInput() {

    }

    public SystemInput(String name, String value) {
        this.name = name;
        this.value = value;
    }
}
