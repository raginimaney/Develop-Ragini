package com.kasisto.iapi.webhook.core.model.request;

import java.io.Serializable;

public class UserInput implements Serializable {

    public String name;
    public String value;
    public String currency;

    @Override
    public String toString() {
        return "UserInput [name=" + name + ", value=" + value + "]";
    }

    public UserInput() {

    }

    public UserInput(String name, String value) {
        this.name = name;
        this.value = value;
    }
}
