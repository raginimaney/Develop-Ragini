package com.kasisto.iapi.webhook.core.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserMessage {
    public String type;


    public Payload payload;

    public class Payload {
        public String text;
    }


    public String toString() {
        return payload.text;
    }
}
