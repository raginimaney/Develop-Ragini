package com.kasisto.iapi.webhook.core.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConversationResponse {

    public enum ConversationState {
        PENDING_USER, CANCELLED, COMPLETED, FAILED, PROCEED
    }

    public String conversation_id;
    public ConversationState conversation_state;

    public List<MessageContent> message_contents = new ArrayList<>();

    public List<QuickReply> quick_replies = new ArrayList<>();


    public RequestUserInput request_user_input;

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("conversation_id=" + conversation_id + ",conversation_state=" + conversation_state + ",message_contents" + message_contents);
        return sb.toString();
    }

    public static class QuickReply {

        public static final String QUICK_REPLY_TYPE_TEXT = "TEXT";
        public static final String QUICK_REPLY_TYPE_CUSTOM = "CUSTOM";

        public String type;
        public String display_text;
        public String payload;


        public QuickReply(String type, String display_text, String payload) {
            this.type = type;
            this.display_text = display_text;
            this.payload = payload;
        }
    }
}
