package com.kasisto.iapi.webhook.core.model.response;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class DefaultMessageTemplates {

    public static String getRandomizedMessage(List<String> template) {
        Random randomGenerator = new Random();
        int index = randomGenerator.nextInt(template.size());
        return template.get(index);
    }

    //Note: message templates with variables
    public static final List<String> DEFAULT_CURRENT_TIME = new ArrayList<>(Arrays.asList(
            "OK the current time is ${now}.",
            "It is ${now}.",
            "As yoda would say, ${now} the time it is."
    ));

    public static final List<String> DEFAULT_GOODBYE = new ArrayList<>(Arrays.asList(
            "OK Goodbye.", "Thanks. Goodbye.", "Got it. Goodbye."
    ));

    public static final List<String> DEFAULT_FATAL = new ArrayList<>(Arrays.asList(
            "Sorry. There has been a problem. Please try again later.",
            "I'm sorry. Please try again."
    ));

    public static final List<String> DEFAULT_RETRY = new ArrayList<>(Arrays.asList(
            "What was that?",
            "Sorry. What was that?",
            "I missed that. Rephrase it, please?",
            "I didn't catch that. Rephrase it, please?",
            "Oops. Didn't catch that. Could you rephrase?",
            "I haven't understood. Rephrase, please?",
            "Didn't quite get that. Try saying it another way.",
            "Sorry, I'm not following. Rephrase, please?",
            "That's not clear to me. Rephrase, please?",
            "I didn't catch your drift. Rephrase, please?",
            "A little lost. Apologies. Could you rephrase?",
            "Didn't catch that. Would you mind rephrasing?",
            "Lost you there, sorry. Could you rephrase?",
            "Missed that last bit. Could you rephrase?",
            "I've dropped the ball. Could you rephrase?",
            "Oops. Signal fuzzy. Could you rephrase?"
    ));

    public static final List<String> DEFAULT = new ArrayList<>(Arrays.asList(
            "What is the next value",
            "Next value please"
    ));

    public static final List<String> DEFAULT_BOOL = new ArrayList<>(Arrays.asList(
            "What is the boolean value?",
            "Please answer yes or no?",
            "True or false?"
    ));

    public static final List<String> DEFAULT_BOOL_RETRY = new ArrayList<>(Arrays.asList(
            "OK. Let's try that again. What is the boolean value?",
            "OK. Let's try that again. Please answer yes or no?",
            "OK.  Again. true or false?"
    ));

    public static final List<String> DEFAULT_MESSAGE_REGISTER = new ArrayList<>(Arrays.asList(
            "Great question. I'm glad to chat, but for me to help with that, you'll need to link an account. Please log in"
    ));

    public static final List<String> DEFAULT_MESSAGE_ACCOUNT_NOT_FOUND = new ArrayList<>(Arrays.asList(
            "I can't find that account"
    ));

    //TODO Add more default templates
}
