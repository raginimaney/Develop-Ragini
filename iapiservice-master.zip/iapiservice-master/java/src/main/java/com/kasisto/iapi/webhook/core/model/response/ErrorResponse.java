package com.kasisto.iapi.webhook.core.model.response;

public class ErrorResponse {

    public String message;
    public String code;
}
