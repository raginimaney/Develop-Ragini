package com.kasisto.iapi.webhook.core.model.response;

public abstract class MessageContent {

    public enum MessageContentType {
        TEXT, BUTTON, CARD, CONTAINER, REF
    }

    public MessageContentType type;
    public MessageContentPayload payload;

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("message content_type=" + type + ",message_content_payload=" + payload);
        return sb.toString();
    }

    public interface MessageContentPayload {
    }

}
