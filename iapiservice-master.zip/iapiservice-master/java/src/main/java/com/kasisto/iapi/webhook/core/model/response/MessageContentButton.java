package com.kasisto.iapi.webhook.core.model.response;

public class MessageContentButton extends MessageContent {

    public MessageContentButton(String label, String type, String payload) {
        this.type = MessageContentType.BUTTON;
        this.payload = new MessageContentButtonPayload(label, type, payload);
    }

    class MessageContentButtonPayload implements MessageContentPayload {

        public String label;
        public String type;
        public String payload;

        MessageContentButtonPayload(String label, String type, String payload) {
            this.label = label;
            this.type = type;
            this.payload = payload;
        }
    }
}
