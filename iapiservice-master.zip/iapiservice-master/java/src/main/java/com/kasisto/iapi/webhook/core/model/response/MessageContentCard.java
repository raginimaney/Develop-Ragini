package com.kasisto.iapi.webhook.core.model.response;

import java.util.List;

public class MessageContentCard extends MessageContent {

  public MessageContentCard(String title, String subtitle, Medium medium, List<Button> buttons) {
    this.type = MessageContentType.CARD;
    this.payload = new MessageContentCardPayload(title, subtitle, medium, buttons);
  }


  public MessageContentCard(String title, String subtitle, Medium medium) {
    this(title, subtitle, medium, null);
  }

  public MessageContentCard(String title, String subtitle, List<Button> buttons) {
    this.type = MessageContentType.CARD;
    this.payload = new MessageContentCardPayload(title, subtitle, null, buttons);
  }

  public MessageContentCard(String title, String subtitle) {
    this.type = MessageContentType.CARD;
    this.payload = new MessageContentCardPayload(title, subtitle, null, null);
  }


  public class MessageContentCardPayload implements MessageContentPayload {

    public String title;
    public String subtitle;
    public Medium medium;
    public List<Button> buttons;

    MessageContentCardPayload(String title, String subtitle, Medium medium, List<Button> buttons) {
      this.title = title;
      this.subtitle = subtitle;
      this.medium = medium;
      this.buttons = buttons;
    }
  }

  public static class Medium {
    public String medium_url;
    public String hyperlink_url;

    public Medium(String medium_url) {
      this.medium_url = medium_url;
    }

    public Medium(String medium_url, String hyperlink_url) {
      this.medium_url = medium_url;
      this.hyperlink_url = hyperlink_url;
    }
  }

  public static class Button {
    public String label;
    public String type;
    public String payload;

    public enum ButtonType{
        HYPERLINK,
        POSTBACK,
        CALL,
        CUSTOM
    }

    public Button(String label, String type, String payload) {
      this.label = label;
      this.type = type;
      this.payload = payload;
    }

    Button(String label, String type) {
      this.label = label;
      this.type = type;
    }
  }
}
