package com.kasisto.iapi.webhook.core.model.response;

import java.util.List;

public class MessageContentContainer extends MessageContent {

    public static final String MSG_CONTAINER_CAROUSEL = "CAROUSEL";
    public static final String MSG_CONTAINER_LIST = "LIST";

    public MessageContentContainer(String mode, List<MessageContent> contents) {
        this.type = MessageContentType.CONTAINER;
        this.payload = new MessageContentContainerPayload(mode, contents);
    }

    public class MessageContentContainerPayload implements MessageContentPayload {

        public String mode;
        public List<MessageContent> contents;

        MessageContentContainerPayload(String mode, List<MessageContent> contents) {
            this.mode = mode;
            this.contents = contents;
        }

        public List<MessageContent> getContents() {
            return contents;
        }
    }

}
