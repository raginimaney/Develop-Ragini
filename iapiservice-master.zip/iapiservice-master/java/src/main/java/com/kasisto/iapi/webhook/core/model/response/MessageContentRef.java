package com.kasisto.iapi.webhook.core.model.response;

public class MessageContentRef extends MessageContent {

    public MessageContentRef(String refId) {
        this.type = MessageContentType.REF;
        this.payload = new MessageContentRefPayload(refId);
    }

    public class MessageContentRefPayload implements MessageContentPayload {

        public String content_id;

        MessageContentRefPayload(String ref) {
            this.content_id = ref;
        }

        public String toString() {
            return content_id;
        }
    }
}
