package com.kasisto.iapi.webhook.core.model.response;

public class MessageContentText extends MessageContent {

    public MessageContentText(String text) {
        this.type = MessageContentType.TEXT;
        this.payload = new MessageContentTextPayload(text);
    }

    public class MessageContentTextPayload implements MessageContentPayload {

        public String text;

        MessageContentTextPayload(String text) {
            this.text = text;
        }

        public String toString() {
            return text;
        }

        public String getTextPayload() {
            return text;
        }
    }
}
