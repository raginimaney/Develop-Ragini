package com.kasisto.iapi.webhook.core.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestUserInput {

    public enum RequestUserInputMode {
        QUICK_REPLIES, CAROUSEL, LIST
    }

    public enum UserInputType {
        NUMBER,
        BOOLEAN,
        DATE,
        PATTERN,
        CURRENCY_AMOUNT,
        EMAIL,
        STRING,
        NORM_CREDIT_CARD_NUMBER,
    }

    public enum OptionalParams {
        validation_error_msg,
        ValidationErrorInvalidOption,
        ValidationErrorInvalidBoolean,
        ValidationErrorInvalidNumber,
        ValidationErrorPatternDoesNotMatch,
        ValidationErrorInvalidDate,
        ValidationErrorInvalidEmail,
        ValidationErrorInvalidCurrencyAmount
    }


    public RequestUserInputMode input_mode;
    public List<Option> options;
    public String name;
    public String type;
    public String pattern;
    public String validation_error_msg;
    public HashMap validation_error_msgs_map;


    public RequestUserInput(String name) {
        this.name = name;
    }

    protected void setType(UserInputType inputType) {
        if (inputType == UserInputType.NORM_CREDIT_CARD_NUMBER) {
            this.type = "norm.credit_card_number";
        } else {
            this.type = inputType.name();
        }

    }

    @JsonIgnore
    public UserInputType getTypeNorm() {

        if (type.equals("norm.credit_card_number")) {
            return UserInputType.NORM_CREDIT_CARD_NUMBER;
        } else {
            return UserInputType.valueOf(type);
        }
    }


    public RequestUserInput(String name, UserInputType inputType) {
        this.name = name;
        this.setType(inputType);
    }


    public RequestUserInput(String name, UserInputType type, HashMap optionalParams) {
        this.name = name;
        this.setType(type);
        parseOptionalParams(optionalParams);
    }

    public RequestUserInput(String name, UserInputType type, String pattern) {
        this.name = name;
        this.setType(type);
        this.pattern = pattern;
    }

    public RequestUserInput(String name, UserInputType inputType, String pattern, HashMap optionalParams) {
        this.name = name;
        this.setType(inputType);
        this.pattern = pattern;
        parseOptionalParams(optionalParams);
    }


    public RequestUserInput(String name, UserInputType inputType, List<QuickReplyOption> options) {
        this.name = name;
        this.setType(inputType);
        this.input_mode = RequestUserInputMode.QUICK_REPLIES;
        this.options = new ArrayList<>(options.size());
        this.options.addAll(options);
    }

    public RequestUserInput(String name, UserInputType type, List<QuickReplyOption> options, HashMap optionalParams) {
        this.name = name;
        this.setType(type);
        this.input_mode = RequestUserInputMode.QUICK_REPLIES;
        this.options = new ArrayList<>(options.size());
        this.options.addAll(options);
        parseOptionalParams(optionalParams);
    }

    public RequestUserInput(String name, UserInputType type, RequestUserInputMode input_mode, List<CardOption> options) {
        this.name = name;
        this.setType(type);
        this.input_mode = input_mode;
        this.options = new ArrayList<>(options.size());
        this.options.addAll(options);
    }

    public RequestUserInput(String name, UserInputType type, RequestUserInputMode input_mode, List<CardOption> options, HashMap optionalParams) {
        this.name = name;
        this.setType(type);
        this.input_mode = input_mode;
        this.options = new ArrayList<>(options.size());
        this.options.addAll(options);
        parseOptionalParams(optionalParams);
    }


    public interface Option {
    }

    public static class QuickReplyOption implements Option {
        public String value;
        public String label;
        public Boolean allow_substring_match = false;
        public List<String> aliases;

        public QuickReplyOption(String value, String label) {
            this.value = value;
            this.label = label;
        }

        public QuickReplyOption(String value, String label, boolean allowSubStringMatch, List<String> aliases) {
            this.value = value;
            this.label = label;
            this.allow_substring_match = allowSubStringMatch;
            this.aliases = aliases;
        }
    }

    public static class CardOption implements Option {
        public String value;
        public boolean enabled;
        public String label;
        public Medium medium;
        public String title;
        public String subtitle;

        public CardOption(String value, boolean enabled, String label, Medium medium, String title, String subtitle) {
            this.value = value;
            this.enabled = enabled;
            this.label = label;
            this.medium = medium;
            this.title = title;
            this.subtitle = subtitle;
        }

        public CardOption(String value, String label, Medium medium, String title, String subtitle) {
            this(value, true, label, medium, title, subtitle);
        }

        public CardOption(String value, String label, String title, String subtitle) {
            this(value, true, label, null, title, subtitle);
        }

    }

    public static class Medium {
        public String medium_url;
        public String hyperlink_url;

        public Medium(String medium_url) {
            this.medium_url = medium_url;
        }

        public Medium(String medium_url, String hyperlink_url) {
            this.medium_url = medium_url;
            this.hyperlink_url = hyperlink_url;
        }
    }


    private void parseOptionalParams(HashMap optional_params) {
        //validation_error_msg
        if (optional_params.containsKey(OptionalParams.validation_error_msg)) {
            this.validation_error_msg = optional_params.get(OptionalParams.validation_error_msg).toString();
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidBoolean)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidBoolean, optional_params.get(OptionalParams.ValidationErrorInvalidBoolean));
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidNumber)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidNumber, optional_params.get(OptionalParams.ValidationErrorInvalidNumber));
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidCurrencyAmount)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidCurrencyAmount, optional_params.get(OptionalParams.ValidationErrorInvalidCurrencyAmount));
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidDate)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidDate, optional_params.get(OptionalParams.ValidationErrorInvalidDate));
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidEmail)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidEmail, optional_params.get(OptionalParams.ValidationErrorInvalidEmail));
        }

        //ValidationErrorInvalidOption
        if (optional_params.containsKey(OptionalParams.ValidationErrorInvalidOption)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorInvalidOption, optional_params.get(OptionalParams.ValidationErrorInvalidOption));
        }
        //ValidationErrorPatternDoesNotMatch
        if (optional_params.containsKey(OptionalParams.ValidationErrorPatternDoesNotMatch)) {
            this.validation_error_msgs_map = new HashMap();
            this.validation_error_msgs_map.put(OptionalParams.ValidationErrorPatternDoesNotMatch, optional_params.get(OptionalParams.ValidationErrorPatternDoesNotMatch));
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("name=" + name + ",type=" + type + ",mode=" + input_mode);
        return sb.toString();
    }


}


