package com.kasisto.iapi.webhook.core.session;

import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.WFState;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple memory session manager used to store the active sessions in memory.
 *
 * @author olivier
 */

public class ConversationSession implements Serializable {

    public String user_id = "";
    public String conversation_id = "";
    public String intentName = "";
    public String token = "";
    public String[] segments = new String[0];
    public String lastMessageText = "";
    public Context context = null;



    //the inputs from the current request
    private Map<String, UserInput> currentUserInputs = new ConcurrentHashMap<String, UserInput>();
    //the inputs from all previous requests
    private final Map<String, UserInput> previousUserInputs = new ConcurrentHashMap<String, UserInput>();
    //the inputs from all system events
    private final Map<String, SystemInput> systemInputs = new ConcurrentHashMap<String, SystemInput>();

    //current workflow state
    public WFState currentWorkflowState;


    @Override
    public String toString() {
        return "[intentName: " + intentName + ", conversation_id: " + conversation_id + ", previousUserInputs: " + previousUserInputs + ",currentUserInputs: " + currentUserInputs + ",lastMessageText: " + lastMessageText + "work_state: " + currentWorkflowState + ",token:" + token + "]";
    }


    /*
    Get the userinputs from the current request
     */
    public Map<String, UserInput> getCurrentUserInputs() {
        return currentUserInputs;
    }

    public Map<String, UserInput> getPreviousUserInputs() {
        return previousUserInputs;
    }

    // Get System Inputs for the current request
    public Map<String, SystemInput> getSystemInputs() {
        return systemInputs;
    }

    /**
     * get the userinputs from the current AND previous request
     *
     * @return
     */
    public Map<String, UserInput> getAccumulatedUserInput() {
        Map<String, UserInput> combineUserInputsMap = new ConcurrentHashMap<String, UserInput>();
        combineUserInputsMap.putAll(previousUserInputs);
        //overwrite the previous inputs
        combineUserInputsMap.putAll(currentUserInputs);
        return combineUserInputsMap;
    }


    /**
     * Promote from the current inputs to the previous set
     */
    public void promoteUserInputs() {
        for (UserInput userInput : currentUserInputs.values()) {
            previousUserInputs.put(userInput.name, userInput);
        }
    }

    public void setCurrentUserInputs(List<UserInput> currentInputs) {

        this.currentUserInputs.clear();
        for (UserInput input : currentInputs) {
            this.currentUserInputs.put(input.name, input);
        }

    }


}
