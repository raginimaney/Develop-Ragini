package com.kasisto.iapi.webhook.core.session;

import com.kasisto.iapi.webhook.core.exception.SessionStoreException;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class InMemorySessionStore implements SessionStore {


    static final Map<String, ConversationSession> SESSIONS = Collections
            .synchronizedMap(new LinkedHashMap<String, ConversationSession>() {
                private static final long serialVersionUID = 1L;

                @Override
                protected boolean removeEldestEntry(@SuppressWarnings("rawtypes") final Map.Entry eldest) {
                    return size() > 50000; // MAX 50 000 entries
                }
            });

    public ConversationSession getConversationSession(String conversation_id) throws SessionStoreException {

        return SESSIONS.get(conversation_id);
    }

    public void saveConversationSession(ConversationSession session) throws SessionStoreException {
        SESSIONS.put(session.conversation_id, session);
    }

    public void deleteConversationSession(ConversationSession session) throws SessionStoreException {
        SESSIONS.remove(session.conversation_id);
    }
}