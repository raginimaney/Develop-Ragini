package com.kasisto.iapi.webhook.core.session;

import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import redis.clients.jedis.Jedis;

import java.io.*;
import java.util.Base64;

public class RedisSessionStore implements SessionStore {


    private Log log = LogFactory.getLog(getClass());
    private Jedis jedis;


    public RedisSessionStore() {

        jedis = new Jedis("localhost");

    }


    public String serialize(ConversationSession session) throws IOException {

        if (session == null || session.conversation_id == null) {
            throw new IOException("cannot serialize null object");
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(session);
        oos.close();
        return Base64.getEncoder().encodeToString(baos.toByteArray());

    }

    public ConversationSession deserialize(String s) throws IOException, ClassNotFoundException {

        byte[] data = Base64.getDecoder().decode(s);

        ObjectInputStream ois = new ObjectInputStream(
                new ByteArrayInputStream(data));
        Object o = ois.readObject();
        ois.close();
        return (ConversationSession) o;

    }


    public ConversationSession getConversationSession(String conversation_id) throws SessionStoreException {
        String result = jedis.get(conversation_id);


        if (result == null) {
            throw new SessionStoreException("got empty result back");
        }

        try {
            ConversationSession session = deserialize(result);
            return session;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        throw new SessionStoreException("Could not find object in cache");
    }

    public void saveConversationSession(ConversationSession session) throws SessionStoreException {


        try {
            String result = jedis.set(session.conversation_id, this.serialize(session));
        } catch (IOException e) {
            throw new SessionStoreException("Could not save object in cache:" + e.toString());
        }


        try {
            ConversationSession newSession = deserialize(jedis.get(session.conversation_id));

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    public void deleteConversationSession(ConversationSession session) throws SessionStoreException {

        jedis.del(session.conversation_id);

    }
}