package com.kasisto.iapi.webhook.core.session;


import com.kasisto.iapi.webhook.core.exception.SessionStoreException;


/**
 * Standard interface for peristing and retrieving session data
 */
public interface SessionStore {


    ConversationSession getConversationSession(String conversation_id) throws SessionStoreException;

    void saveConversationSession(ConversationSession session) throws SessionStoreException;

    void deleteConversationSession(ConversationSession session) throws SessionStoreException;
}