package com.kasisto.iapi.webhook.core.session;

public class SessionStoreFactory {

    public enum StoreType {
        INMEMORY, REDIS
    }

    public static SessionStore getSessionStore(StoreType type) {
        if (type == StoreType.REDIS) {
            return new RedisSessionStore();
        } else {
            return new InMemorySessionStore();
        }
    }
}
