package com.kasisto.iapi.webhook.core.workflow;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import org.jvnet.hk2.annotations.Contract;

@Contract
public interface AbstractIntentProcessorFactory {

    AbstractIntentProcessor get(String intentName) throws ApiException;
}
