package com.kasisto.iapi.webhook.core.workflow;

public class NoTransitionFoundException extends Exception {

    public NoTransitionFoundException(String msg) {
        super(msg);
    }
}


