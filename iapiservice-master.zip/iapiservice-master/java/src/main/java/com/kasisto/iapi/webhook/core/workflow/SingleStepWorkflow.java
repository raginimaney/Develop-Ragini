package com.kasisto.iapi.webhook.core.workflow;


import java.util.ArrayList;
import java.util.List;


/**
 * For a single-step workflow like help, greeting, thankyou, where the primary difference is across the intent processor
 * implementation.   Avoids repetitive boilerplate workflow across simple intents
 */
public class SingleStepWorkflow extends Workflow {


    public enum States implements WFState {
        START, END
    }

    public enum Actions implements WFAction {
        SHOW_ANSWER
    }

    @Override
    public List<WFTransition> generateTransitions() {


        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.SHOW_ANSWER,
                States.START, States.END,
                event -> true)
        );

        return transitions;
    }

    @Override
    public WFState getOrigin() {
        return States.START;
    }
}

