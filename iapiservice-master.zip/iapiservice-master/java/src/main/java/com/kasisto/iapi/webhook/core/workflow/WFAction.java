package com.kasisto.iapi.webhook.core.workflow;


/**
 * The result of completing a transition between two states.
 */
public interface WFAction {

    String name();

}
