package com.kasisto.iapi.webhook.core.workflow;

/**
 * A specific test of a condition being met given a condition
 */
public interface WFCondition {

    boolean conditionMet(WFEvent event);

}
