package com.kasisto.iapi.webhook.core.workflow;


/**
 * A 'node' in the workflow
 */
public interface WFState {

    String name();

}

