package com.kasisto.iapi.webhook.core.workflow;

public class WFTransition {


    WFState start;
    WFState end;
    WFCondition condition;
    WFAction action;


    public WFTransition(WFAction action, WFState start, WFState end, WFCondition condition) {
        this.start = start;
        this.end = end;
        this.condition = condition;
        this.action = action;
    }


    public WFState getStart() {
        return start;
    }

    public WFState getEnd() {
        return end;
    }

    public WFAction getAction() {
        return action;
    }

    public WFCondition getCondition() {
        return condition;
    }

    public String toString() {
        return "transition{ beginState:" + start + ",endState:" + end + ",condition:" + condition + ",action:" + action;
    }

}