package com.kasisto.iapi.webhook.core.workflow;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * an interface for a workflow.  Concrete implementations should be made per intent
 */
public abstract class Workflow {


    private Log log = LogFactory.getLog(getClass());

    abstract public List<WFTransition> generateTransitions();

    //the entry state for a workflow
    abstract public WFState getOrigin();


    /**
     * A temporary data-structure to improve efficiency of reviewing transition sets from
     * a known starting point and some workflow event
     */
    private Map<WFState, List<WFTransition>> stateToTransitions = new HashMap<>();


    /**
     * The starting point for the workflow
     */
    private static WFState ORIGIN;

    /**
     * construct 'helper' data structures to make it easier to compute transitions
     */
    public Workflow() {

        initialize();
    }

    protected void initialize() {

        ORIGIN = getOrigin();

        for (WFTransition aTransition : generateTransitions()) {

            List<WFTransition> transOut = new ArrayList<>();

            if (stateToTransitions.containsKey(aTransition.start)) {
                transOut = stateToTransitions.get(aTransition.start);
            }
            transOut.add(aTransition);
            stateToTransitions.put(aTransition.start, transOut);

        }
    }

    public WFTransition getTransition(WFState currentState, WFEvent event) throws NoTransitionFoundException {

        WFState state = currentState;
        if (state == null) {
            state = ORIGIN;
        }


        if (stateToTransitions.containsKey(state)) {

            List<WFTransition> candidateTransitions = stateToTransitions.get(state);

            for (WFTransition aTransition : candidateTransitions) {

                //should possibly find a way of prioritizing if multiple transitions are satisfied
                if (conditionMet(aTransition.condition, event)) {
                    log.trace("found a transition to:" + aTransition.getEnd());
                    return aTransition;

                }
            }
        }


        throw new NoTransitionFoundException("No valid transition out from state=" + state.name());
    }


    private boolean conditionMet(WFCondition wcondition, WFEvent event) {

        return wcondition.conditionMet(event);
    }


}
