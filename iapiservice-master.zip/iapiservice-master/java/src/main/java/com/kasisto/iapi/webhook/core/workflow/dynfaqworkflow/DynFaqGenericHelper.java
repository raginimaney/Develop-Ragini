package com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;


/**
 *
 */
public class DynFaqGenericHelper implements GenericDynFaqProcessorHelper {

    private Log log = LogFactory.getLog(getClass());
    private String dynfaqPrefix = "DYNFAQ";


    public static final List<RequestUserInput> userInputs;

    // Basic parameter types
    public static final String PARAM_STRING = "string_param";


    public static final boolean allowSubStringMatchAlias = false;

    //DYNFAQ resource info
    private ResourceBundle dynfaqResource;

    public DynFaqGenericHelper(String faqPrefix) {
        this.dynfaqPrefix = faqPrefix;
        this.dynfaqResource = ResourceBundle.getBundle(faqPrefix);
    }

    static {
        //the parameters to collect in what order
        userInputs = new ArrayList<>();
        userInputs.add(new RequestUserInput(PARAM_STRING, RequestUserInput.UserInputType.STRING));

    }

    @Override
    public String getDisambigPromptForIntent(String intentName) {
        String parsedIntentName =  intentName.toLowerCase().replaceFirst(dynfaqPrefix.toLowerCase()+ "_", "");
        String resourceKey= parsedIntentName + ".prompt";
        log.info("getDisambigPromptForIntent -> Looking for resource key [" + resourceKey +"] from resource bundle [" + dynfaqResource.getBaseBundleName() + "]" );
        try {
            return dynfaqResource.getString(resourceKey);
        } catch (Exception e){
            return dynfaqResource.getString("default.prompt");
        }

    }

    @Override
    public List<RequestUserInput.QuickReplyOption> getDisambigQuickRepliesTextForIntent(String intentName) {
        List<RequestUserInput.QuickReplyOption> options = new ArrayList<>();
        String parsedIntentName =  intentName.toLowerCase().replaceFirst(dynfaqPrefix.toLowerCase() + "_", "");
        int count = 0;
        String resourceKey= parsedIntentName + ".prompt.quick_replies.text." + count;
        try {
            while (!dynfaqResource.getString(resourceKey).equals(null)) {
                log.info("getDisambigQuickRepliesTextForIntent -> Looking for resource key [" + resourceKey +"] from resource bundle [" + dynfaqResource.getBaseBundleName() + "]" );

                //parse resource string
                String[] parts = dynfaqResource.getString(resourceKey).split("\\|");

                //add to list

                List<String> alias = new ArrayList<String>();

                if(parts.length > 2){
                    for(int i=2; i < parts.length; i++){
                        alias.add(parts[i]);
                    }
                }

                options.add(new RequestUserInput.QuickReplyOption(parts[1], parts[0], allowSubStringMatchAlias,alias));

                //update
                count ++;
                resourceKey= parsedIntentName + ".prompt.quick_replies.text." + count;
            }
            return options;
        } catch (java.util.MissingResourceException e){
            return options;
        }

    }

    @Override
    public String getFinalPromptForIntent(String intentName, String resourceKeyBase) {
        String parsedIntentName =  intentName.toLowerCase().replaceFirst(dynfaqPrefix.toLowerCase() + "_", "");
        String resourceKey= parsedIntentName + ".disambig." + resourceKeyBase.toLowerCase().replaceAll("\\s+", "_") + ".prompt";
        log.info("getFinalPromptForIntent -> Looking for resource key [" + resourceKey +"] from resource bundle [" + dynfaqResource.getBaseBundleName() + "]" );

        try {
            return dynfaqResource.getString(resourceKey);
        } catch (Exception e){
            return dynfaqResource.getString("default.prompt");
        }

    }


    @Override
    public List<RequestUserInput> getInputParams() {

        return userInputs;
    }

    @Override
    public void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs) {
        log.trace("submitting form result..." + accumulatedInputs.toString());
    }

    @Override
    public boolean isValid(String paramName, String paramValue) {
        return true;

    }


}
