package com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;

import java.util.List;
import java.util.Map;


public interface GenericDynFaqProcessorHelper {


    /**
     * method to validate a particular parameter
     *
     * @param paramName
     * @param paramValue
     * @return
     */
    boolean isValid(String paramName, String paramValue);


    /**
     * Generate the dismbiguation prompt for a given intent
     *
     * @param intentName
     * @return
     */
    String getDisambigPromptForIntent(String intentName);
    List<RequestUserInput.QuickReplyOption> getDisambigQuickRepliesTextForIntent(String intentName);

    /**
     * Generate the final prompt for a given intent
     *
     * @param intentName
     * @param resourceKey
     * @return
     */
    String getFinalPromptForIntent(String intentName, String resourceKey);

    /**
    /*
      The list of parameters that need to be processed
    */

    List<RequestUserInput> getInputParams();


    /**
     * Function to process the completed result from a form
     *
     * @param userId
     * @param accumulatedInputs
     */
    void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs);

}
