package com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow;

import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.session.ConversationSession;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class GenericDynFaqProcesssor extends AbstractIntentProcessor {
    private String currentIntentName;
    private String promptKey;
    public static String DYNFAQ_PREFIX = "DYNFAQ";

    public static String FIELD_DISAMBIG ="disambig";

    private List<RequestUserInput> requiredParams;

    private DynFaqGenericHelper genericFaqProcessorHelper;

    public GenericDynFaqProcesssor(DynFaqGenericHelper genericProcessorHelper) {
        this.requiredParams = genericProcessorHelper.getInputParams();
        this.genericFaqProcessorHelper = genericProcessorHelper;
    }


    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {

        ConversationResponse response = new ConversationResponse();

        //update accumulatedInputs
        UserInput property_now = new UserInput("now", ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME));
        accumulatedInputs.put("now", property_now);


        if (action.name().equals(GenericDynFaqWorkflow.Actions.DISAMBIG_GET.name())) {
            //Disambiguate
            response.message_contents.add(new MessageContentText(this.genericFaqProcessorHelper.getDisambigPromptForIntent(currentIntentName)));
            HashMap optionalParams = new HashMap();
            response.request_user_input = new RequestUserInput(FIELD_DISAMBIG, RequestUserInput.UserInputType.STRING, genericFaqProcessorHelper.getDisambigQuickRepliesTextForIntent(currentIntentName));
            response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;

        } else if (action.name().equals(GenericDynFaqWorkflow.Actions.FINALIZE_DISAMBIG.name())) {
            //Finalize Disambig
            response.message_contents.add(new MessageContentText(this.genericFaqProcessorHelper.getFinalPromptForIntent(currentIntentName, promptKey)));
            response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;
        } else {
            //Finalize One Shot
            response.message_contents.add(new MessageContentText(this.genericFaqProcessorHelper.getFinalPromptForIntent(currentIntentName, promptKey)));
            response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;
        }

        return response;
    }


    @Override
    public void updatePreconditions(ConversationSession session) {

        currentIntentName =session.intentName;
        System.out.println(currentIntentName);
        if (session.getCurrentUserInputs().containsKey(FIELD_DISAMBIG)) {
            promptKey = session.getCurrentUserInputs().get(FIELD_DISAMBIG).value;


        } else if (session.getCurrentUserInputs().size() > 0) {
            for (String key : session.getCurrentUserInputs().keySet()) {
                //there should only be 1 key
                promptKey = session.getCurrentUserInputs().get(key).value;
                break;
            }

        }
    }

}
