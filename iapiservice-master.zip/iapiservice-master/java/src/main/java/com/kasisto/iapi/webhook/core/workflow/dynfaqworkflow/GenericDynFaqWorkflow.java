package com.kasisto.iapi.webhook.core.workflow.dynfaqworkflow;
import com.kasisto.iapi.webhook.core.workflow.*;

import java.util.ArrayList;
import java.util.List;

/**
 * A Generic workflow that attempts to process an generic FAQ intent.
 * The FAQ may have 1 optional inputs.
 * If the input field is provided with the intent trigger then the intent will process that field.
 * If the input field is not provided (and is required) then the workflow will attempt to collect and then complete the intent.
 * If the input field is optional, then the workflow will generate a response and complete the intent.
 * The workflow returns a CMS ctaid, which will be used by KAI to generate the final response.
 *
 */
public class GenericDynFaqWorkflow extends Workflow {

    enum States implements WFState {
        //INIT,
        START,
        DISAMBIGUATE,
        END
    }

    enum Actions implements WFAction {
        DISAMBIG_GET,
        FINALIZE_DISAMBIG,
        FINALIZE_ONESHOT

    }

    private DynFaqGenericHelper genericFaqProcessorHelper;


    @Override
    public List<WFTransition> generateTransitions() {

        List<WFTransition> transitions = new ArrayList<>();

        transitions.add(new WFTransition(Actions.DISAMBIG_GET, GenericDynFaqWorkflow.States.START, States.DISAMBIGUATE, event -> {
            return !hasAnyInput(event);
        }));

        transitions.add(new WFTransition(Actions.FINALIZE_DISAMBIG, GenericDynFaqWorkflow.States.DISAMBIGUATE, States.END, event -> {
            return event.hasUserInput(GenericDynFaqProcesssor.FIELD_DISAMBIG);
        }));

        transitions.add(new WFTransition(Actions.FINALIZE_ONESHOT, GenericDynFaqWorkflow.States.START, States.END, event -> {
            return hasAnyInput(event);
        }));



        return transitions;
    }


    private boolean hasAllInputs(WFEvent event, String[] params) {

        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
            } else {
                return false;
            }
        }
        return true;
    }


    private boolean hasAInput(WFEvent event, String[] params) {

        boolean hasAInput = false;
        for (String aParam : params) {
            if (event.getCurrentUserInputs().containsKey(aParam) ||
                    event.getPreviousUserInputs().containsKey(aParam)) {
                hasAInput = true;
            } else {

            }
        }
        return hasAInput;


    }

    private boolean hasAnyInput(WFEvent event) {
        boolean hasAnyInput = false;
        if (event.getCurrentUserInputs().size() > 0) {
            hasAnyInput = true;
        }

        return hasAnyInput;


    }

    @Override
    public WFState getOrigin() {
        return GenericDynFaqWorkflow.States.START;
    }
}
