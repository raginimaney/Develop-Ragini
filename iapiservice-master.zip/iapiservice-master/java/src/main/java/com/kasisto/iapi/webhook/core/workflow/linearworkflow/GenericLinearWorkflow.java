package com.kasisto.iapi.webhook.core.workflow.linearworkflow;

import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A Generic workflow that attempts to process a set of inputs in a linear order.
 * <p>
 * 1) Will process in order
 * 2) Reprompt if input is deemed to be consider invalid according to the intent-helper
 * 3) When complete, delegates the submit step to the intenthelper
 */
public class GenericLinearWorkflow extends Workflow {

    public static final String PROMPT_PREFIX = "PROMPT_";
    public static final String RETRY_PREFIX = "RETRY_";

    public Set<WFState> states;
    private WFState origin;

    public static final String startState = "start";
    public static final String endState = "end";

    public static final String ACTION_END = "DONE";
    public static final String ACTION_WELCOME = "WELCOME";


    public WFAction[] action;

    List<RequestUserInput> userInputs;

    private GenericProcessorHelper genericProcessorHelper;
    private WFState firstState;


    public GenericLinearWorkflow(GenericProcessorHelper genericProcessorHelper) {
        super();
        this.genericProcessorHelper = genericProcessorHelper;
        userInputs = genericProcessorHelper.getInputParams();
        this.origin = new WFStateSimple(startState);
        firstState = new WFStateSimple(userInputs.get(0).name);
        this.initialize();
    }


    @Override
    public List<WFTransition> generateTransitions() {


        states = new HashSet<>();

        List<WFTransition> transitions = new ArrayList<>();

        //set the step from origin to first parameter

        //transition form start to the first parameter
        WFCondition conditionStart = event -> event.getCurrentUserInputs().size() == 0;


        if (userInputs == null) {
            return new ArrayList<WFTransition>();
        }

        WFTransition torigin = new WFTransition(makeWFAction(PROMPT_PREFIX, userInputs.get(0).name), origin, firstState, conditionStart);
        transitions.add(torigin);


        for (int i = 0; i < userInputs.size(); i++) {


            WFState currentState = new WFStateSimple(userInputs.get(i).name);
            WFState nextState = null;

            if (i < userInputs.size() - 1) {
                nextState = new WFStateSimple(userInputs.get(i + 1).name);
            }

            states.add(currentState);

            if (nextState != null) {
                states.add(nextState);
            }

            String currentParam = userInputs.get(i).name;

            if (i + 1 < userInputs.size()) {
                WFCondition conditionPass = new WFCondition() {
                    @Override
                    public boolean conditionMet(WFEvent event) {
                        if (!event.getCurrentUserInputs().containsKey(currentParam)) {
                            return false;
                        }
                        return genericProcessorHelper.isValid(currentParam, event.getCurrentUserInputs().get(currentParam).value);
                    }
                };


                // WFCondition conditionPass = event -> genericProcessorHelper.isValid(currentParam,event.getCurrentUserInputs().get(currentParam).value);
                WFTransition t = new WFTransition(makeWFAction(PROMPT_PREFIX, userInputs.get(i + 1).name), currentState, nextState, conditionPass);
                transitions.add(t);
            }

            WFCondition conditionFail = new WFCondition() {
                @Override
                public boolean conditionMet(WFEvent event) {
                    if (!event.getCurrentUserInputs().containsKey(currentParam)) {
                        return false;
                    }
                    return !genericProcessorHelper.isValid(currentParam, event.getCurrentUserInputs().get(currentParam).value);
                }
            };

            // WFCondition conditionFail = event -> ! genericProcessorHelper.isValid(currentParam,event.getCurrentUserInputs().get(currentParam).value);
            WFTransition t2 = new WFTransition(makeWFAction(RETRY_PREFIX, userInputs.get(i).name), currentState, currentState, conditionFail);
            transitions.add(t2);

        }


        String lastParam = userInputs.get(userInputs.size() - 1).name;

        WFStateSimple last = new WFStateSimple(lastParam);
        WFStateSimple end = new WFStateSimple(endState);

        WFCondition conditionPass = new WFCondition() {
            @Override
            public boolean conditionMet(WFEvent event) {
                if (!event.getCurrentUserInputs().containsKey(lastParam)) {
                    return false;
                }
                return genericProcessorHelper.isValid(lastParam, event.getCurrentUserInputs().get(lastParam).value);
            }
        };

        // WFCondition conditionPass = event -> genericProcessorHelper.isValid(currentParam,event.getCurrentUserInputs().get(currentParam).value);
        WFTransition t = new WFTransition(new WFActionSimple(ACTION_END), last, end, conditionPass);
        transitions.add(t);


        return transitions;
    }


    private WFAction makeWFAction(String prefix, String parameter) {

        return new WFActionSimple(prefix + parameter);
    }


    @Override
    public WFState getOrigin() {
        return origin;
    }
}
