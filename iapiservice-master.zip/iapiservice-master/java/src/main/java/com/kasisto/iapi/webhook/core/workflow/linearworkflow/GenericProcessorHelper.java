package com.kasisto.iapi.webhook.core.workflow.linearworkflow;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;

import java.util.List;
import java.util.Map;


public interface GenericProcessorHelper {


    /**
     * method to validate a particular parameter
     *
     * @param paramName
     * @param paramValue
     * @return
     */
    boolean isValid(String paramName, String paramValue);


    /**
     * Generate the prompt for a given input parameter
     *
     * @param paramName
     * @return
     */
    MessageContent getPromptForInput(RequestUserInput paramName);

    /**
     * Generate the response if the input parameter is invalid
     *
     * @param paramName
     * @return
     */
    MessageContent getRetryPromptForInput(RequestUserInput paramName);

    /**
     * Generate the response if successfully completed form
     *
     * @return
     */
    MessageContent getEndPrompt();


    /*
      The list of parameters that need to be processed
    */

    List<RequestUserInput> getInputParams();


    /**
     * Function to process the completed result from a form
     *
     * @param userId
     * @param accumulatedInputs
     */
    void submitFormResults(String userId, Map<String, UserInput> accumulatedInputs);

}
