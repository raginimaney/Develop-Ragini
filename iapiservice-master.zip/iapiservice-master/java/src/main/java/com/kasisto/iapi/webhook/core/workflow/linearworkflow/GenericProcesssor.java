package com.kasisto.iapi.webhook.core.workflow.linearworkflow;


import com.kasisto.iapi.webhook.core.AbstractIntentProcessor;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.MessageContent;
import com.kasisto.iapi.webhook.core.model.response.MessageContentText;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import com.kasisto.iapi.webhook.core.workflow.WFAction;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import static com.kasisto.iapi.webhook.core.workflow.linearworkflow.GenericLinearWorkflow.ACTION_END;

public class GenericProcesssor extends AbstractIntentProcessor {


    private List<RequestUserInput> requiredParams;

    private GenericProcessorHelper genericProcessorHelper;

    public GenericProcesssor(GenericProcessorHelper genericProcessorHelper) {
        this.requiredParams = genericProcessorHelper.getInputParams();
        this.genericProcessorHelper = genericProcessorHelper;
    }

    @Override
    public boolean isLoginRequired() {
        return false;
    }


    @Override
    public ConversationResponse generateResponseForAction(WFAction action, String userId, String token, Map<String, UserInput> accumulatedInputs, Map<String, SystemInput> systemInputs, Context context) {

        ConversationResponse response = new ConversationResponse();

        //update accumulatedInputs
        UserInput property_now = new UserInput("now", ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME));
        accumulatedInputs.put("now", property_now);

        if (action.name().equals(ACTION_END)) {

            MessageContent endMsg = this.genericProcessorHelper.getEndPrompt();

            if (endMsg instanceof MessageContentText) {
                response.message_contents.add(new MessageContentText(genText(((MessageContentText.MessageContentTextPayload) endMsg.payload).getTextPayload(), accumulatedInputs.values())));
            } else {
                response.message_contents.add(endMsg);
            }

            this.genericProcessorHelper.submitFormResults(userId, accumulatedInputs);
            response.conversation_state = ConversationResponse.ConversationState.COMPLETED;
        } else {
            RequestUserInput input = getForAction(action);

            MessageContent msg;

            if (action.name().startsWith(GenericLinearWorkflow.PROMPT_PREFIX)) {
                msg = this.genericProcessorHelper.getPromptForInput(input);
            } else {
                msg = this.genericProcessorHelper.getRetryPromptForInput(input);

            }

            if (msg instanceof MessageContentText) {
                response.message_contents.add(new MessageContentText(genText(((MessageContentText.MessageContentTextPayload) msg.payload).getTextPayload(), accumulatedInputs.values())));
            } else {
                response.message_contents.add(msg);
            }

            response.request_user_input = input;
            response.conversation_state = ConversationResponse.ConversationState.PENDING_USER;
        }

        return response;
    }

    public RequestUserInput getForAction(WFAction action) {

        for (RequestUserInput input : this.requiredParams) {

            //fix
            if (action.name().contains(input.name)) {
                return input;
            }
        }
        return null;
    }

}
