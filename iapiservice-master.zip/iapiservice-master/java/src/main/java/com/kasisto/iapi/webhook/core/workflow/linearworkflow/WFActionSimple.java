package com.kasisto.iapi.webhook.core.workflow.linearworkflow;

import com.kasisto.iapi.webhook.core.workflow.WFAction;

public class WFActionSimple implements WFAction {

    private String name;

    public WFActionSimple() {

    }

    public WFActionSimple(String name) {
        this.name = name;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        return ((WFActionSimple) obj).name.equals(this.name());
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

}
