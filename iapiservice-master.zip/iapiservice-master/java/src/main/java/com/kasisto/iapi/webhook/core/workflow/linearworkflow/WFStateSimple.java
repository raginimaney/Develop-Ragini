package com.kasisto.iapi.webhook.core.workflow.linearworkflow;

import com.kasisto.iapi.webhook.core.workflow.WFState;

import java.io.Serializable;

public class WFStateSimple implements WFState, Serializable {

    private String name;

    public WFStateSimple(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        return ((WFStateSimple) obj).name.equals(this.name());
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
