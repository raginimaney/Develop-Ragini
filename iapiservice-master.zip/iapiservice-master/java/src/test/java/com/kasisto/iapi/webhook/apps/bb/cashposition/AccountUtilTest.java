package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.api.model.Account;
import java.util.ArrayList;
import java.util.List;

import com.kasisto.iapi.webhook.apps.bb.AccountUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AccountUtilTest {


  List<Account> accountList;

  @Before
  public void setup() {
    accountList = new ArrayList<>();
    accountList.add(MockBusinessBankEAPI.ac);
    accountList.add(MockBusinessBankEAPI.ac2);
    accountList.add(MockBusinessBankEAPI.ac3);
  }


  @Test
  public void testBasicFilter() {

    Assert.assertEquals(3, AccountUtil.accountFilterByAccountType(accountList, null, null, null, null).size());
    assertEquals(2, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION_SUMMARY, null, null, null).size());
    assertEquals(1, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION, null, null, null).size());
    assertEquals(1, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION_SUMMARY, null, "EUR", null).size());

    assertEquals(1, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION, null, null, "JPMorgan").size());
    assertEquals(0, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION, null, null, "jpmoasdfasrgan").size());

    assertEquals(1, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION, "6278", null, null).size());


    assertEquals(0, AccountUtil.accountFilterByAccountType(accountList, Account.AccountTypeEnum.CASH_POSITION, null, null, "fakebank").size());
  }

}