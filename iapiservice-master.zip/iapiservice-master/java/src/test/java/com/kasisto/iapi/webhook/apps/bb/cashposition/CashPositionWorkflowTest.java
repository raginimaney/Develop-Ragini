package com.kasisto.iapi.webhook.apps.bb.cashposition;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CashPositionWorkflowTest {
  Workflow workflow;

  @Before
  public void setup() {

    workflow = new CashPositionWorkflow();
  }

  @Test
  public void testInitialWithNoCurrency() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput());
    WFTransition transition = workflow.getTransition(CashPositionWorkflow.States.START, aEvent);
    assertEquals(CashPositionWorkflow.States.CURRENCY, transition.getEnd());
  }


  @Test
  public void testInitialWithCurrency() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(CashPositionIntentProcessor.FIELD_CURRENCY, CashPositionIntentProcessor.CP_CURRENCY.EUR.name()));
    WFTransition transition = workflow.getTransition(CashPositionWorkflow.States.START, aEvent);
    assertEquals(CashPositionWorkflow.States.BALANCE, transition.getEnd());
  }

}