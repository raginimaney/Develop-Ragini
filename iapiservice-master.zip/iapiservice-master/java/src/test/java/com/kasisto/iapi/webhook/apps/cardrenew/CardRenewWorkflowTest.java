package com.kasisto.iapi.webhook.apps.cardrenew;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CardRenewWorkflowTest {


  Workflow workflow;

  @Before
  public void setup() {
    workflow = new CardRenewWorkflow();
  }

  @Test
  public void testWorkflow() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(CardRenewIntentProcessor.FIELD_CARD_EXPIRATION, "12/2/2020"));

    WFTransition aTransition = workflow.getTransition(CardRenewWorkflow.States.START, aEvent);
    assertEquals(CardRenewWorkflow.States.CARDS, aTransition.getEnd());
  }


  @Test
  public void testWorkflowComplete() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(CardRenewIntentProcessor.FIELD_CARD_EXPIRATION, "12/2/2020"));

    WFTransition aTransition = workflow.getTransition(CardRenewWorkflow.States.START, aEvent);
    assertEquals(CardRenewWorkflow.States.CARDS, aTransition.getEnd());
  }


}