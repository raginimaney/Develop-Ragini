package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;

import static com.kasisto.iapi.webhook.apps.cards.CardActivateProcessor.GLOBAL_ISCARDACTIVATED;
import static com.kasisto.iapi.webhook.apps.cards.CardActivateProcessor.GLOBAL_ISCARDVALID;
import static org.junit.Assert.assertEquals;

public class CardActivationWorkflowTest {


    Workflow workflow;

    @Before
    public void setup() {
        workflow = new CardActivateWorkflow();
    }



    @Test
    public void testWorkflow() throws NoTransitionFoundException {
        WFEvent aEvent = new WFEvent();
        WFTransition transition = workflow.getTransition(CardActivateWorkflow.States.START, aEvent);
        assertEquals(CardActivateWorkflow.States.CARDNUM, transition.getEnd());
    }

    @Test
    public void testWorkflow1() throws NoTransitionFoundException {
        WFEvent aEvent = new WFEvent(new UserInput(CardActivateProcessor.FIELD_CARDNUM,"4114 1234 1234 1234"));
        WFTransition transition = workflow.getTransition(CardActivateWorkflow.States.CARDNUM, aEvent);
        assertEquals(CardActivateWorkflow.States.CCV, transition.getEnd());

    }
    @Test
    public void testWorkflow2() throws NoTransitionFoundException {
        WFEvent aEvent = new WFEvent(new UserInput(CardActivateProcessor.FIELD_CCV,"123"));
        WFTransition transition = workflow.getTransition(CardActivateWorkflow.States.CCV, aEvent);
        assertEquals(CardActivateWorkflow.States.EXPIRY, transition.getEnd());
    }

    @Test
    public void testWorkflow3() throws NoTransitionFoundException {

        WFEvent aEvent = new WFEvent(new UserInput(CardActivateProcessor.FIELD_EXPIRY,"12/20"));
        aEvent.addToSystemInputs(new SystemInput(GLOBAL_ISCARDVALID,"true"));
        aEvent.addToSystemInputs(new SystemInput(GLOBAL_ISCARDACTIVATED, "true"));
        WFTransition transition = workflow.getTransition(CardActivateWorkflow.States.EXPIRY, aEvent);
        assertEquals(CardActivateWorkflow.States.END, transition.getEnd());

    }



}
