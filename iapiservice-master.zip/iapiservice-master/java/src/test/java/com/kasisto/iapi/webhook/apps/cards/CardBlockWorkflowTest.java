package com.kasisto.iapi.webhook.apps.cards;

import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CardBlockWorkflowTest {


    Workflow workflow;

    @Before
    public void setup() {

        workflow = new CardBlockWorkflow();
    }



    //@Test
    public void testWorkflow() throws NoTransitionFoundException {

        WFEvent aEvent = new WFEvent(new UserInput(CardBlockProcessor.FIELD_CARD_NUM,"1234"));


        WFTransition transition = workflow.getTransition(CardBlockWorkflow.States.START, aEvent);

        assertEquals(CardBlockWorkflow.States.CONFIRM, transition.getEnd());

    }

    @Test
    public void testWorkflow2() throws NoTransitionFoundException {

        WFEvent aEvent = new WFEvent();

        aEvent.addToSystemInputs(new SystemInput(CardBlockProcessor.SYSTEM_EVENT_VALID_CARD_FOR_TOKEN,"2"));


        WFTransition transition = workflow.getTransition(CardBlockWorkflow.States.START, aEvent);

        assertEquals(CardBlockWorkflow.States.PROMPT_NUM, transition.getEnd());

    }

    @Test
    public void testWorkflow3() throws NoTransitionFoundException {

        WFEvent aEvent = new WFEvent(new UserInput(CardBlockProcessor.FIELD_CARD_CONFIRM,"true"));



        WFTransition transition = workflow.getTransition(CardBlockWorkflow.States.CONFIRM, aEvent);

        assertEquals(CardBlockWorkflow.States.END, transition.getEnd());

    }


}
