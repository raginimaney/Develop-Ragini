package com.kasisto.iapi.webhook.apps.guai;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class GUAIWorkflowTest {

  Workflow workflow;

  @Before
  public void setup() {

    workflow = new GUAIWorkflow();
  }

  @Test
  public void testWorkflow() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(GUAIIntentProcessor.FIELD_AGG, GUAIIntentProcessor.VAL_FIELD_AGG_TOTAL));
    WFTransition transition = workflow.getTransition(GUAIWorkflow.States.START, aEvent);
    assertEquals(GUAIWorkflow.States.AGGREGATE, transition.getEnd());
  }


}