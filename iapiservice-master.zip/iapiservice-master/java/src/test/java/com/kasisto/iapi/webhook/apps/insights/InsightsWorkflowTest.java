package com.kasisto.iapi.webhook.apps.insights;

import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;


import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class InsightsWorkflowTest {

  Workflow workflow;

  @Before
  public void setup() {
    workflow = new InsightsWorkflow();
  }

  @Test
  public void testWorkflow() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"));

    WFTransition aTransition = workflow.getTransition(InsightsWorkflow.States.START, aEvent);
    assertEquals(InsightsWorkflow.States.CATEGORY, aTransition.getEnd());

    WFEvent bEvent = new WFEvent(new UserInput[]{new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"),new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food")});

    WFTransition bTransition = workflow.getTransition(aTransition.getEnd(), bEvent);
    assertEquals(InsightsWorkflow.States.AMOUNT, bTransition.getEnd());

    WFEvent cEvent = new WFEvent(new UserInput[]{new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"),
            new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"),
            new UserInput(InsightsBudgetIntentProcessor.FIELD_AMOUNT, "500")});


    WFTransition cTransition = workflow.getTransition(bTransition.getEnd(), cEvent);
    assertEquals(InsightsWorkflow.States.CONFIRM, cTransition.getEnd());

    WFEvent dEvent = new WFEvent(new UserInput[]{ new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"),
            new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"),
            new UserInput(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION, "yes")});

    WFTransition dTransition = workflow.getTransition(cTransition.getEnd(), dEvent);
    assertEquals(InsightsWorkflow.States.END, dTransition.getEnd());
  }

  @Test
  public void testWorkflowABWithCategory() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput[]{ new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"),
            new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food")});

    WFTransition aTransition = workflow.getTransition(InsightsWorkflow.States.START, aEvent);
    assertEquals(InsightsWorkflow.States.AMOUNT, aTransition.getEnd());
  }


  @Test
  public void testWorkflowABWithBadCategory() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"));

    WFTransition aTransition = workflow.getTransition(InsightsWorkflow.States.START, aEvent);
    assertEquals(aTransition.getEnd(), InsightsWorkflow.States.CATEGORY);

    WFEvent bEvent = new WFEvent(new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "madeupcategory"));
    bEvent.addToPreviousUserInput(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, "set"));

    //test that sent back to the category state
    WFTransition bTransition = workflow.getTransition(InsightsWorkflow.States.CATEGORY, bEvent);
    assertEquals(bTransition.getEnd(), InsightsWorkflow.States.CATEGORY);
  }

}