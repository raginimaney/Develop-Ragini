package com.kasisto.iapi.webhook.apps.payment;

import com.kasisto.iapi.webhook.core.model.request.SystemInput;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.workflow.NoTransitionFoundException;
import com.kasisto.iapi.webhook.core.workflow.WFEvent;
import com.kasisto.iapi.webhook.core.workflow.WFTransition;
import com.kasisto.iapi.webhook.core.workflow.Workflow;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class PaymentWorkflowTest {

  Workflow workflow;

  @Before
  public void setup() {
    workflow = new PaymentGeneralWorkflow();
  }

  @Test
  public void testWorkflowNoParam() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent();
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.QUALIFY, aTransition.getEnd());

  }

  @Test
  public void testWorkflowPaymentTypeWrong() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "WrongPaymentType"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"false"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.QUALIFY, aTransition.getEnd());

  }

  @Test
  public void testWorkflowPaymentTypeInternational() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "international"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());

  }

  @Test
  public void testWorkflowPaymentTypeSocial() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "social"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());

  }

//  @Test
//  public void testWorkflowPaymentTypeSocialFriend() throws NoTransitionFoundException {
//
//
//    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "friend"));
//    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
//    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());
//
//  }

  @Test
  public void testWorkflowPaymentTypeLocal() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "local"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());

  }

  @Test
  public void testWorkflowPaymentTypeBill() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_PAYMENT_TYPE, "bill"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());

  }

  @Test
  public void testWorkflowMerchantType() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_MERCHANT_TYPE, "ABCD"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));
    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());

  }

  @Test
  public void testWorkflowWrongMerchantType() throws NoTransitionFoundException {


    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_MERCHANT_TYPE, "wrongMerchant"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"false"));

    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.QUALIFY, aTransition.getEnd());

  }

  @Test
  public void testWorkflowCountryType() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_COUNTRY_TYPE, "india"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"true"));

    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.END, aTransition.getEnd());
  }

  
  @Test
  public void testWorkflowCountryTypeInvalidCountry() throws NoTransitionFoundException {

    WFEvent aEvent = new WFEvent(new UserInput(PaymentGeneralIntentProcessor.FIELD_COUNTRY_TYPE, "somemadeupcountry"));
    aEvent.getSystemInputs().put(PaymentGeneralIntentProcessor.VALID_INPUT,new SystemInput(PaymentGeneralIntentProcessor.VALID_INPUT,"false"));

    WFTransition aTransition = workflow.getTransition(PaymentGeneralWorkflow.States.START, aEvent);
    assertEquals(PaymentGeneralWorkflow.States.QUALIFY, aTransition.getEnd());
  }


}