package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;

import static org.junit.Assert.assertEquals;

public class WHTestHelper {


  public static void validateUserInput(ConversationResponse response, RequestUserInput.UserInputType type, String name, ConversationResponse.ConversationState conversationState) {
    assertEquals(name, response.request_user_input.name);
    assertEquals(type, response.request_user_input.getTypeNorm());
    assertEquals(conversationState, response.conversation_state);
  }
}
