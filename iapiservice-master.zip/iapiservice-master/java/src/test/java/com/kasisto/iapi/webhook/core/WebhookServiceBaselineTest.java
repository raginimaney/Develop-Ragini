package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.baseline.BaselineHelper;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;


/**
 * TODO:
 *
 * @author jon
 */
public class WebhookServiceBaselineTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();

    this.webhookService = new WebhookService();
    this.webhookService.setIntentProcessorFactory(processorFactory);

  }


  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //Initialize baseline_form
    StartConversationRequest request = new StartConversationRequest(BaselineHelper.BASELINE_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    // Tests parameters
    response = validateBooleanParam(response, convoid);
    response = validateNumberParam(response, convoid);
    response = validateDatetimeParam(response, convoid);
    response = validatePatternParam(response, convoid);
    response = validateCurrencyParam(response, convoid);
    response = validateEmailParam(response, convoid);
    response = validateStringParam(response, convoid);
    response = validateOptionsParam(response, convoid);

    // Test normalizers
    response = validateDateNorm(response, convoid);


    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
  }


  // Helper to validate boolean paramater
  private ConversationResponse validateBooleanParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.BOOLEAN, BaselineHelper.PARAM_BOOL, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_BOOL, "TRUE"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate number parameter
  private ConversationResponse validateNumberParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.NUMBER, BaselineHelper.PARAM_NUM, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_NUM, "12345"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate datetime parameter
  private ConversationResponse validateDatetimeParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.DATE, BaselineHelper.PARAM_DATETIME, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_DATETIME, "12/12/12"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate the pattern type parameter
  private ConversationResponse validatePatternParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res,RequestUserInput.UserInputType.PATTERN, BaselineHelper.PARAM_PATTERN, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_PATTERN, "(347)935-5266"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate currency type parameter
  private ConversationResponse validateCurrencyParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.CURRENCY_AMOUNT, BaselineHelper.PARAM_CURRENCY, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_CURRENCY, "$52.432"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate currency type paramter
  private ConversationResponse validateEmailParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.EMAIL, BaselineHelper.PARAM_EMAIL, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_EMAIL, "bob@yahoo.com"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate string type parameter
  private ConversationResponse validateStringParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.STRING, BaselineHelper.PARAM_STRING, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_STRING, "blabla"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate options type parameter
  private ConversationResponse validateOptionsParam(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.STRING, BaselineHelper.PARAM_OPTION, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.PARAM_OPTION, "blabla"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }


  // Helper to validate normalized date type
  private ConversationResponse validateDateNorm(ConversationResponse res, String convoId) throws ApiException, SessionStoreException {
    WHTestHelper.validateUserInput(res, RequestUserInput.UserInputType.DATE, BaselineHelper.NORM_DATE, ConversationResponse.ConversationState.PENDING_USER);
    SendUserInputRequest req = new SendUserInputRequest(convoId, new UserInput(BaselineHelper.NORM_DATE, "tomorrow"));
    return webhookService.handleSendUserInput(secret, token, locale, request_id, date, req);
  }
}
