package com.kasisto.iapi.webhook.core;


import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.cards.CardActivateProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.Context;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;


public class WebhookServiceCardActivationTest {

    WebhookService webhookService;
    String secret = "secret";
    String token = "tokenACME^Cards";
    String tokenCustomActionFail = "tokenACME^Cards^CustomActionFail";
    String locale = "locale";
    String request_id = "req1";
    Date date = null;


    @Before
    public void setUp() throws Exception {

        MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();
        this.webhookService = new WebhookService();
        this.webhookService.setIntentProcessorFactory(processorFactory);


    }



    @Test (expected=ApiException.class)
    public void testOlderApiVersion() throws ApiException, SessionStoreException {
        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        request.context = new Context();
        request.context.api_version = "0.0.9";
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    }

    @Test(expected=ApiException.class)
    public void testVersionNoRevision() throws ApiException, SessionStoreException {
        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        request.context = new Context();
        request.context.api_version = "1.0";
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    }


    @Test
    public void testVersion2() throws ApiException, SessionStoreException {
        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        request.context = new Context();
        request.context.api_version = "2.1.1";
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    }

    @Test
    public void testVersion3() throws ApiException, SessionStoreException {
        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        request.context = new Context();
        request.context.api_version = "2.6.6";
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    }






    @Test
    public void testSimplePath() throws ApiException, SessionStoreException {

        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
        String convoid = response.conversation_id;

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, CardActivateProcessor.FIELD_CARDNUM,
                ConversationResponse.ConversationState.PENDING_USER);

        SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CARDNUM, "4114 1234 1234 1234"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_CCV,
                ConversationResponse.ConversationState.PENDING_USER);

        SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CCV, "123"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_EXPIRY,
                ConversationResponse.ConversationState.PENDING_USER);
        SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_EXPIRY, "12/20"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);


        //assertNull(response.request_user_input);
        Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

    }



    @Test
    public void testInvalidCardNumber() throws ApiException, SessionStoreException {
        StartConversationRequest request = new StartConversationRequest(CardActivateProcessor.CARD_ACTIVATE_INTENT_NAME);
        ConversationResponse response = webhookService.handleStartConversation(secret, tokenCustomActionFail, locale, request_id, date, request);
        String convoid = response.conversation_id;

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, CardActivateProcessor.FIELD_CARDNUM,
                ConversationResponse.ConversationState.PENDING_USER);


        SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CARDNUM, "4114 1234 1234 1234"));
        response = webhookService.handleSendUserInput(secret, tokenCustomActionFail, locale, request_id, date, request2);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_CCV,
                ConversationResponse.ConversationState.PENDING_USER);


        SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CCV, "123"));
        response = webhookService.handleSendUserInput(secret, tokenCustomActionFail, locale, request_id, date, request3);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_EXPIRY,
                ConversationResponse.ConversationState.PENDING_USER);
        SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_EXPIRY, "12/20"));
        response = webhookService.handleSendUserInput(secret, tokenCustomActionFail, locale, request_id, date, request4);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NORM_CREDIT_CARD_NUMBER, CardActivateProcessor.FIELD_CARDNUM,
                ConversationResponse.ConversationState.PENDING_USER);


        SendUserInputRequest request2b = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CARDNUM, "4114 1234 1234 1234"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2b);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_CCV,
                ConversationResponse.ConversationState.PENDING_USER);


        SendUserInputRequest request3b = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_CCV, "123"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3b);

        WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.PATTERN, CardActivateProcessor.FIELD_EXPIRY,
                ConversationResponse.ConversationState.PENDING_USER);
        SendUserInputRequest request4b = new SendUserInputRequest(convoid, new UserInput(CardActivateProcessor.FIELD_EXPIRY, "12/20"));
        response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4b);

        //assertNull(response.request_user_input);
        Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
    }


}
