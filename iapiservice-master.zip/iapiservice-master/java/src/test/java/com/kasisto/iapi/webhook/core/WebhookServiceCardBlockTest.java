package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.cards.CardBlockProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;


/**
 * TODO:
 * <p>
 * 1) better testing fuzzy matching on webhook message output
 * 2) Fix confirmation on Insights Test
 * 3) TODO inject EAPI to mock out EAPI data
 *
 * @author jon
 */
public class WebhookServiceCardBlockTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "tokenACME^Cards";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();

    this.webhookService = new WebhookService();
    this.webhookService.setIntentProcessorFactory(processorFactory);

  }


  @Test
  public void testSimplePath() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CardBlockProcessor.CARD_BLOCK_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    assertEquals(2,response.request_user_input.options.size());

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NUMBER, CardBlockProcessor.FIELD_CARD_NUM,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(CardBlockProcessor.FIELD_CARD_NUM, "1022"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, CardBlockProcessor.FIELD_CARD_CONFIRM,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(CardBlockProcessor.FIELD_CARD_CONFIRM, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);


    //assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

  }


  @Test
  public void testSimplePathWithNumberInTrigger() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CardBlockProcessor.CARD_BLOCK_INTENT_NAME,
            new UserInput(CardBlockProcessor.FIELD_CARD_NUM, "4985"));


    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;


    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, CardBlockProcessor.FIELD_CARD_CONFIRM,
            ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(CardBlockProcessor.FIELD_CARD_CONFIRM, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);

    //assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

  }


  @Test(expected= ApiException.class)
  public void testSimplePathWitBadNumberInTrigger() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CardBlockProcessor.CARD_BLOCK_INTENT_NAME,
            new UserInput(CardBlockProcessor.FIELD_CARD_NUM, "1111"));


    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);

    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NUMBER, CardBlockProcessor.FIELD_CARD_NUM,
            ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(CardBlockProcessor.FIELD_CARD_NUM, "1234111111"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);

  }


}
