package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.cardrenew.CardRenewIntentProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;


/**
 * TODO:
 * <p>
 * 1) better testing fuzzy matching on webhook message output
 * 2) Fix confirmation on Insights Test
 * 3) TODO inject EAPI to mock out EAPI data
 *
 * @author jon
 */
public class WebhookServiceCardRenewTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();

    this.webhookService = new WebhookService();
    this.webhookService.setIntentProcessorFactory(processorFactory);

  }


  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CardRenewIntentProcessor.CARD_RENEW_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NUMBER, CardRenewIntentProcessor.FIELD_CARD_NUMBER,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.FIELD_CARD_NUMBER, "1234"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.DATE, CardRenewIntentProcessor.FIELD_CARD_EXPIRATION,
        ConversationResponse.ConversationState.PENDING_USER);

    SendUserInputRequest request5 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.FIELD_CARD_EXPIRATION, "1/2/20"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request5);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, CardRenewIntentProcessor.CONFIRM_SUBMISSION,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request6 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.CONFIRM_SUBMISSION, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request6);


    //assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

  }


  @Test
  public void testEndToEndNoConfirmation() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CardRenewIntentProcessor.CARD_RENEW_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NUMBER, CardRenewIntentProcessor.FIELD_CARD_NUMBER,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.FIELD_CARD_NUMBER, "1234"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.DATE, CardRenewIntentProcessor.FIELD_CARD_EXPIRATION,
        ConversationResponse.ConversationState.PENDING_USER);

    SendUserInputRequest request5 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.FIELD_CARD_EXPIRATION, "1/2/20"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request5);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, CardRenewIntentProcessor.CONFIRM_SUBMISSION,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request6 = new SendUserInputRequest(convoid, new UserInput(CardRenewIntentProcessor.CONFIRM_SUBMISSION, "no"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request6);


    //assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
    assertEquals("I canceled your card renewel request", response.message_contents.get(0).payload.toString());


  }


}
