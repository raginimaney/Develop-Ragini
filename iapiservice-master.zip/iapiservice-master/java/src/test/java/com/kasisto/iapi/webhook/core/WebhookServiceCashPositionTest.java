package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.bb.cashposition.CashPositionIntentProcessor;
import com.kasisto.iapi.webhook.apps.bb.cashposition.MockBusinessBankEAPI;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;


/**
 * TODO:
 * <p>
 * 1) better testing fuzzy matching on webhook message output
 * 2) Fix confirmation on Insights Test
 * 3) TODO inject EAPI to mock out EAPI data
 *
 * @author jon
 */
public class WebhookServiceCashPositionTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();
    processorFactory.setSimplifiedEnterpiseApi(new MockBusinessBankEAPI());

    this.webhookService = new WebhookService();

    this.webhookService.setIntentProcessorFactory(processorFactory);

  }


  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CashPositionIntentProcessor.CP_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.STRING, CashPositionIntentProcessor.FIELD_CURRENCY,
        ConversationResponse.ConversationState.PENDING_USER);


    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(CashPositionIntentProcessor.FIELD_CURRENCY, CashPositionIntentProcessor.CP_CURRENCY.EUR.name()));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.STRING, CashPositionIntentProcessor.FIELD_GUAI_CONSTRAINTS,
        ConversationResponse.ConversationState.PENDING_USER);

    SendUserInputRequest request5 = new SendUserInputRequest(convoid, new UserInput(CashPositionIntentProcessor.FIELD_GUAI_CONSTRAINTS, CashPositionIntentProcessor.CP_PERIOD.projected.name()));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request5);

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.STRING, CashPositionIntentProcessor.FIELD_GUAI_CONSTRAINTS,
        ConversationResponse.ConversationState.PENDING_USER);

  }


  @Test
  public void testNoAccountsForAccountNum() throws ApiException, SessionStoreException {


    List<UserInput> userInputs = new ArrayList<UserInput>();
    UserInput ui = new UserInput();
    ui.name = CashPositionIntentProcessor.FIELD_ACTNUM;
    ui.value = "99999999";

    userInputs.add(ui);

    //set a budget
    StartConversationRequest request = new StartConversationRequest(CashPositionIntentProcessor.CP_INTENT_NAME, userInputs);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    assertEquals("No matching accounts exist", response.message_contents.get(0).payload.toString());

  }


}
