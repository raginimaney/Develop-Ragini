package com.kasisto.iapi.webhook.core;

import com.kasisto.api.model.*;
import com.kasisto.api.model.Account.AccountTypeEnum;
import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.guai.GUAIIntentProcessor;
import com.kasisto.iapi.webhook.core.eapi.OfferRequest;
import com.kasisto.iapi.webhook.core.eapi.SimplifiedEnterpriseApi;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import domain.lola.user.bb.Offer;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;


/**
 * TODO:
 * <p>
 * 1) better testing fuzzy matching on webhook message output
 * 2) Fix confirmation on Insights Test
 * 3) TODO inject EAPI to mock out EAPI data
 *
 * @author jon
 */
public class WebhookServiceGUAITest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  private static List<Account> fixedAccounts;

  static {

    fixedAccounts = new ArrayList<Account>();

    Account account = new Account();
    account.setAccountName("wells fargo joint checking 1");
    account.setAvailableBalance(200d);
    account.setAccountType(AccountTypeEnum.CHECKING);
    account.setAccountNickname("share");


    Account account2 = new Account();
    account2.setAccountName("wells fargo joint checking 2");
    account2.setAvailableBalance(200d);
    account2.setAccountType(AccountTypeEnum.CHECKING);
    account2.setAccountNickname("share");

    Account account3 = new Account();
    account3.setAccountName("wells fargo savings");
    account3.setAvailableBalance(300d);
    account3.setAccountType(AccountTypeEnum.SAVINGS);
    account3.setAccountNickname("share");

    Account account4 = new Account();
    account4.setAccountName("wells fargo credit card");
    account4.setAvailableBalance(0d);
    account4.setPaymentDueAmount(1000d);
    account4.setAccountType(AccountTypeEnum.CREDIT_CARD);
    account4.setAccountNickname("mycc");

    Account account5 = new Account();
    account5.setAccountName("wells fargo credit card");
    account5.setAvailableBalance(0d);
    account5.setPaymentDueAmount(800d);
    account5.setAccountType(AccountTypeEnum.CREDIT_CARD);
    account5.setAccountNickname("work cc");

    fixedAccounts.add(account);
    fixedAccounts.add(account2);
    fixedAccounts.add(account3);
    fixedAccounts.add(account4);
    fixedAccounts.add(account5);

  }

  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();
    processorFactory.setSimplifiedEnterpiseApi(new SimplifiedEnterpriseApi() {

      @Override
      public List<Transaction> transactions(String secret, String token, TransactionCriteria transactionCriteria,
                                            Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public List<Payee> payees(String secret, String token, PayeesRequest payeesRequest,
                                Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public List<Merchant> merchants(String secret, String token, MerchantsRequest merchantsRequest,
                                      Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public Customer customer(String secret, String token, CustomerRequest customerRequest,
                               Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public List<Category> categories(String secret, String token, CategoriesRequest categoriesRequest,
                                       Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public CustomerActionResponse customerAction(HeaderData hData, CustomerActionRequest actionRequest, Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        // TODO Auto-generated method stub
        return null;
      }

      @Override
      public List<Offer> bankOffers(String secret, String token, OfferRequest offerRequest, Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        return null;
      }

      @Override
      public List<Account> accounts(String secret, String token, AccountsRequest accountsRequest,
                                    Map<String, String> responseHeaders) throws com.kasisto.iapi.webhook.core.eapi.ApiException {
        return fixedAccounts;
      }


    });

    this.webhookService = new WebhookService();
    this.webhookService.setIntentProcessorFactory(processorFactory);

  }


  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(GUAIIntentProcessor.GUAI_INTENT_NAME,
        new UserInput(GUAIIntentProcessor.FIELD_AGG, GUAIIntentProcessor.VAL_FIELD_AGG_TOTAL));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, GUAIIntentProcessor.CONFIRM_BREAKDOWN,
        ConversationResponse.ConversationState.PENDING_USER);

    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(GUAIIntentProcessor.CONFIRM_BREAKDOWN, "no"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);
    assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

  }


  @Test
  public void testGetCheckingTransactions() throws ApiException, SessionStoreException {
    StartConversationRequest request = new StartConversationRequest(GUAIIntentProcessor.GUAI_INTENT_NAME,
        new UserInput(GUAIIntentProcessor.FIELD_ACCOUNT_TYPE, "checking"));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);

    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
  }


}
