package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.insights.InsightsBudgetIntentProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.SendUserInputRequest;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.request.UserInput;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;
import com.kasisto.iapi.webhook.core.model.response.RequestUserInput;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;


/**
 * TODO:
 * <p>
 * 1) better testing fuzzy matching on webhook message output
 * 2) Fix confirmation on Insights Test
 * 3)
 *
 * @author jon
 */
public class WebhookServiceInsightsTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    this.webhookService = new WebhookService();
    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();
    //no need to add EAPI dependency for insights api
    this.webhookService.setIntentProcessorFactory(processorFactory);

  }

  @Test
  public void testEndToEnd() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME,
        new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    Assert.assertEquals(response.request_user_input.getTypeNorm(), RequestUserInput.UserInputType.STRING);
    assertEquals(response.request_user_input.name, InsightsBudgetIntentProcessor.FIELD_CATEGORY);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the category for the budget");
    Assert.assertEquals(ConversationResponse.ConversationState.PENDING_USER, response.conversation_state);

    //food
    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);
    assertEquals(response.request_user_input.getTypeNorm(), RequestUserInput.UserInputType.NUMBER);
    assertEquals(response.request_user_input.name, InsightsBudgetIntentProcessor.FIELD_AMOUNT);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the amount you want to set for the budget");
    Assert.assertEquals(ConversationResponse.ConversationState.PENDING_USER, response.conversation_state);

    //$200
    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_AMOUNT, "200"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);
    assertEquals(response.request_user_input.getTypeNorm(), RequestUserInput.UserInputType.BOOLEAN);
    assertEquals(response.request_user_input.name, InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION);
    assertEquals(response.message_contents.get(0).payload.toString(), "Let's confirm, you want to set a budget for category food for an amount of 200");
    Assert.assertEquals(ConversationResponse.ConversationState.PENDING_USER, response.conversation_state);

    //yes
    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);
    assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
    assertEquals(response.message_contents.get(0).payload.toString(), "I set a budget for category food for amount of 200");
  }

  /**
   * Using a helper function, this is a equivalent test run to above but uses a helper function
   * to encouraging testing type, conversation state, and response in a single call and
   * makes it easier to read.
   *
   * @throws ApiException
   */
  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME,
        new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;

    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.STRING, InsightsBudgetIntentProcessor.FIELD_CATEGORY,
        ConversationResponse.ConversationState.PENDING_USER);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the category for the budget");


    //food
    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);
    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.NUMBER, InsightsBudgetIntentProcessor.FIELD_AMOUNT,
        ConversationResponse.ConversationState.PENDING_USER);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the amount you want to set for the budget");

    //$200
    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_AMOUNT, "200"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);
    WHTestHelper.validateUserInput(response, RequestUserInput.UserInputType.BOOLEAN, InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION,
        ConversationResponse.ConversationState.PENDING_USER);
    assertEquals(response.message_contents.get(0).payload.toString(), "Let's confirm, you want to set a budget for category food for an amount of 200");

    //yes
    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);
    assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);

    assertEquals(response.message_contents.get(0).payload.toString(), "I set a budget for category food for amount of 200");
  }


  @Test
  public void testCategoryProvidedAtStart() throws ApiException, SessionStoreException {

    //set a budget for food
    List<UserInput> inputs = Arrays.asList(new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET),
        new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"));

    //set a budget
    StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME, inputs);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;
    //assertEquals(response.request_user_input.type,RequestUserInput.UserInputType.NUMBER);
    assertEquals(response.request_user_input.name, InsightsBudgetIntentProcessor.FIELD_AMOUNT);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the amount you want to set for the budget");

    //$200
    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_AMOUNT, "200"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);
    assertEquals(response.request_user_input.getTypeNorm(), RequestUserInput.UserInputType.BOOLEAN);
    assertEquals(response.request_user_input.name, InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION);
    assertEquals(response.message_contents.get(0).payload.toString(), "Let's confirm, you want to set a budget for category food for an amount of 200");

    //yes
    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION, "yes"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);
    assertNull(response.request_user_input);
    Assert.assertEquals(ConversationResponse.ConversationState.COMPLETED, response.conversation_state);
    assertEquals(response.message_contents.get(0).payload.toString(), "I set a budget for category food for amount of 200");
  }

  @Test
  public void testEndToEndBadCategory() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME,
        new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the category for the budget");

    //food
    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "madeupcategory"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);
    assertEquals(response.message_contents.get(0).payload.toString(), "Not a valid category. What is the category for the budget");

  }

  @Test
  public void testNoConfirmation() throws ApiException, SessionStoreException {

    //set a budget
    StartConversationRequest request = new StartConversationRequest(InsightsBudgetIntentProcessor.IB_INTENT_NAME,
        new UserInput(InsightsBudgetIntentProcessor.FIELD_ACTION, InsightsBudgetIntentProcessor.ACTION_SET));
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the category for the budget");


    //food
    SendUserInputRequest request2 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_CATEGORY, "food"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request2);
    assertEquals(response.message_contents.get(0).payload.toString(), "What is the amount you want to set for the budget");

    //$200
    SendUserInputRequest request3 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.FIELD_AMOUNT, "200"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request3);
    assertEquals(response.message_contents.get(0).payload.toString(), "Let's confirm, you want to set a budget for category food for an amount of 200");

    //yes
    SendUserInputRequest request4 = new SendUserInputRequest(convoid, new UserInput(InsightsBudgetIntentProcessor.CONFIRM_SUBMISSION, "no"));
    response = webhookService.handleSendUserInput(secret, token, locale, request_id, date, request4);
    assertEquals(response.message_contents.get(0).payload.toString(), "FAQ1");
  }
}
