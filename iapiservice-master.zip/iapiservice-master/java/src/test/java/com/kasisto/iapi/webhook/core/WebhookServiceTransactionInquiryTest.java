package com.kasisto.iapi.webhook.core;

import com.kasisto.iapi.webhook.apps.MyApplicationIntentProcessorFactory;
import com.kasisto.iapi.webhook.apps.bb.cashposition.MockBusinessBankEAPI;
import com.kasisto.iapi.webhook.apps.bb.transactioninquiry.TransactionInquiryIntentProcessor;
import com.kasisto.iapi.webhook.core.exception.ApiException;
import com.kasisto.iapi.webhook.core.exception.SessionStoreException;
import com.kasisto.iapi.webhook.core.model.request.StartConversationRequest;
import com.kasisto.iapi.webhook.core.model.response.ConversationResponse;

import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;


/**
 * TODO:
 *
 * @author jon
 */
public class WebhookServiceTransactionInquiryTest {

  WebhookService webhookService;
  String secret = "secret";
  String token = "token";
  String locale = "locale";
  String request_id = "req1";
  Date date = null;


  @Before
  public void setUp() throws Exception {

    MyApplicationIntentProcessorFactory processorFactory = new MyApplicationIntentProcessorFactory();
    processorFactory.setSimplifiedEnterpiseApi(new MockBusinessBankEAPI());

    this.webhookService = new WebhookService();
    this.webhookService.setIntentProcessorFactory(processorFactory);


  }


  @Test
  public void testEndToEndWithHelperFunction() throws ApiException, SessionStoreException {

    //Initialize baseline_form
    StartConversationRequest request = new StartConversationRequest(TransactionInquiryIntentProcessor.TX_INQUIRY_INTENT_NAME);
    ConversationResponse response = webhookService.handleStartConversation(secret, token, locale, request_id, date, request);
    String convoid = response.conversation_id;


    assertEquals("What is your reference number?",response.message_contents.get(0).payload.toString());
    Assert.assertEquals(ConversationResponse.ConversationState.PENDING_USER, response.conversation_state);
  }



}
