# Running the IAPI Node webhook

A Node.js version of the IAPI services has been built with reference examples.  Our implementations utilise the [botkit](https://botkit.ai/) framework.   

## Getting Started

1. install the latest version (10.05+) of node
(https://nodejs.org/en/)
2. install dependencies
npm cache clean --force
npm install
3. configure config/config.js
update iapi.secret and iapi.token with kasisto secret and token
5. Run the iapi webhook service
npm start
6. if any dependencies are not found - you can install locally by:
npm install <dependency>
  
# Example Intents

The intent-definitions for the node examples are located [here](../intent_definitions/node/).   There are set of common library utilities in the form of node-modules available in [lib](./lib).  This include EAPI and caching utilities. The individual bot intents are located in [skills directory](dialog/framework/botkit/bots/skills/)

# Architecture
Below shows the general architecture of the IAPI node-applications. 
![alt text](https://github.com/kasisto/iapiservice/blob/master/node/docs/node_arch.png)

# Sample video
Below shows a walk through of the node version of the Cash-Position Intent
[Video](https://github.com/kasisto/iapiservice/blob/master/node/docs/node_cash_position.mp4)

# Botkit Example of using the IAPI webhook
Check out this [video](https://drive.google.com/file/d/1l2SW0LWVTZllxSUzDSKHweKA6pjMk2Wj/view?usp=sharing)
that shows examples of the IAPI webhook being uses for 2 example intents:

1. kai_find_atm_td2 - "where is the nearest atm"
2. kai_find_branch_td2 "where is the nearest branch"

Each of these intents, are handled by the same bot (dialog/framework/botkit/bot/kai.js).  
However, Each intent is handled by a different skill implemented in dialog/framework/botkit/skills/skills_td_location_finder.js
The example shows how dialog context (in this case name and zip code) can be get/set and re-used between intents to create a richer experience.
The dilog also provides integration to the td_location API as an example to demostrate transaction fullfillmenmt

=======
# MS Bot Framework Example
The webhook also implements a handler for the Microsoft Bot Framework
The dialog is implemented fopr the example intent:
1. find_td - "where is the nearest td"

This dialog is implemented in dialog/framework/msbotframework/bots/td_atm_finder_example.js


===========
# How to test your bot locally


Bring up stable kai or run-kai locally from the root-directory

```
docker-compose up kai
```

Set the appropriate environment properties to configure app to override config.js if necessary.

```
export NODE_ENV=dev
export IAPI_PORT=8290
export IAPI_HOSTNAME=host.docker.internal (or use ngrok) 
```

Start the node service from <iapiservice>/node directory. It will automatically load the intent definitions at startup. 

```
npm start
```

To run the Botium CLI/Tests.  From <iapiservice>/test/testcases/botium,  run Testproxy and then either the CLI tool or Botium test-runner after specifying botium testfile directory 

```
npm run testproxy
then either:
npm run emulator
(or) 
export BOTIUM_CONVO_PATH=<path-to-testfiles>(e.g.<iapiservice>/test/testcases/botium/spec/convo)
npm run testdev
```

Update you appropriate skills.js source and restart via 'npm start' to pick up your changes, using the emulator or json tool to verify changes. 

To run the Functional test-cases. Update IAPI_TYPE=node in docker-compose.yml From <iapiservice> directory:

```
docker-compose up functional_testrunner
``` 
