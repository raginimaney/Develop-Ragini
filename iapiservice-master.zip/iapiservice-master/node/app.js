///////////////////////////////////////////////////////////////////////////////
// Kasisto IAPI Framework setup
// uses Microsoft Bot Framework
///////////////////////////////////////////////////////////////////////////////
const LOGTAG = `IAPI=>`;
const kaiutils = require('./lib/kai-utils');
const axios = require("axios");
const path = require('path')
global.XMLHttpRequest = require("xhr2");
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
var config = require('./config/config');
const logger = require('./lib/logger');
const uuidv4 = require('uuid/v4');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const express = require('express');
const app = express();
var sleep = require('system-sleep');
const util = require('util');

/*
usage - examples:
DEBUG=iapi:* npm start
DEBUG=iapi:kai* npm start
DEBUG=iapi:kai:to*req,iapi:kai:from:resp:*  npm start
etc
*/

var debug_kaitoreq = require('debug')('iapi:kai:to:req')
var debug_kaitoresp = require('debug')('iapi:kai:to:resp')
var debug_kaifromreq = require('debug')('iapi:kai:from:req')
var debug_kaifromresp = require('debug')('iapi:kai:from:resp')
var debug = require('debug')('iapi:app')
// Place the express-winston logger before the router.
//appIAPI.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser({limit: '50mb'}));
//app.use(morgan('common', {}));

const conversationStateEnum = {
    PENDING_USER: 'PENDING_USER',
    COMPLETED: 'COMPLETED',
    CANCELLED: 'CANCELLED',
    FAILED: 'FAILED',
};

//////////////////////////////////////////////////////////////////////////////
// App Session Storage
//////////////////////////////////////////////////////////////////////////////
var storage = require('./lib/iapi-storage')();


//////////////////////////////////////////////////////////////////////////////
// Kasisto IAPI specific
///////////////////////////////////////////////////////////////////////////////
const FRAMEWORK_BOTKIT = "FRAMEWORK_BOTKIT";
var botregistry_workers = {};  //referenced by threadid
var botregistry_intent_workers ={}; //referenced by intent
var botregistry_intent_thread ={}; //referenced by intent
var botregistry_workers_confObj={}; //referenced by threadid
var botregistry_conversations = {} ; //referenced by conversation_id


//////////////////////////////////////////////////////////////////////////////
// Init All Bots in bot_definitions
///////////////////////////////////////////////////////////////////////////////

// Read botFilePath and botFileSecret from .env file.
// .bot file path
const BOT_FILE_PATH = config.get('bot_framework_path');
// Read the configuration from a .bot file.
// This includes information about the bot's endpoints and Bot Framework configuration.
var fs = require('fs');
let botConfig;
var this_intent_name = null;
fs.readdir(BOT_FILE_PATH,function(err,frameworks){
    if(err) throw err;
    frameworks.forEach(function(framework) {
        // do something with each file HERE!
        // Read bot configuration from .bot file.
        fs.readdir(BOT_FILE_PATH + "/" + framework + "/bots",function(err,files) {
            files.forEach(function(file) {
                if(err) throw err;
                if (file.endsWith(".js")) {
                    ///////////////////////////////////////////////////////////////////////////////
                    //create worker thread for each bot and register (save thread details)
                    ///////////////////////////////////////////////////////////////////////////////
                    var path = `${BOT_FILE_PATH}/${framework}/bots/${file}`;
                    const w = new Worker(path, {workerData: null});
                    var threadid = uuidv4();
                    w.on('message', (msg) => {  //get START ACK and save worker
                        logger.debug('%s Received msg from worker thread [%s]: %j', LOGTAG, threadid, msg)
                        //get msg from worker
                        var confObj = {};
                        confObj.bot_intent = msg.botintent;
                        confObj.bot_port = msg.botport;
                        confObj.bot_framework = msg.botframework;
                        confObj.bot_status = msg.botstatus;
                        confObj.bot_id = msg.botid;
                        confObj.bot_name = msg.botname;
                        confObj.bot_desc = msg.botdesc;
                        confObj.bot_resp = msg.botresp;
                        confObj.bot_workerthreadid = msg.workerthreadid;

                        var thread_isactive = true;
                        if (confObj.bot_status == 'NOT_ACTIVE') {
                            logger.debug('%s Bot NOT_ACTIVE with worker thread [%s] - Destroying worker thread', LOGTAG, threadid);
                            w.destroy;
                            thread_isactive = false;

                        }
                        //save worker details
                        if (thread_isactive == true) {
                            botregistry_intent_workers[confObj.bot_intent] = threadid;
                            botregistry_workers_confObj[threadid] = confObj;
                            botregistry_workers[threadid] = w;
                            botregistry_intent_thread[confObj.bot_intent] = threadid;
                            if (confObj.bot_status == 'STARTED') {
                                //setup connection to bot framework if required
                                if (confObj.bot_framework == FRAMEWORK_BOTKIT) {
                                    // add any framework init here
                                } else {
                                    //add any default framework init here

                                }



                            } else if (confObj.bot_status == 'STOPPED') {
                                //TODO
                            }
                        }
                    })

                    var msg = {threadid: threadid, status: 'START'};
                    w.postMessage(msg) // send messages to workers

                }
            });
        });
    });
});


//////////////////////////////////////////////////////////////////////////////
// Init Intent Definitions
///////////////////////////////////////////////////////////////////////////////
const INTENT_DEFINITIONS_FILE_PATH = path.join(config.get('intent_definitions_path'),'node');

const LOAD_DEFS = config.get('load_definitions')
logger.info('LOAD_DEFS:'+LOAD_DEFS)
var fs = require('fs');
if(LOAD_DEFS === true){
    fs.readdir(INTENT_DEFINITIONS_FILE_PATH,function(err,files){
	logger.info('LOAD_DEFS:'+INTENT_DEFINITIONS_FILE_PATH)
        if(err) throw err;
        logger.info(LOGTAG + 'STARTING => Register Intents...')
        files.forEach(function(file) {
            if(err) throw err;
            if (file.endsWith(".json")) {
                var intent_definition = require(path.join(config.get('intent_definitions_path'),'node',file))
                ///////////////////////////////////////////////////////////////////////////////
                //create intent request
                ///////////////////////////////////////////////////////////////////////////////
                //update webhook_url
                try {
                    var registered=false;
                    var needsleep=false;
                    while (!registered) { //do until intents are registered
                        if (needsleep == true){
                            sleep(5000)
                        }
                        if (registered == true)
                            throw "BreakException"
                        intent_definition['webhook_url'] = `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/api/intents`
                        //logger.debug(LOGTAG + 'Registering file => %s ', file)
                        const url = `${config.get('kai.protocol')}://${config.get('kai.hostname')}:${config.get('kai.port')}/kai/api/v1/intents`
                        const intent_headers = []
                        intent_headers.push('Content-Type: application/json')
                        intent_headers.push(`secret: ${config.get('iapi.secret')}`)

                        logger.debug(LOGTAG + 'Registering Intent Request [%s] to  => %s ', file, url)
                        logger.debug(LOGTAG + 'Registering request headers  => %j ', intent_headers)
                        logger.debug(LOGTAG + 'Registering request body  => %j ', intent_definition)

                        const curl = new (require( 'curl-request' ))();
                        needsleep = true
                        debug_kaitoreq('REQUEST SENT %s\nREQUEST HEADERS %o\nREQUEST BODY\n%O', intent_definition['webhook_url'],intent_headers, intent_definition)
                        curl.setHeaders(intent_headers)
                            .setBody(JSON.stringify(intent_definition))
                            .post(url)
                            .then(({statusCode, body, headers}) => {
                                needsleep = true
                                debug_kaitoresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', headers, body)
                                if (statusCode == 200) {
                                    registered = true
                                    needsleep =false
                                } else {
                                    needsleep = true
                                    logger.warn(LOGTAG + 'Error HTTP %s - Intent not Registered.  Will retry in 5 seconds.', statusCode)
                                }
                            })
                            .catch(function (error) {
                                needsleep = true
                                logger.warn(LOGTAG + 'Error %j - Intent not Registered.  Will retry in 5 seconds.', error)
                            });
                    }
                } catch (e){
                    logger.debug(LOGTAG + 'FINISHED => Intent Registered!')
                }

            }
        });
        logger.info(LOGTAG + 'FINISHED => All Intents Registered! iapiservice-node READY');
        app.use('/healthcheck', require('express-healthcheck')());
    });
}
///////////////////////////////////////////////////////////////////////////////
// Setup kasisto Intent API Routes
// uses the DirectLine client to route conversations to the bot framework
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
app.post('/api/intents/start_conversation', (req, res) => {
///////////////////////////////////////////////////////////////////////////////
    debug_kaifromreq('REQUEST RECEIVED %s \nREQUEST HEADERS %o\nREQUEST BODY\n%O', '/api/intents/start_conversation',req.headers, req.body)
	logger.debug(LOGTAG + '/api/intents/start_conversation => headers => %j', req.headers)
	logger.debug(LOGTAG + '/api/intents/start_conversation => body => %j', req.body)
    processIAPIStartConversation(req, res);
});
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
app.post('/api/intents/send_user_input', (req, res) => {
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
    debug_kaifromreq('REQUEST RECEIVED %s \nREQUEST HEADERS %o\nREQUEST BODY\n%O', '/api/intents/send_user_input',req.headers, req.body)
    logger.debug(LOGTAG + '/api/intents/send_user_input => headers => %j', req.headers)
	logger.debug(LOGTAG + '/api/intents/send_user_input => body => %j', req.body)
	processIAPISendUserInput(req, res);

});
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
app.post('/api/intents/cancel_user_input', (req, res) => {
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
    debug_kaifromreq('REQUEST RECEIVED %s \nREQUEST HEADERS %o\nREQUEST BODY\n%O', '/api/intents/cancel_user_input',req.headers, req.body)
    logger.debug(LOGTAG + '/api/intents/cancel_user_input => headers => %j', req.headers)
	logger.debug(LOGTAG + '/api/intents/cancel_user_input => body => %j', req.body)
    processIAPICancelUserInput(req, res);
});


app.listen(config.get('iapi.port'), function() {
	logger.info(LOGTAG + `Kasitso IAPI Webhook listening on ${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/api/intents`);

});

///////////////////////////////////////////////////////////////////////////////
// IAPI Public Assets. - e.g images or html pages
///////////////////////////////////////////////////////////////////////////////


app.use('/public', express.static(__dirname + '/public'));
logger.info(LOGTAG + `Kasitso IAPI Public assets available on  on ${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public`);

///////////////////////////////////////////////////////////////////////////////
// IAPI Utility / Helper functions.
///////////////////////////////////////////////////////////////////////////////


errorHandling = (res, err) => {
    logger.error(err)
    if (!err.code) {
        err.code = 500;
    }
    res.status(err.code).send({
        message: err.message,
        code: err.code.toString(),
        otp_details: err.otp_details || '',
        meta: err.meta || []
    });
};

verifyToken = (req, user_id) => {
    //TODO
    if (config.get('iapi.token')){
        if(req.header('token') !== config.get('iapi.token') || user_id === null) {
            throw ({ code: 401, message: 'Authentication Failed' });
        }
    }

};

verifySecret = (req) => {
    if(req.header('secret') !== config.get('iapi.secret')) {
        throw ({ code: 403, message: 'Access Denied' });
    };
};


generateIntentConversationId = () => {
    var newUUID = uuidv4();
    return newUUID;
};


updateConversationSessionContext = (message, conversation_session_context) => {
    conversation_session_context.dialog = message.extra.dialog
    //debug("updateConversationSessionContext->Saving conversation_session_context.dialog=%o", message.extra.dialog)
    storage.conversations.save(conversation_session_context, function (err) {
            if (err) throw err
            logger.debug(LOGTAG + `Saved updateConversationSessionContext for conversation id [${conversation_session_context.id}]`);
    })

};


parseBotkitResponse = (text) => {
    var parsedObj ={}
    parsedObj.raw = {}
    parsedObj.kai={}

    var str = text.replace(/&#x2F;/g, '/');
    var tojson = JSON.parse(str.replace(/&quot;/g,'"'));
    //console.log(util.inspect(tojson, false, null, true /* enable colors */))
    parsedObj.raw.message_contents = tojson.message_contents;
    if (typeof(tojson.request_user_input) != 'undefined'){
        parsedObj.raw.request_user_input = tojson.request_user_input;
    }
    parsedObj.raw.message_options = tojson.message_options;
    //console.log(util.inspect(parsedObj, false, null, true /* enable colors */))

    if (typeof(parsedObj.raw.message_contents) != undefined) {
        if( typeof (parsedObj.raw.message_contents) === 'string' ) {
            parsedObj.kai.message_contents=kaiutils.createTextMessage(parsedObj.raw.message_contents).message_contents
        } else {
            parsedObj.kai.message_contents=parsedObj.raw.message_contents
        }
 } else {
        parsedObj.kai.message_contents=kaiutils.createTextMessage(str).message_contents
    }

    var request_user_input ={}
    if (typeof(parsedObj.raw.request_user_input) != 'undefined'){
        request_user_input = parsedObj.raw.request_user_input;
    } else {
        request_user_input = {
            name: parsedObj.raw.message_options.user_input_name,
            type: parsedObj.raw.message_options.user_input_type,
        };
    }


    if (typeof(parsedObj.raw.message_options.user_input_norm_type) != undefined){
        request_user_input.norm_type = parsedObj.raw.message_options.user_input_norm_type
    }

    parsedObj.kai.request_user_input = request_user_input
    parsedObj.complete = parsedObj.raw.message_options.complete
    //console.log(util.inspect(parsedObj, false, null, true /* enable colors */))
    return parsedObj

};

addMessageContent = (responseObj, parsedObj) => {
        responseObj.message_contents = parsedObj.kai.message_contents
};

addRequestInput = (responseObj, parsedObj) => {
        responseObj.request_user_input = parsedObj.kai.request_user_input;
};


modifyConversationState = (responseObj, state) => {
    responseObj.conversation_state = state;
};

processIAPIStartConversation = (req, res) => {
	try {
		verifySecret(req);

        if (req.body.intent_name){
            var skill = req.body.intent_name
            var skill_pattern = req.body.intent_name
            var BreakException = {};
            //try and match with all intent

            try {
                for(var index in botregistry_intent_workers) {
                    var pattern = index;
                    var found = skill.match(new RegExp(pattern));

                    if (found != null) {
                        if (found[0] != found[1]){
                            skill = found[1];
                            if (skill == undefined){
                                skill = found[0]
                            }
                            skill_pattern = pattern;
                            throw BreakException
                        }
                    }
                }
            } catch(e) {
                if (e !== BreakException) throw e;
            }
        }
		if (skill && botregistry_intent_workers[skill_pattern]) {
            var conversation_id = generateIntentConversationId()
            var intentData = {conversation_id: conversation_id, intent_name:skill, token: req.header('token'), intent_pattern:skill_pattern, user_inputs: req.body.user_inputs,  user_id: conversation_id, text: req.body.user_message.payload.text};
            var responseObj = { conversation_id: intentData.conversation_id, conversation_state: conversationStateEnum.PENDING_USER, message_contents: [], request_user_input: {} };
			//get worker thread
			var threadid =botregistry_intent_thread[skill_pattern];
			//get worker config
			var confObj = botregistry_workers_confObj[threadid];
			//save conversation reference
            botregistry_conversations[intentData.conversation_id] = {intent_name: intentData.intent_name, intent_pattern:skill_pattern, user_id: intentData.user_id, thread_id: threadid}

            //create context
            var conversation_session_context = {}
            conversation_session_context.id = conversation_id
            conversation_session_context.dialog = {}
            conversation_session_context.dialog.id = conversation_id
            conversation_session_context.dialog.store = {}
            conversation_session_context.dialog.store.skill = {}
            conversation_session_context.dialog.store.iapi = {}
            conversation_session_context.dialog.store.iapi.autosaved = {} //auto updated by iapi
            conversation_session_context.dialog.store.iapi.stack= []//auto updated by iapi
            conversation_session_context.skill = skill
            conversation_session_context.skill_pattern = skill_pattern
            conversation_session_context.botregistry_worker_confobj = botregistry_workers_confObj[threadid]
            conversation_session_context.botregistry_conversation = botregistry_conversations[intentData.conversation_id]
            storage.conversations.save(conversation_session_context, function (err) {
                logger.debug(LOGTAG + "Conversations Session Context Created")
            })


            //Verify Token
			verifyToken(req, intentData.user_id);


			var framework = confObj.bot_framework.trim();
                if (framework == FRAMEWORK_BOTKIT){
                ////////////////////////////////////////////////////////////////////////////////////
                // Process IAPI intents via botkit framework
                ////////////////////////////////////////////////////////////////////////////////////
                var url = 'http://127.0.0.1:' + confObj.bot_port + '/botkit/receive'
                var text_input= intentData.intent_name;
                var user_id = intentData.user_id;
                intentData.dialog = conversation_session_context.dialog;
                logger.debug(LOGTAG + "Posting request to url[%s] text [%s] extra[%j]",url, text_input,intentData)
                var config =  { headers: {'Content-Type': 'application/json' }}
                axios.post(url, {
                    "text": text_input,
                    "user": user_id,
                    "channel": "webhook",
                    "extra": intentData
                }, config)
                    .then(function (response) {
                        logger.debug(LOGTAG + "received response => %j", response.data);
                        if (response.data.user == intentData.user_id) {
                            var parsedObj = parseBotkitResponse(response.data.text)
                            if (parsedObj.complete == true) {
                                //Cancel bot
                                var url = 'http://127.0.0.1:' + confObj.bot_port + '/botkit/cancel'
                                //var text_input = intentData.user_inputs[0].value;
                                //var text_input_data= utils.createStrMessage(intentData);
                                var user_id = intentData.user_id;
                                //logger.debug(LOGTAG + "Posting request to url[%s] text [%s]", url, text_input)
                                var config = {headers: {'Content-Type': 'application/json'}}
                                addMessageContent(responseObj, parsedObj);
                                addRequestInput(responseObj, parsedObj);
                                modifyConversationState(responseObj, conversationStateEnum.COMPLETED);
                                updateConversationSessionContext(response.data, conversation_session_context)
                                axios.post(url, {
                                    "user": user_id,
                                    "channel": "webhook",
                                }, config)
                                    .then(function (response) {
                                        logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                                        debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                                        return res.status(200).send(responseObj)
                                    });

                            } else {
                                addMessageContent(responseObj, parsedObj);
                                modifyConversationState(responseObj, conversationStateEnum.PENDING_USER);
                                addRequestInput(responseObj, parsedObj);
                                updateConversationSessionContext(response.data, conversation_session_context)
                                //clear input field
                                intentData.user_inputs.input_string = null;
                                logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj)
                                debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                                return res.status(200).send(responseObj)

                            }


                        }
                        logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                        return res.status(200)

                    })
                    .catch(function (error) {
                        console.log(error);
                    });




            } else {
                ////////////////////////////////////////////////////////////////////////////////////
                // Process IAPI intents via (default) bespoke framework - i.e. no external framework
                ////////////////////////////////////////////////////////////////////////////////////
                //get worker
                logger.debug(LOGTAG + `Processing request using framework => [%s]`, framework);
                var w = botregistry_workers[threadid]
				var msg={threadid: threadid, status:'IAPI_REQUEST', intentData: intentData, responseObj: responseObj};
				w.on('message', (msg) => {
					logger.debug(LOGTAG + "DEBUG => %j", msg);
					responseObj = msg.iapi_resp;
					//return
					logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                    debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                    res.status(200).send(responseObj);

				});
				w.postMessage(msg)
			}


		} else {
			throw ({ code: 500, message: 'Unsupported Intent' });
		}
	} catch (err) {
		errorHandling(res, err);
	}

};




processIAPISendUserInput = (req, res) => {
    try {
        verifySecret(req);
        //get conversation from saved state
        var conversation_session_context = {}

        var promise = new Promise(function (resolve, reject) {
            storage.conversations.get(req.body.conversation_id, function(err, user_data) {
                if (err) return reject(err)
                return (resolve(user_data))
            })
        })

        promise.then(function(user_data) {
            conversation_session_context =user_data
            var botregistry_conversation = conversation_session_context.botregistry_conversation
            var botregistry_workers_confobj = conversation_session_context.botregistry_worker_confobj
            var conversation = botregistry_conversation
            logger.debug(LOGTAG + `Retrieved conversation context for conversation id [${req.body.conversation_id}] %j `,conversation);

            var intent = conversation.intent_name
            var intent_pattern = conversation.intent_pattern
            var user_id = req.body.conversation_id
            var threadid = conversation.thread_id

            //add user input and save dialog context, dialog stack
            var ts = Math.round((new Date()).getTime()) +"" //milliseconds from UNIX epoch
            req.body.user_inputs.forEach(function (obj) {
                var key= obj.name
                var val = obj.value
                var tmp ={
                    name: key,
                    value: val,
                    unixts: ts
                }

                conversation_session_context.dialog.store.iapi.autosaved[key] = val //overwrites key if exists
                conversation_session_context.dialog.store.iapi.stack.push(tmp) //creates a stack of inputs
                logger.debug(LOGTAG + "Conversations Session Context Updated - added dialog.store.iapi.autosaved, dialog.store.iapi.stack")

            });

            //debug(conversation_session_context)
            storage.conversations.save(conversation_session_context, function (err) {
                if (err) throw err
                logger.debug(LOGTAG + `Saved conversation session context for conversation id [${req.body.conversation_id}] %j `,conversation_session_context);
            })

             //console.log(util.inspect(conversation_session_context, false, null, true /* enable colors */))

            if (intent && botregistry_workers_confobj) {
                var intentData = {conversation_id: req.body.conversation_id, token: req.header('token'), user_inputs: req.body.user_inputs,  user_id: user_id, user_message: req.body.user_message, text: req.body.user_message.payload.text};
                var responseObj = { conversation_id: intentData.conversation_id, conversation_state: conversationStateEnum.PENDING_USER, message_contents: [], request_user_input: {} };


                //get worker config
                var confObj = botregistry_workers_confobj;


                //Verify Token
                verifyToken(req, user_id);


                var framework = confObj.bot_framework.trim();
                logger.debug(LOGTAG + `Processing request using framework => [%s]`, framework);
                if (framework == FRAMEWORK_BOTKIT){
                    ////////////////////////////////////////////////////////////////////////////////////
                    // Process IAPI intents via botkit framework
                    ////////////////////////////////////////////////////////////////////////////////////
                    var url = 'http://127.0.0.1:' + confObj.bot_port + '/botkit/receive'
                    var text_input =intentData.user_inputs[0].value;
                    var user_id = intentData.user_id;
                    intentData.dialog = conversation_session_context.dialog
                    logger.debug(LOGTAG + "Posting request to url[%s] text [%s] extra[%j]",url, text_input,intentData)
                    var config =  { headers: {'Content-Type': 'application/json' }}
                    axios.post(url, {
                        "text": text_input,
                        "user": user_id,
                        "channel": "webhook",
                        "extra": intentData
                    }, config)
                        .then(function (response) {
                            logger.debug(LOGTAG + "received response => %j", response.data);
                            if (response.data.user == intentData.user_id) {
                                var parsedObj = parseBotkitResponse(response.data.text)
                                if (parsedObj.complete == true) {
                                    //Cancel bot
                                    var url = 'http://127.0.0.1:' + confObj.bot_port + '/botkit/cancel'
                                    //var text_input = intentData.user_inputs[0].value;
                                    //var text_input_data= utils.createStrMessage(intentData);
                                    var user_id = intentData.user_id;
                                    //logger.debug(LOGTAG + "Posting request to url[%s] text [%s]", url, text_input)
                                    var config = {headers: {'Content-Type': 'application/json'}}
                                    addMessageContent(responseObj, parsedObj);
                                    addRequestInput(responseObj, parsedObj);
                                    modifyConversationState(responseObj, conversationStateEnum.COMPLETED);
                                    updateConversationSessionContext(response.data, conversation_session_context)
                                    axios.post(url, {
                                        "user": user_id,
                                        "channel": "webhook",
                                    }, config)
                                        .then(function (response) {
                                            logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                                            debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                                            return res.status(200).send(responseObj)

                                        });

                                } else {
                                    addMessageContent(responseObj, parsedObj);
                                    modifyConversationState(responseObj, conversationStateEnum.PENDING_USER);
                                    addRequestInput(responseObj, parsedObj);
                                    updateConversationSessionContext(response.data, conversation_session_context)
                                    //clear input field
                                    intentData.user_inputs.input_string = null;
                                    logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                                    debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                                    return res.status(200).send(responseObj)

                                }


                            }
                            logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                            return res.status(200)
                        })
                        .catch(function (error) {
                            console.log(error);
                        });

                } else {
                    ////////////////////////////////////////////////////////////////////////////////////
                    // Process IAPI intents via (default) bespoke framework - i.e. no external framework
                    ////////////////////////////////////////////////////////////////////////////////////
                    //get worker
                    logger.debug(LOGTAG + `Processing request using framework => [%s]`, framework);
                    var w = botregistry_workers[threadid]
                    var msg={threadid: threadid, status:'IAPI_REQUEST', intentData: intentData, responseObj: responseObj};
                    w.on('message', (msg) => {
                        logger.debug(LOGTAG + "DEBUG => %j", msg);
                        responseObj = msg.iapi_resp;
                        //return
                        logger.debug(LOGTAG + "Returning to IAPI => %j", responseObj);
                        debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, responseObj)
                        res.status(200).send(responseObj);

                    });
                    w.postMessage(msg)
                }


            } else {
                throw ({ code: 500, message: 'Unsupported Intent' });
            }

        })


    } catch (err) {
        errorHandling(res, err);
    }

};

processIAPICancelUserInput = (req, res) => {
    try {
        verifySecret(req);
        //get conversation from saved state
        var conversation_session_context = {}
        var promise = new Promise(function (resolve, reject) {
            storage.conversations.get(req.body.conversation_id, function(err, user_data) {
                if (err) return reject(err)
                return (resolve(user_data))
            })
        })

        promise.then(function(user_data) {
            conversation_session_context = user_data
            var botregistry_conversation = conversation_session_context.botregistry_conversation
            var botregistry_workers_confobj = conversation_session_context.botregistry_worker_confobj
            var conversation = botregistry_conversation
            //logger.debug(LOGTAG + `Retrieved conversation context for conversation id [${req.body.conversation_id}] %j `,conversation);

            var intent = conversation.intent_name
            var intent_pattern = conversation.intent_pattern
            var user_id = req.body.conversation_id
            var threadid = conversation.thread_id


            if (intent && botregistry_workers_confobj) {
                var intentData = {conversation_id: req.body.conversation_id, token: req.header('token')};
                var responseObj = { conversation_id: intentData.conversation_id, conversation_state: conversationStateEnum.CANCELLED, message_contents: [], request_user_input: {} };


                //get worker config
                var confObj = botregistry_workers_confobj;


                //Verify Token
                verifyToken(req, user_id);


                var framework = confObj.bot_framework.trim();
                logger.debug(LOGTAG + `Processing request using framework => [%s]`, framework);
                if (framework == FRAMEWORK_BOTKIT) {
                    ////////////////////////////////////////////////////////////////////////////////////
                    // Process IAPI intents via botkit framework
                    ////////////////////////////////////////////////////////////////////////////////////
                    var url = 'http://127.0.0.1:' + confObj.bot_port + '/botkit/cancel'
                    var user_id = intentData.conversation_id;
                    logger.debug(LOGTAG + "Posting cancel request to url[%s] ",url)
                    var config =  { headers: {'Content-Type': 'application/json' }}
                    axios.post(url, {
                        "text": null,
                        "user": user_id,
                        "channel": "webhook",
                        "extra": ""
                    }, config)
                        .then(function (response) {
                            logger.debug(LOGTAG + "received response => %j", response.data);
                            logger.debug(LOGTAG + "Conversation cancelled - Returning to IAPI => HTTP 200");
                            debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers,{})
                            return res.status(200).send({});
                        })
                        .catch(function (error) {
                            console.log(error);
                            debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers,{})
                            return res.status(200).send({});
                        });

                } else {
                    ////////////////////////////////////////////////////////////////////////////////////
                    // Process IAPI intents via (default) bespoke framework - i.e. no external framework
                    ////////////////////////////////////////////////////////////////////////////////////
                    //get worker
                    logger.debug(LOGTAG + `Processing request using framework => [%s]`, framework);
                    var w = botregistry_workers[threadid]
                    var msg={threadid: threadid, status:'IAPI_REQUEST', intentData: intentData, responseObj: responseObj};
                    w.on('message', (msg) => {
                        //return
                        logger.debug(LOGTAG + "Returning to IAPI => HTTP 200");
                        debug_kaifromresp('RESPONSE HEADERS %o\nRESPONSE BODY\n%O', res.headers, {})
                        res.status(200).send({});

                    });
                    w.postMessage(msg)
                }


            } else {
                throw ({ code: 500, message: 'Unsupported Intent' });
            }
        })

  } catch (err) {
        errorHandling(res, err);
    }

};

