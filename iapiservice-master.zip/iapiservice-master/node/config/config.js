var debug = require('debug')('iapi:config')
const path = require('path')
const env = process.env.NODE_ENV || 'dev'; // 'dev','test','stage','prod'
const iapi_service_home = process.env.IAPI_SERVICE_HOME || path.join(__dirname, "../..")
const iapi_test_home = process.env.IAPI_TEST_HOME || path.join(__dirname, "../..")
const load_definitions = process.env.LOAD_DEFINITIONS || true

const dev = {

    kai: {
        hostname: {
            default: "localhost",
            args: "iapi-kai-hostname",
            env: "IAPI_KAI_HOSTNAME"
        },
        port: {
            default: 8090,
            args: "iapi-kai-port",
            env: "IAPI_KAI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-kai-protocol",
            env: "IAPI_KAI_PROTOCOL"
        }
    },
    iapi: {
        hostname: {
            default: "localhost",
            args: "iapi-hostname",
            env: "IAPI_HOSTNAME"
        },
        port: {
            default: 8290,
            args: "iapi-port",
            env: "IAPI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-protocol",
            env: "IAPI_PROTOCOL"
        },
        secret: {
            default: "ef576554-637f-11e8-adc0-fa7ae01bbebc",
            args: "iapi-secret",
            env: "IAPI_SECRET"
        },
        token: {
            default: "",
            args: "iapi-token",
            env: "IAPI_TOKEN"
        }
    },
    botium: {
        capabilities: {
            simplerest_headers_template: {
                default: "{\"secret\": \"ef576554-637f-11e8-adc0-fa7ae01bbebc\", \"kai\":\"http://localhost:8090\", \"Content-Type\": \"application/json;charset=UTF-8\"}",
                args: "botium-simplerest-headers-template",
                env: "BOTIUM_SIMPLEREST_HEADERS_TEMPLATE"
            }
        }
    },
    botium_convo_path: {
        default: `${iapi_test_home}/botium/spec/convo_dev`,
        args: "botium_convo_path",
        env: "BOTIUM_CONVO_PATH"
    },
    sessionstore:{
        default: {adapter: 'memory'}

    },

    iapi_service_home:{
        default: `${iapi_service_home}`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    iapi_service_node_home:{
        default: `${iapi_service_home}/node`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    bot_framework_path:{
        default: `${iapi_service_home}/node/dialog/framework`,
        args: "bot_framework_path",
        env: "BOT_FRAMEWORK_PATH"
    },

}

const test = {
    kai: {
        hostname: {
            default: "kai",
            args: "iapi-kai-hostname",
            env: "IAPI_KAI_HOSTNAME"
        },
        port: {
            default: 8090,
            args: "iapi-kai-port",
            env: "IAPI_KAI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-kai-protocol",
            env: "IAPI_KAI_PROTOCOL"
        }
    },
    iapi: {
        hostname: {
            default: "iapiservice-node",
            args: "iapi-hostname",
            env: "IAPI_HOSTNAME"
        },
        port: {
            default: 8290,
            args: "iapi-port",
            env: "IAPI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-protocol",
            env: "IAPI_PROTOCOL"
        },
        secret: {
            default: "ef576554-637f-11e8-adc0-fa7ae01bbebc",
            args: "iapi-secret",
            env: "IAPI_SECRET"
        },
        token: {
            default: "",
            args: "iapi-token",
            env: "IAPI_TOKEN"
        }
    },
    botium_convo_path: {
        default: `${iapi_test_home}/botium/spec/convo`,
        args: "botium_convo_path",
        env: "BOTIUM_CONVO_PATH"
    },
    sessionstore:{
        default: {adapter: 'redis', options: {host: 'redis', port: 6379}}

    },
    iapi_service_home:{
        default: `${iapi_service_home}`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    iapi_service_node_home:{
        default: `${iapi_service_home}/node`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    bot_framework_path:{
        default: `${iapi_service_home}/node/dialog/framework`,
        args: "bot_framework_path",
        env: "BOT_FRAMEWORK_PATH"
    },



}

const ci = {
    kai: {
        hostname: {
            default: "kai",
            args: "iapi-kai-hostname",
            env: "IAPI_KAI_HOSTNAME"
        },
        port: {
            default: 8090,
            args: "iapi-kai-port",
            env: "IAPI_KAI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-kai-protocol",
            env: "IAPI_KAI_PROTOCOL"
        }
    },
    iapi: {
        hostname: {
            default: "iapiservice-node",
            args: "iapi-hostname",
            env: "IAPI_HOSTNAME"
        },
        port: {
            default: 8290,
            args: "iapi-port",
            env: "IAPI_PORT"
        },
        protocol: {
            default: "http",
            format: ["https", "http"],
            args: "iapi-protocol",
            env: "IAPI_PROTOCOL"
        },
        secret: {
            default: "ef576554-637f-11e8-adc0-fa7ae01bbebc",
            args: "iapi-secret",
            env: "IAPI_SECRET"
        },
        token: {
            default: "",
            args: "iapi-token",
            env: "IAPI_TOKEN"
        }
    },
    botium_convo_path: {
        default: `${iapi_test_home}/botium/spec/convo`,
        args: "botium_convo_path",
        env: "BOTIUM_CONVO_PATH"
    },
    sessionstore:{
	    default: {adapter: 'memory'}
    },


    iapi_service_home:{
        default: `${iapi_service_home}`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    iapi_service_node_home:{
        default: `${iapi_service_home}/node`,
        args: "iapi_service_home",
        env: "IAPI_SERVICE_HOME"
    },

    bot_framework_path:{
        default: `${iapi_service_home}/dialog/framework`,
        args: "bot_framework_path",
        env: "BOT_FRAMEWORK_PATH"
    },

}


const configs = {
    dev,
    test,
    ci

};
var convict = require('convict');
var config = convict(configs[env])
debug("config loaded")
//Add general properties
config.load({
    "intent_definitions_path": `${iapi_service_home}/intent_definitions`,
    "enterprise_api_url":"http://mock-enterprise-api.kitsys.net:9001/api",
    "enterprise_api_secret":"74573e7e-7e24-4b25-a42d-3dabaa4db2d0",
    "botkitframework_bot_listener_server_base_port":5500,
    "load_definitions": load_definitions
});

module.exports = config;



