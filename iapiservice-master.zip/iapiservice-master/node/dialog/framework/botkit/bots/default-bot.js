//Kasisto Intent API Bot Reference Design
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CONFIGURATION
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
var debug = require('debug')('iapi:default-bot')
const FRAMEWORK_BOTKIT = "FRAMEWORK_BOTKIT";
const BOTCONF = {
	ACTIVE: true,
	ID: 4,
	NAME: 'Default Kai Bot',
	DESC: 'Default Kai Bot - uses botkit framework',
	IAPI_INTENT: 'kai_(.*)', //Intent is defined as a RegExp
	FRAMEWORK: FRAMEWORK_BOTKIT,
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
const utils = require('../../../../lib/kai-utils');
const {  parentPort } = require('worker_threads');
const path = require('path')
const bodyParser = require('body-parser');
const ENV_FILE = path.join(__dirname, '../../../../config/.env');
require('dotenv').config({ path: ENV_FILE });
var scriptName = path.basename(__filename);
const logger = require('../../../../lib/logger');
var config = require('../../../../config/config');

const morgan = require('morgan');
const express = require('express');
const app = express();
app.use(bodyParser({limit: '50mb'}));
app.use(bodyParser.urlencoded({ extended: true }))
//app.use(morgan('common', {}));

var debug_fromiapitobot = require('debug')('iapi:default-bot:receive')
var debug_frombottoiapi = require('debug')('iapi:default-bot:send')

var LOGTAG = `BOT=>[${scriptName}][id=${BOTCONF.ID}][name=${BOTCONF.NAME}][desc=${BOTCONF.DESC}][intent=${BOTCONF.IAPI_INTENT}]`

///////////////////////////////////////////////////////////////////////////////////////////////
// Setup Thread Handler for Framework
///////////////////////////////////////////////////////////////////////////////////////////////
//you can receive messages from the main thread this way:
const botkit_server_port = parseInt(config.get('botkitframework_bot_listener_server_base_port')) + parseInt(BOTCONF.ID)
var Botkit = require('botkit');


//////////////////////////////////////////////////////////////////////////////
// Create the Botkit controller, which controls all instances of the bot.
//////////////////////////////////////////////////////////////////////////////

var controller = Botkit.anywhere({
    debug: false,
});


parentPort.on('message', (msg) => {
	logger.debug('%sThread received msg from parent: %j', LOGTAG, msg)
	if (BOTCONF.ACTIVE == false){
		var respmsg = { botstatus: 'NOT_ACTIVE', workerthreadid: msg.threadid, botresp: {user_inputs: {}}, botframework: BOTCONF.FRAMEWORK, botport: null, botid: BOTCONF.ID, botname:BOTCONF, botdesc:BOTCONF.DESC, botintent: BOTCONF.IAPI_INTENT};
		logger.debug('%sThread response msg to parent: %j', LOGTAG, respmsg)
		parentPort.postMessage(respmsg);
	}

	if (msg.status == 'START' && BOTCONF.ACTIVE == true){
		logger.debug('%sThread received msg from parent: %j', LOGTAG, msg.status)
		const threadid = msg.threadid;
		LOGTAG = `${LOGTAG}[threadid=${threadid}]`;

		//////////////////////////////////////////////////////////////////////////////////////////////////////
		// BOTKIT FRAMEWORK ='FRAMEWORK_BOTKIT' - Setup Botkit Handler
		/////////////////////////////////////////////////////////////////////////////////////////////////////
        controller.startTicking();
        var respmsg = { botstatus: 'STARTED', workerthreadid: threadid, botresp: {user_inputs: {}}, botframework: BOTCONF.FRAMEWORK,  botport: botkit_server_port, botid: BOTCONF.ID, botname:BOTCONF, botdesc:BOTCONF.DESC, botintent: BOTCONF.IAPI_INTENT};
		logger.debug('%sThread response msg to parent: %j', LOGTAG, respmsg)
		parentPort.postMessage(respmsg);

	} else if (msg.status == 'ACK_STARTED' && BOTCONF.ACTIVE == true){
		var respmsg = { botstatus: 'RUNNING', workerthreadid: threadid, botresp: {user_inputs: {}}, botframework: BOTCONF.FRAMEWORK, botport: botkit_server_port,  botid: BOTCONF.ID, botname:BOTCONF, botdesc:BOTCONF.DESC, botintent: BOTCONF.IAPI_INTENT};
		logger.debug('%sThread response msg to parent: %j', LOGTAG, respmsg)
		parentPort.postMessage(respmsg);

	} else if (msg.status == 'STOP' && BOTCONF.ACTIVE == true){
		//stop services


	} else{
		//ignore
	}


});




app.listen(botkit_server_port, function (req, resp) {
    logger.debug(`${LOGTAG}` + `Botkit Webhook listening on http://0.0.0.0:${botkit_server_port}/botkit/receive`);
});


var bot;

// Listen for incoming requests.
app.post('/botkit/receive', (req, res) => {
    logger.debug(`${LOGTAG}` + `Received request [%j]`,req.body);
    // respond to the webhook has been received.
    controller.handleWebhookPayload(req, res, bot);
});


// Listen for incoming requests.
app.post('/botkit/cancel', (req, res) => {
    logger.debug(`${LOGTAG}` + `Received cancel request [%j]`,req.body);
    let tasks = controller.tasks
    for (let task of tasks) {
        for (let convo of task.convos) {
            //Cancel active user conversations.  Note that the context data will persists
            if (convo.isActive() && convo.source_message.user == req.body.user) {
                convo.stop();
            }
        }
    }
    // respond to the webhook has been received.
    res.status(200);
    res.send('ok');
});

///////////////////////////////////////////////////////////////////////////////////////////////
// Load Skills Library
///////////////////////////////////////////////////////////////////////////////////////////////
var normalizedPath = require("path").join(__dirname, "/skills");
require("fs").readdirSync(normalizedPath).forEach(function (file) {
    try {
        require("./skills/" + file)(controller, bot);
        logger.debug('%sLoaded skill [%s]', LOGTAG, file)

    }
    catch (err) {
        console.log(err);
        if (err.code == "MODULE_NOT_FOUND") {
            if (file != "utils") {
                console.log("could not load skill: " + file);
            }
        }
    }
});


///////////////////////////////////////////////////////////////////////////////////////////////
// Custom Dialog
///////////////////////////////////////////////////////////////////////////////////////////////
//override controller middleware if required
/*
RECEIVING MIDDLEWARE
*/
controller.middleware.receive.use(function(bot, message, next) {
    debug_fromiapitobot("%o\n", message)
    //save dialog (from iapi message) so that it is availailable to all bots - using transient storage (bot-storage)
    var user_data = message.extra.dialog
    utils.saveStoreData (controller, user_data, function(err) {
        if (err) throw err
        // call next to proceed, now with additional info!
        //debug_fromiapitobot('MESSAGE_TEXT %o\nMESSAGE %O', message.text, message)
        logger.debug(`${LOGTAG}` + `Botkit receiving from IAPI ${message}`,);
        debug_fromiapitobot("%O\nCache Saved", user_data)
        //deconstruct dialog from message.extra before passing to controller
        message.extra.dialog = {}
        next();
    })

})


/*
SENDING MIDDLEWARE
 */
controller.middleware.send.use(function(bot, message, next) {
    debug("%o\nsend_orig->", message)
    var message_cpy = message
    //retrieve dialog context and return to app so it can be saved using-iapi storage (persistant storage)
    utils.getStoreData(controller, message_cpy, function(err, data) {
        if (err) throw err
        debug_frombottoiapi("%O\niapi Cache Retrieved", data)
        logger.debug(`${LOGTAG}` + `Botkit sending to IAPI ${message.text}`,);
        //update message (to iapi)
        //reconstruct dialog store to pass to iapi to store
        message.extra = {}
        message.extra.dialog ={}
        message.extra.dialog.id = message_cpy.user
        message.extra.dialog.store = data
        debug_frombottoiapi("%o\n", message)
        // call next to proceed, now with additional info!
        next();
    })

});



// default message
controller.hears(('.*'), 'message_received', function(bot, message) {
    bot.reply(message, utils.createIAPIResponse(`***Sorry. I don't understand. You said: ${message.text} but i don't know how to handle that yet!`));

});
