module.exports = function (controller) {
    var debug = require('debug')('iapi:skill:baseline_form')
    const kaiutils = require('../../../../../lib/kai-utils');
    const util = require('util') //logging util
    const logger = require('../../../../../lib/logger');

    //create alias shortcut
    function kairesp(message, options) {
        return kaiutils.createIAPIResponse(message, options)
    }
    //create alias shortcut
    function kairespFromFormattedResponse(respmsg, options) {
        return kaiutils.createIAPIResponseFromKaiFormattedRespMsg(respmsg, options)
    }

    /**
     *
     * This is an intent to go through each of the types in a linear fashion.
     *
     * It is based on the java version.
     *
     * See BaselineHelper.java to see the corresponding java inputs to collect
     *
     * userInputs.add(new RequestUserInput(PARAM_BOOL, RequestUserInput.BOOLEAN_TYPE));
     userInputs.add(new RequestUserInput(PARAM_NUM, RequestUserInput.NUMBER_TYPE));
     userInputs.add(new RequestUserInput(PARAM_DATETIME, RequestUserInput.DATETIME_TYPE));
     userInputs.add(new RequestUserInput(PARAM_PATTERN, RequestUserInput.PATTERN_TYPE, "\\d\\d\\d-\\d\\d\\d"));
     userInputs.add(new RequestUserInput(PARAM_CURRENCY, RequestUserInput.CURRENCY_TYPE));
     userInputs.add(new RequestUserInput(PARAM_EMAIL, RequestUserInput.EMAIL_TYPE));
     userInputs.add(new RequestUserInput(PARAM_STRING, RequestUserInput.STRING_TYPE));
     
     Note, at each step if the user provides the wrong type, kai should validate and tell them to re-enter.
     At the end the form should be marked completed.

     */
    controller.hears('baseline_form', 'message_received', function (bot, message) {
        bot.startConversation(message, function (err, convo) {

            //save some adhoc user context
            var ts = Math.round((new Date()).getTime()) +"" //milliseconds from UNIX epoch
            kaiutils.saveUserDefinedData (controller, message, 'ts', ts, function(err){})

            convo.ask(kairesp('What is your boolean?', {complete: false, user_input_type: kaiutils.USER_INPUT_TYPES.boolean, user_input_name: "my_boolean"}), function (res, convo) {
                convo.next()

                //how do specify that input must be a date
                convo.ask(kairesp('What is your number?', {complete: false, user_input_type: kaiutils.USER_INPUT_TYPES.number, user_input_name: "my_number"}), function (res, convo) {
                    convo.next()

                    //how do specify that input must be number
                    convo.ask(kairesp('What is your datetime?', {user_input_type: kaiutils.USER_INPUT_TYPES.date, user_input_name: "my_datetime"}), function (res, convo) { //defaults to complete:false
                        convo.next()

                        //how do specify that input must be number
                        //convo.ask(kairesp('What is your pattern?', {user_input_type: kaiutils.USER_INPUT_TYPES.pattern}), function (res, convo) {
                        convo.ask(kairesp('What is your pattern?', {user_input_type: kaiutils.USER_INPUT_TYPES.string, user_input_name: "my_pattern"}), function (res, convo) {
                            convo.next()

                            //how do specify that input must be number
                            convo.ask(kairesp('What is your currency?', {user_input_type: kaiutils.USER_INPUT_TYPES.currency_amount, user_input_name: "my_currency"}), function (res, convo) {
                                convo.next()


                                convo.ask(kairesp('What is your email?', {user_input_type: kaiutils.USER_INPUT_TYPES.email, user_input_name: "my_email"}), function (res, convo) {
                                    convo.next()

                                    convo.ask(kairesp("what is your string?", {user_input_type: kaiutils.USER_INPUT_TYPES.string, user_input_name: "my_string"}), function (res, convo) {
                                        var context_saved = {}
                                        //get saved context
                                        kaiutils.getAutoSavedDataByKey(controller, message, 'my_boolean', function(err, value){
                                            context_saved.card1_value = value
                                        })

                                        kaiutils.getAutoSavedDataByKey(controller, message, 'my_datetime', function(err, value){
                                            context_saved.card2_value = value
                                        })

                                        kaiutils.getAutoSavedDataByKey(controller, message, 'my_pattern', function(err, value){
                                            context_saved.card3_value = value
                                        })

                                        kaiutils.getAutoSavedDataByKey(controller, message, 'my_currency', function(err, value){
                                            context_saved.card4_value = value
                                        })

                                        kaiutils.getAutoSavedDataByKey(controller, message, 'my_email', function(err, value){
                                            context_saved.card5_value = value
                                        })

                                        kaiutils.getUserDefinedData(controller, message, 'ts', function(err, value){
                                            context_saved.card6_value = value
                                        })

                                        console.log(util.inspect(context_saved, false, null, true /* enable colors */))


                                        var cardArr = [];
                                        cardArr.push(kaiutils.createCard('Card 1', context_saved.card1_value ))
                                        cardArr.push(kaiutils.createCard('Card 2', context_saved.card2_value ))
                                        cardArr.push(kaiutils.createCard('Card 3', context_saved.card3_value ))
                                        cardArr.push(kaiutils.createCard('Card 4', context_saved.card4_value ))
                                        cardArr.push(kaiutils.createCard('Card 5', context_saved.card5_value ))
                                        cardArr.push(kaiutils.createCard('Card 6', context_saved.card6_value ))


                                        //console.log(util.inspect(cardArr, false, null, true /* enable colors */))
                                        convo.say(kairespFromFormattedResponse(kaiutils.createCarousel("OK.  Here's a summary of your inputs.", cardArr),{complete: true}));
                                        convo.next()
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    })
}


