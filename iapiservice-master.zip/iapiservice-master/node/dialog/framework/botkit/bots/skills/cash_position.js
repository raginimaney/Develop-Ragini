module.exports = function(controller) {
    var debug = require('debug')('iapi:bot:cash_position')
    const kaiutils = require('../../../../../lib/kai-utils');
    const logger = require('../../../../../lib/logger');
    const uuidv4 = require('uuid/v4');
    const path = require('path');
    const axios = require("axios");
    var config = require('../../../../../config/config.js');
    var scriptName = path.basename(__filename);
    var LOGTAG = '';
    var eapiObjGlobal = {};

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// DIALOG References
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ;

    const REF_QUICK_REPLY_TEMPLATES = {
        qr_by_currency: {pivotkey: 'fcy_currency_code', sortkey: 'available_balance', quick_reply_label_template: "{0} - [#{1} - ${2}]", quick_reply_label_template_vals: ["fcy_currency_code", "account_number", "available_balance"], max_number_replies: 8, reverse: true},
        qr_by_bankname: {pivotkey: 'meta_bank_name', sortkey: 'available_balance', quick_reply_label_template: "#[{0}] - [{1}]", quick_reply_label_template_vals: ["account_id","meta_bank_name"], max_number_replies: 8, reverse: true},

    }

    //create alias shortcut
    function kairesp(message, options) {
        return kaiutils.createIAPIResponse(message, options)
    }
    //create alias shortcut
    function kairespFromFormattedResponse(respmsg, options) {
        return kaiutils.createIAPIResponseFromKaiFormattedRespMsg(respmsg, options)
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// CONVERSATIONAL DIALOG
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    controller.hears('cash_position', 'message_received', function (bot, message) {
        debug(message)
        LOGTAG = `[SKILL=>${scriptName}][hears=${message.match}][intent_name=${message.extra.intent_name}][conversation_id=${message.extra.conversation_id}][user_id=${message.extra.user_id}][token=${message.extra.token}] `;
        logger.debug("%s received message %j", LOGTAG, message);
        //retrieve account
        var eapiObjAll = {};
        var eapiObjArray =[];
        bot.createConversation(message, function (err, convo) {
            convo.addMessage(kairesp("***goodbye"), 'goodbye_message')
            convo.addMessage(kairesp("***Apologies an error occurred handling your question. Please login and try again"), 'error_message')
            convo.addMessage(kairesp("***Apologies an error occurred handling your question. Your request returned account information however I cannot see any Cash Position Summary accounts.  Please login and try again"), 'error_message_no_cash_position_summary')
            var getaccounts = kaiutils.getAccounts(config.get('enterprise_api_secret'), config.get('enterprise_api_url'),message.extra.token, message.user);
            getaccounts.then(function(result) {
                //console.log(result)
                eapiObjAll = result.accountObjects;
                eapiObjArray = result.accountArray;

                for(var key in eapiObjAll){
                    eapiObjGlobal[key] = eapiObjAll[key];
                }



                //check validity
                var tmpFilteredArray = kaiutils.getFilteredArray(eapiObjArray, 'account_type', 'cash_position_summary');
                if(typeof tmpFilteredArray == "undefined" || tmpFilteredArray.length ==0) {
                    convo.gotoThread('error_message_no_cash_position_summary')
                    convo.next();
                } //otherwise continue
                if (message.extra.user_inputs[0] == undefined) {
                    /////////////////////////////////////////////////////////////////////
                    ///// DEFAULT CONVERSATION (what is my cash position)
                    /////////////////////////////////////////////////////////////////////
                    var eapiObjResultFilteredArray = kaiutils.getFilteredArray(eapiObjArray, 'account_type', 'cash_position_summary');
                    logger.debug("%s triggered conversation [%s]", LOGTAG, 'default')
                    convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(kaiutils.randomPrompt(["Lets see.", "OK.", "OK let me see."]) + " What is the Base currency?", getQuickReplyOptions(eapiObjResultFilteredArray, eapiObjAll, REF_QUICK_REPLY_TEMPLATES.qr_by_currency)),{complete: false}));
                    //console.log(convo.vars);
                    convo.addQuestion('{{vars.dynamic_out}}', function (response, convo) { //response.text is the account id
                        var account = getAccount(eapiObjGlobal, response.text);
                        var currency = account.fcy_currency_code;
                        var parsed = parseAccountDataById(eapiObjAll, response.text)
                        convo.setVar('dynamic_out', kairespFromFormattedResponse(getDefaultCarousel(parsed, currency), {complete: false}));
                        logger.debug("%s conversation addQuestion [%s] for question thread id [%s]", LOGTAG, convo.vars.dynamic_out, 'default')
                        convo.say('{{vars.dynamic_out}}');
                        convo.next();
                    }, {}, 'default')
                } else {
                    var eapiObjResultFilteredArray = kaiutils.getFilteredArray(eapiObjArray, 'account_type', 'cash_position_summary');
                    logger.debug("%s triggered conversation with [%j]", LOGTAG, message.extra.user_inputs)
                    logger.debug("%s triggered conversation with slot name [%j] value %j", LOGTAG, message.extra.user_inputs[0].name, message.extra.user_inputs[0].value)
                    var out = {};
                    out.input_param = message.extra.user_inputs[0].value;
                    out.input_cat = message.extra.user_inputs[0].name;
                    if (out.input_cat == "CP_period") {
                        /////////////////////////////////////////////////////////////////////
                        ///// CP_period (what is my cash position for yesterday)
                        /////////////////////////////////////////////////////////////////////
                        //choose currency first
                        convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(kaiutils.randomPrompt(["Lets see.", "OK.", "OK let me see."]) + " What is the Base currency?", getQuickReplyOptions(eapiObjResultFilteredArray, eapiObjAll, REF_QUICK_REPLY_TEMPLATES.qr_by_currency)),{complete: false}));
                        convo.addQuestion('{{vars.dynamic_out}}', function (response, convo) { //response.text is the account id
                            logger.debug("%s Get Currency => response text [%j] ", LOGTAG, response.text)
                            var parsed = parseAccountDataByCurrency(eapiObjAll, response.text);
                            out.parsed = parsed;
                            out.input_param = 'current';
                            convo.setVar('out', out);
                            //console.log(convo.vars)
                            convo.gotoThread('loop-controller')
                            convo.next();
                        }, {}, 'default');



                    } else if (out.input_cat == "CP_balancetype") {
                        //todo


                    } else if (out.input_cat == "CP_bankname") {
                        /////////////////////////////////////////////////////////////////////
                        ///// CP_bankname (What's the balance for my JPMorgan account)
                        /////////////////////////////////////////////////////////////////////
                        //console.log(eapiObjArray)
                        var eapiObjResultFilteredArray = kaiutils.getFilteredArray(eapiObjArray, 'meta_bank_name_normalized', kaiutils.normalizeBankName(out.input_param));
                        var id_array = findAccountsByProperty(eapiObjResultFilteredArray, 'meta_bank_name_normalized', 'meta_balances_currentday_openingavailable', true);
                        if (id_array.length == 1) {
                            logger.debug("%s Get Bank => id [%j] ", LOGTAG, id_array[0].key)
                            var parsed = parseAccountDataByBank(eapiObjAll, id_array[0].key);
                            out.parsed = parsed;
                            convo.setVar('out', out);
                            console.log(convo.vars)
                            convo.say('***' + '{{vars.dynamic_out}}');
                            convo.next();
                        } else if (id_array.length > 1){
                            convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(kaiutils.randomPrompt(["Lets see.", "OK.", "OK let me see."]) + " Which Bank?", getQuickReplyOptions(eapiObjResultFilteredArray, eapiObjAll, REF_QUICK_REPLY_TEMPLATES.qr_by_bankname),{complete: false})));
                            convo.addQuestion('{{vars.dynamic_out}}', function (response, convo) { //response.text is a bank name
                                logger.debug("%s Get Bank => response text [%j] ", LOGTAG, response.text)
                                var parsed = parseAccountDataByBank(eapiObjAll, response.text);
                                out.parsed = parsed;
                                out.input_param = 'current';
                                convo.setVar('out', out);
                                convo.gotoThread('loop-controller')
                                convo.next();
                            }, {}, 'default');
                        } else {
                            convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(kaiutils.randomPrompt(["Lets see.", "OK.", "OK let me see."]) + " I don't know see any accounts with that bank name. Can you please tell me another name?", getQuickReplyOptions(eapiObjResultFilteredArray, eapiObjAll, REF_QUICK_REPLY_TEMPLATES.qr_by_bankname),{complete: false})));
                            convo.addQuestion('{{vars.dynamic_out}}', function (response, convo) { //response.text is a bank name
                                var id_array = findAccountsByProperty(eapiObjResultFilteredArray, 'meta_bank_name_normalized', 'meta_balances_currentday_openingavailable', true);
                                logger.debug("%s Get Bank => response text [%j] ", LOGTAG, response.text);
                                if (id_array.length == 1) {
                                    logger.debug("%s Get Bank => id [%j] ", LOGTAG, id_array[0].key)
                                    var parsed = parseAccountDataByBank(eapiObjAll, id_array[0].key);
                                    out.parsed = parsed;
                                    out.input_param = 'current';
                                } else {
                                    out.input_param = "unknown";
                                    out.parsed={};
                                    out.parsed.prompt={};
                                    out.parsed.prompt[out.input_param] = {
                                        text: `Sorry. I don't know see any accounts for (${response.text}).  Let's start over`,
                                        options: [{
                                            label: "Start Over",
                                            value: "startover"
                                        }],
                                        complete: true
                                    };

                                }
                                convo.setVar('out', out);
                                //console.log(convo.vars)
                                convo.gotoThread('loop-controller');
                                convo.next();
                            }, {}, 'default');
                        }
                    } else if (out.input_cat == "CP_currency") {
                        //todo
                    } else if (out.input_cat == "CP_accountnum") {
                        var eapiObjResultFilteredArray = kaiutils.getFilteredArray(eapiObjArray, 'account_number', message.extra.user_inputs[0].value);
                        console.log(eapiObjResultFilteredArray)
                        var id_array = findAccountsByProperty(eapiObjResultFilteredArray, 'account_number', 'account_number', true);
                        if (id_array.length == 1) {
                            logger.debug("%s Get Account => id [%j] ", LOGTAG, id_array[0].key)
                            var parsed = parseAccountDataByCurrency(eapiObjAll, id_array[0].key);
                            out.parsed = parsed;
                            var prompt_value = out.parsed.prompt['current'].text;
                            var prompt_options = out.parsed.prompt['current'].options;
                            var prompt_complete = out.parsed.prompt['current'].complete_flag || false;
                            convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(prompt_value, prompt_options),{complete: prompt_complete}));
                            convo.addQuestion('{{vars.dynamic_out}}', function (response, convo) { //response.text is the account type
                                logger.debug("%s Get Currency => response text [%j] ", LOGTAG, response.text)
                                var parsed = parseAccountDataByCurrency(eapiObjAll, id_array[0].key);
                                out.parsed = parsed;
                                out.input_param = 'current';
                                convo.setVar('out', out);
                                convo.gotoThread('loop-controller')
                                convo.next();
                            }, {}, 'default');
                        } else {
                            convo.setVar('dynamic_out', kairespFromFormattedResponse(`Sorry, I don't see that account (#${out.input_param}). Let's start over!`,{complete: true}));
                            convo.say('{{vars.dynamic_out}}');
                            convo.next();

                        }

                    } else {
                        //todo
                    }
                } //end default thread


                convo.beforeThread('loop-controller', function(convo, next) {
                    var out = convo.vars.out;
                    //console.log(out.parsed.prompt);
                    var key = out.input_param;
                    var prompt_value = out.parsed.prompt[key].text;
                    var prompt_options = out.parsed.prompt[key].options;
                    var prompt_complete = out.parsed.prompt[key].complete_flag || false;
                    convo.setVar('dynamic_out', kairespFromFormattedResponse(kaiutils.createQuickReplies(prompt_value, prompt_options),{complete: prompt_complete}));
                    next();

                });
                convo.addQuestion('{{vars.dynamic_out}}', function(response, convo) {
                    convo.vars.out.input_param = response.text
                    logger.debug("%s LOOP-CONTROLLER => response text [%j] ", LOGTAG, response.text)
                    convo.gotoThread('loop-controller')
                }, {}, 'loop-controller')


                }, function(err) {
                    convo.gotoThread('error_message')
            });


            logger.debug("%s conversation activated", LOGTAG)
            convo.activate();

        });//end create conversation

    }); //end contoller.hears



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// HELPER FUNCTIONS
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////





    function getAccount(eapiObj, id){
        //console.log(id);
        var account = eapiObjGlobal[id]
        //console.log(account);
        return account;

    }

    function getQuickReplyOptions(dataObjArray, allObj, template) {
        var tmp = [];
        const maxnumberreplies = template.max_number_replies;
        var id, pivotval, sortval;
        dataObjArray.forEach(function (obj) {
            //use key and value here
            id = obj['account_id'];
            pivotval = obj[template.pivotkey];
            sortval= obj[template.sortkey];
            if (pivotval && pivotval != undefined ) {
                tmp.push({key: id, pivotkey: template.pivotkey, pivotval: pivotval, sortkey: template.sortkey, sortval: sortval});
            }
        });

        //sort array
        var arraySort = require('array-sort');
        arraySort(tmp, 'sortval', {reverse: template.reverse});

        //create quick replies options
        var l = tmp.length;
        var max_opt_length = l;
        if (l > maxnumberreplies) {
            max_opt_length = 8;
        }

        let options=[];
        var format = require("string-template")
        for(var i = 0; i < max_opt_length;i++){
            //add quick reply options
            var account_id = tmp[i].key;
            var accountdata = allObj[account_id];
            var template_length = template.quick_reply_label_template_vals.length
            var template_vals = []
            for(var x = 0; x < template_length;x++){
                var tmp_template_val = template.quick_reply_label_template_vals[x];
                template_vals.push(accountdata[tmp_template_val])
            }
            var label=format(template.quick_reply_label_template, template_vals);
            options.push( {value : account_id, label: label});
        }
        console.log(options);
        return options;
    }


    function getQuickReplyOptions_BalanceTypes(exclude) {
        const qr_option_cancel = {value : 'startover', label: 'Something Else'};
        const qr_option_balancetype_current = {value : 'current', label: 'Current Day Balances'};
        const qr_option_balancetype_projected1 = {value : 'projected1', label: 'Predicted 1 Day Balances'};
        const qr_option_balancetype_projected2 = {value : 'projected2', label: 'Predicted 2 Day Balances'};
        const qr_option_balancetype_prior = {value : 'prior', label: 'Prior Day Balances'};
        const qr_option_balancetype_credit = {value : 'credit', label: 'Credits'};
        const qr_option_balancetype_debit = {value : 'debit', label: 'Debits'};

        let tmp = [qr_option_cancel, qr_option_balancetype_current, qr_option_balancetype_projected1, qr_option_balancetype_projected2, qr_option_balancetype_prior, qr_option_balancetype_credit, qr_option_balancetype_debit];
        let options =[];

        tmp.forEach(function (obj) { //iterate through meta
            if (obj.value == exclude){
                //skip
            } else {
                options.push(obj)
            }
        });
        return options;
    }

    function getDefaultCarousel(parsed){
        var cardArr = [];
        //console.log(parsed)
        cardArr.push(kaiutils.createCard('Current Day Balances', parsed.prompt.current.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_current.png`));
        cardArr.push(kaiutils.createCard('Prior Day Balances', parsed.prompt.prior.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_prior.png`));
        cardArr.push(kaiutils.createCard('1 Day Projected', parsed.prompt.projected1.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_projected1.png`));
        cardArr.push(kaiutils.createCard('2 Day Projected', parsed.prompt.projected2.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_projected2.png`));
        cardArr.push(kaiutils.createCard('Credits', parsed.prompt.credit.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_credits.png`));
        cardArr.push(kaiutils.createCard('Debits', parsed.prompt.debit.text, `${config.get('iapi.protocol')}://${config.get('iapi.hostname')}:${config.get('iapi.port')}/public/images/kasisto/calendar_debits.png`));
        return kaiutils.createCarousel("OK.  Here's a summary.", cardArr);
    }

   function parseAccountDataById(eapiObj, id) {
        var obj = getAccount(eapiObj, id)
        var parsed = {};
       parsed.account = obj;
       parsed.prompt={};
       parsed.prompt.current = {
           text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have:\n $${obj.meta_balances_currentday_openingledger} ${obj.fcy_currency_code.toUpperCase()} in Opening Ledger Balance.\n $${obj.meta_balances_currentday_currentorclosingledger} ${obj.fcy_currency_code.toUpperCase()} in Current Ledger Balance.\n $${obj.meta_balances_currentday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Current Available Balance.\n`,
           options: getQuickReplyOptions_BalanceTypes('current')
       };
       parsed.prompt.prior = {
           text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have:\n $${obj.meta_balances_priorday_openingledger } ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Available Balance.\n$${obj.meta_balances_priorday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Ledger Balance. \n`,
           options: getQuickReplyOptions_BalanceTypes('prior')
       };
       parsed.prompt.projected1 = {
           text:`OK. 1 Day Projected Balance for ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
           options: getQuickReplyOptions_BalanceTypes('projected1')
       };

       parsed.prompt.projected2 = {
           text:`OK. 2+ Day Projected Balance for ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
           options: getQuickReplyOptions_BalanceTypes('projected2')
       };
       parsed.prompt.credit = {
           text:`Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have: total credits of $${obj.meta_balances_currentday_totalcreditsamount }.`,
           options: getQuickReplyOptions_BalanceTypes('credit')
       };
       parsed.prompt.debit = {
           text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have: total debits of $${obj.meta_balances_currentday_totaldebitsamount }`,
           options: getQuickReplyOptions_BalanceTypes('debit')
       };
       return parsed;
   }


    function parseAccountDataByCurrency(eapiObj, id) {
        var obj = getAccount(eapiObj, id)
        var  parsed = {};
        parsed.account = obj;
        parsed.prompt={};
        parsed.prompt.current = {
            text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have:\n $${obj.meta_balances_currentday_openingledger} ${obj.fcy_currency_code.toUpperCase()} in Opening Ledger Balance.\n $${obj.meta_balances_currentday_currentorclosingledger} ${obj.fcy_currency_code.toUpperCase()} in Current Ledger Balance.\n $${obj.meta_balances_currentday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Current Available Balance.\n`,
            options: getQuickReplyOptions_BalanceTypes('current')
        };
        parsed.prompt.prior = {
            text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have:\n $${obj.meta_balances_priorday_openingledger } ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Available Balance.\n$${obj.meta_balances_priorday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Ledger Balance. \n`,
            options: getQuickReplyOptions_BalanceTypes('prior')
        };
        parsed.prompt.projected1 = {
            text:`OK. 1 Day Projected Balance for ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
            options: getQuickReplyOptions_BalanceTypes('projected1')
        };

        parsed.prompt.projected2 = {
            text:`OK. 2+ Day Projected Balance for ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
            options: getQuickReplyOptions_BalanceTypes('projected2')
        };
        parsed.prompt.credit = {
            text:`Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have: total credits of $${obj.meta_balances_currentday_totalcreditsamount }.`,
            options: getQuickReplyOptions_BalanceTypes('credit')
        };
        parsed.prompt.debit = {
            text: `Let's see. In ${obj.fcy_currency_code.toUpperCase()} account [#${obj.account_number}] you have: total debits of $${obj.meta_balances_currentday_totaldebitsamount }`,
            options: getQuickReplyOptions_BalanceTypes('debit')
        };
        return parsed;
    }

    function parseAccountDataByBank(eapiObj, id){
        var obj = getAccount(eapiObj, id)
        var parsed = {};
        parsed.account = obj;
        parsed.prompt={};
        parsed.prompt.current = {
            text: `Let's see. In ${obj.meta_bank_name} account [#${obj.account_number}] you have:\n$${obj.meta_balances_currentday_openingledger} ${obj.fcy_currency_code.toUpperCase()} in Opening Ledger Balance.\n$${obj.meta_balances_currentday_currentorclosingledger} ${obj.fcy_currency_code.toUpperCase()} in Current Ledger Balance.\n $${obj.meta_balances_currentday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Current Available Balance.\n`,
            options: getQuickReplyOptions_BalanceTypes('current')

        };
        parsed.prompt.prior = {
            text: `Let's see. In ${obj.meta_bank_name} account [#${obj.account_number}] you have:\n$${obj.meta_balances_priorday_openingledger } ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Available Balance.\n$${obj.meta_balances_priorday_currentorclosingavailable} ${obj.fcy_currency_code.toUpperCase()} in Prior Day Closing Ledger Balance. \n`,
            options: getQuickReplyOptions_BalanceTypes('prior')
        };
        parsed.prompt.projected1 = {
            text:`OK. 1 Day Projected Balance for ${obj.meta_bank_name} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
            options: getQuickReplyOptions_BalanceTypes('projected1')
        };

        parsed.prompt.projected2 = {
            text:`OK. 2+ Day Projected Balance for ${obj.meta_bank_name} account [#${obj.account_number}] is $${obj.meta_balances_currentday_totalday1floatamount } ${obj.fcy_currency_code.toUpperCase()}.\n`,
            options: getQuickReplyOptions_BalanceTypes('projected2')
        };
        parsed.prompt.credit = {
            text:`Let's see. In ${obj.meta_bank_name} account [#${obj.account_number}] you have: total credits of $${obj.meta_balances_currentday_totalcreditsamount }.`,
            options: getQuickReplyOptions_BalanceTypes('credit')
        };
        parsed.prompt.debit = {
            text: `Let's see. In ${obj.meta_bank_name} account [#${obj.account_number}] you have: total debits of $${obj.meta_balances_currentday_totaldebitsamount }`,
            options: getQuickReplyOptions_BalanceTypes('debit')
        };
        return parsed;
    }

    function findAccountsByProperty(dataArray, pivotkey, sortkey, reverse) {
        var tmp = [];
        var id, pivotval, sortval;
        //console.log(dataArray)
        dataArray.forEach(function (obj) {
            //use key and value here
            id = obj['account_id'];
            pivotval = obj[pivotkey];
            sortval= obj[sortkey];
            if (pivotval && pivotval != undefined ) {
                tmp.push({key: id, pivotkey: pivotkey, pivotval: pivotval, sortkey: sortkey, sortval: sortval});
            }
        });

        //sort array
        var arraySort = require('array-sort');
        arraySort(tmp, 'sortval', {reverse: reverse});

        var matches=[];
        tmp.forEach(function (obj) { //iterate through
            matches.push({key: obj.key});
        });

        return matches;
    }






};




