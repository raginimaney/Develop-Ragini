module.exports = function(controller) {
    const utils = require('../../../../../lib/kai-utils.js');

    // Chaining multiple questions together using callbacks
    // You have to call convo.next() in each callback in order to keep the conversation flowing


    //create alias shortcut
    function kairesp(message, options) {
        return utils.createIAPIResponse(message, options)
    }
    //create alias shortcut
    function kairespFromFormattedResponse(respmsg, options) {
        return utils.createIAPIResponseFromKaiFormattedRespMsg(respmsg, options)
    }

    controller.hears('find_atm_td2', 'message_received', function (bot, message) {
        bot.startConversation(message, function (err, convo) {
            controller.storage.users.get(message.user, function (err, user_data) {
                if (user_data) {
                    controller.storage.users.get(message.zip, function (err, user_data) {
                        if (user_data) {
                            process_td_api(user_data.name, user_data.zip, '1').then(response => {
                                convo.say(`${response}`);
                                convo.next();
                            })
                        } else {
                            convo.ask(kairesp('What is your zip code?'), function (res, convo) {
                                controller.storage.users.get(message.user, function (err, user_data) {
                                    process_td_api(user_data.name, res.text, '1').then(response => {
                                        convo.say(`${response}`);
                                        convo.next();
                                    })
                                })
                            })
                        }
                    });
                } else {
                    convo.ask(kairesp('What is your name?'), function (res, convo) {
                        controller.storage.users.save({id: message.user, name: res.text}, function (err) {
                        });
                        convo.next()
                        convo.ask(kairesp('What is your zip code?'), function (res, convo) {
                            controller.storage.users.get(message.user, function (err, user_data) {
                                process_td_api(user_data.name, res.text, '1').then(response => {
                                    convo.say(`${response}`);
                                    convo.next();
                                })
                            })
                        })
                    })
                }
            });
        });
    });


    controller.hears('find_branch_td2', 'message_received', function (bot, message) {
        bot.startConversation(message, function (err, convo) {
            controller.storage.users.get(message.user, function (err, user_data) {
                if (user_data) {
                    controller.storage.users.get(message.zip, function (err, user_data) {
                        if (user_data) {
                            process_td_api(user_data.name, user_data.zip, '2').then(response => {
                                convo.say(`${response}`);
                                convo.next();
                            })
                        } else {
                            convo.ask(utils.createTextMessage('What is your zip code?'), function (res, convo) {
                                controller.storage.users.get(message.user, function (err, user_data) {
                                    process_td_api(user_data.name, res.text, '2').then(response => {
                                        convo.say(`${response}`);
                                        convo.next();
                                    })
                                })
                            })
                        }
                    });
                } else {
                    convo.ask(kairesp('What is your name?'), function (res, convo) {
                        controller.storage.users.save({id: message.user, name: res.text}, function (err) {
                        });
                        convo.next()
                        convo.ask(kairesp('What is your zip code?'), function (res, convo) {
                            controller.storage.users.get(message.user, function (err, user_data) {
                                process_td_api(user_data.name, res.text, '2').then(response => {
                                    convo.say(`${response}`);
                                    convo.next();
                                })
                            })
                        })
                    })
                }
            });
        });
    });

    function process_td_api(name, zip, poi) {
        // Return new promise
        return new Promise(function (resolve, reject) {
            // Do async job
            const axios = require("axios");
            const url = `https://www.tdbank.com/net/get12.ashx?Json=Y&numresults=1&zip=${zip}&poi=${poi}`;
            axios.get(url).then(function (response) {
                //console.log(response)
                var user = {};
                user.zip = zip
                user.name = name
                console.log(response.data.markers.marker[0]);
                const locdetails = response.data.markers.marker[0];
                if (locdetails != undefined) {
                    user.nearest_atm_address = locdetails.address;
                    var dow = new Date();
                    switch (dow) {
                        case 0:
                            user.nearest_atm_hours = locdetails.hours.Monday;
                            break;
                        case 1:
                            user.nearest_atm_hours = locdetails.hours.Tuesday;
                            break;
                        case 2:
                            user.nearest_atm_hours = locdetails.hours.Wednesday;
                            break;
                        case 3:
                            user.nearest_atm_hours = locdetails.hours.Thursday;
                            break;
                        case 4:
                            user.nearest_atm_hours = locdetails.hours.Friday;
                            break;
                        case 5:
                            user.nearest_atm_hours = locdetails.hours.Saturday;
                            break;
                        case 6:
                            user.nearest_atm_hours = locdetails.hours.Sunday;
                            break;
                        default:
                            user.nearest_atm_hours = locdetails.hours.Monday;
                    }
                }

                var respmsg = null;
                //Add *** to signigy that the dialog is complete
                if (user.nearest_atm_address) {
                    if (poi == '1') {
                        //respmsg = `***Hello ${ user.name }. The nearest ATM to your zip: ${ user.zip} is located at ${ user.nearest_atm_address } \n\n Here are today's opening hours: ${user.nearest_atm_hours}`;
                        respmsg = createLocationCard(locdetails, user)
                    } else {
                        respmsg = createLocationCard(locdetails, user)
                        //respmsg = `***Hello ${ user.name }. The nearest branch to your zip: ${ user.zip} is located at ${ user.nearest_atm_address } \n\n Here are today's opening hours: ${user.nearest_atm_hours}`;
                    }
                } else {
                    if (poi == '1') {
                        respmsg = kairesp(`***Hello ${ user.name }. There is no ATM nearby. `);
                    } else {
                        respmsg = kairesp(`***Hello ${ user.name }. There is no ATM nearby. `);
                    }


                }
                resolve(respmsg);

            }).catch(function (error) {
                console.log(error);
                reject(error)
            })
        });

    }

    function createLocationCard(locdetails, user) {
        const google_map_url = `http://maps.google.com/?z=12&t=m&q=${locdetails.lat}+${locdetails.lng}`
        const google_map_static = `https://maps.googleapis.com/maps/api/staticmap?center=${locdetails.lat},${locdetails.lng}&zoom=12&size=400x400&key=AIzaSyAzKgoP9c-L7eptE9v4MTa1d1sBEHvnTxk&format=png&visual_refresh=true&markers=size:mid%7Ccolor:red%7Clabel:1%7C${locdetails.lat},${locdetails.lng}`
        const address = locdetails.address
        const distance = locdetails.distance + ' miles away'
        const text = `Hello ${ user.name }. The nearest ATM to your zip: ${ user.zip} is located at ${ user.nearest_atm_address } \n\n Here are today's opening hours: ${user.nearest_atm_hours}.  I've provided a map to help you find your way.`;
        var cardArr = [];
        cardArr.push(utils.createCard(distance, address, google_map_static))
        //add *** to signify conversation complete
        return kairespFromFormattedResponse(utils.createCarousel(text, cardArr),{complete: true});
    }

};





