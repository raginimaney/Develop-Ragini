module.exports = function (controller) {
    const kaiutils = require('../../../../../lib/kai-utils.js');
    const logger = require('../../../../../lib/logger');
    const util = require('util') //logging util
    var config = require('../../../../../config/config.js');
    var debug = require('debug')('iapi:skill:transaction_enquiry')


    /**
     * The workflow states
     */
    const wfStates = {
        DONE: 'done',
        ACCOUNTNUM: 'accountnum',
        TXDATE: 'txdate',
        TXAMOUNT: 'txamount',
        REFNUM: 'refnum',
        RETRYNOREF: 'retry_nonref',
        FAIL: 'fail'
    }


    const Messages = {
        tx_pre2: {msg: "OK. Here is what I've found"},
        greeting: {msg: "Sure! I can help with that"},
        tx_pre: {msg: "Ok. Here is what I found:"},
        prompt_moreinfo: {msg: "Sure, I can help with wires, but I need some information."},
        prompt_ref: {msg: "Whats the reference number? If thats not available, tell me the account, amount and date."},
        prompt_account: {msg: "What is the account number?"},
        prompt_date: {msg: "What is the transaction date?"},
        prompt_amount: {msg: "What is the amount"},
        no_transaction: {msg: "I am unable to locate your transaction. If your transaction was initiated via our Bank, please verify that it has been released"},
        prompt_retry: {msg: "Sorry, I didnt find a transaction that  matches your request. Lets try another way. Whats the account number"}
    }


    //create alias shortcut
    function generateKaiResponse(message, options, txs) {

        var cardArr = [];
        if (options && options.complete && txs && txs.length > 0) {
            for (var aTrans of txs) {

                var status_update = kaiutils.getMetaProperty(aTrans, "status_update");

                var uetr = kaiutils.getMetaProperty(aTrans, "uetr");


                cardArr.push(kaiutils.createCard("Transaction id:" + aTrans["transaction_id"],
                    "Amount:" + aTrans["amount"] + "\nDate:" + kaiutils.extractDate(aTrans["transaction_date"]) + "\nStatus:" + status_update
                    + "\nUETR:" + uetr));
            }
            return kairespFromFormattedResponse(kaiutils.createCarousel(Messages.tx_pre.msg, cardArr), options);
        } else {
            return kaiutils.createIAPIResponse(message, options)
        }
    }


    function buildKaiResponseFromVars(prompt, type, varname, txs, complete) {

        return generateKaiResponse(prompt, {
            complete: complete,
            user_input_type: type,
            user_input_name: varname
        }, txs)


    }

//create alias shortcut
    function kairespFromFormattedResponse(respmsg, options) {
        return kaiutils.createIAPIResponseFromKaiFormattedRespMsg(respmsg, options)
    }


    /**
     * Determine the next step (or piece of information to be collected
     * @param collected_inputs
     * @param txs
     * @returns {string}
     */
    function getNextStep(collected_inputs, txs) {

        if (collected_inputs.accountnum && collected_inputs.txamount && collected_inputs.txdate && txs && txs.length > 0) {
            return wfStates.DONE
        } else if (collected_inputs.accountnum && collected_inputs.txamount && collected_inputs.txdate && txs && txs.length < 1) {
            return wfStates.FAIL
        } else if (collected_inputs.txdate && collected_inputs.txamount) {
            return wfStates.ACCOUNTNUM
        } else if (collected_inputs.amount && collected_inputs.accountnum) {
            return wfStates.TXDATE
        } else if (collected_inputs.txdate && collected_inputs.accountnum) {
            return wfStates.TXAMOUNT
        } else if (collected_inputs.txdate) {
            returnwfStates.ACCOUNTNUM
        } else if (collected_inputs.accountnum) {
            return wfStates.TXDATE
        } else if (collected_inputs.txamount) {
            return wfStates.ACCOUNTNUM
        } else if (collected_inputs.refnum && txs.length > 0) {
            return wfStates.DONE
        } else if (collected_inputs.refnum && txs.length < 1) {
            return wfStates.RETRYNOREF
        } else {
            return wfStates.REFNUM
        }
    }


    function preProcessTriggerInputs(inputs) {

        var outputs = {}
        for (var input of inputs) {
            var name = input.name.replace("TI_", "");
            outputs[name] = input.value;
        }
        return outputs;
    }

    var dc = {} //dialog context
    controller.hears('transaction_inquiry', 'message_received', function (bot, message) {
        bot.createConversation(message, function (err, convo) {
            convo.addMessage(generateKaiResponse("goodbye", {complete: true}), 'goodbye_message')
            convo.addMessage(generateKaiResponse("Apologies an error occurred handling your question. Please login and try again", {complete: true}), 'login_error_message')
            convo.beforeThread('loop-controller', function (convo, next) {
                var out = convo.vars.out;

                if (out.input_param && out.input_param["name"]) {
                    var varSub = out.input_param["name"].replace("input_", "");
                    convo.setVar(varSub, out.input_param["value"]);
                }

                var collected_inputs = convo.vars;
                var filteredTxs = getFilteredTransactionsFromCache(collected_inputs, message);


                var response = buildKaiResponseFromInputs(collected_inputs, filteredTxs);

                convo.setVar('dynamic_out', response);
                next();

            });


            convo.addQuestion('{{vars.dynamic_out}}',
                function (response, convo) {

                    var out = convo.vars.out;
                    if (!out) {
                        out = {}
                    }
                    out.input_param = response.extra.user_inputs[0];

                    convo.setVar("out", out)

                    convo.gotoThread('loop-controller')
                }, {}, 'loop-controller')


            convo.activate();

            loadBankingCache(message.extra.token, message.user).then(function (result) {
                kaiutils.saveUserDefinedData(controller, message, 'eapi', result, function (err) {
                    if (err) convo.gotoThread('login_error_message')
                    debug("%o\neapi Cache Saved", result)
                })
            }).then(function () {
                //generate the opening question based on whether slots have been pre-populated or not
                var openQuestion = buildKaiResponseFromInputs(preProcessTriggerInputs(message.extra.user_inputs));
                convo.addQuestion(openQuestion, function (response, convo) { //response.text is the account id

                    var out = convo.vars.out;
                    if (!out) {
                        out = {}
                    }
                    out.input_param = response.extra.user_inputs[0];
                    convo.setVar("out", out)

                    for (var someInput of message.extra.user_inputs) {
                        if (someInput["name"]) {
                            var varSub = someInput["name"].replace("TI_", "");
                            convo.setVar(varSub, someInput["value"]);
                        }
                    }

                    convo.gotoThread('loop-controller')
                    convo.next();
                }, {}, 'default');

            }).catch(function (err) {
                debug(err)
                convo.gotoThread('login_error_message')
            })

        });

    });


    function buildKaiResponseFromInputs(collected_inputs, filteredTxs) {


        var nextStep = getNextStep(collected_inputs, filteredTxs);

        var inputname = "input_accountnum";

        var prompt;

        var complete = false

        if (nextStep === wfStates.ACCOUNTNUM) {
            prompt = Messages.prompt_account.msg;
            inputname = "input_accountnum";
            input_type = kaiutils.USER_INPUT_TYPES.number;
        } else if (nextStep === wfStates.TXDATE) {
            prompt = Messages.prompt_date.msg
            inputname = "input_txdate";
            input_type = kaiutils.USER_INPUT_TYPES.date
        } else if (nextStep === wfStates.TXAMOUNT) {
            prompt = Messages.prompt_amount.msg
            inputname = "input_txamount";
            input_type = kaiutils.USER_INPUT_TYPES.currency_amount
        } else if (nextStep === wfStates.DONE) {
            prompt = "goodbye";
            inputname = ""
            input_type = ""
            complete = true;
        } else if (nextStep === wfStates.FAIL) {
            prompt = Messages.no_transaction.msg
            inputname = ""
            input_type = ""
            complete = true;
        } else if (nextStep === wfStates.RETRYNOREF) {
            prompt = Messages.prompt_retry.msg
            inputname = "input_accountnum";
            input_type = kaiutils.USER_INPUT_TYPES.number
            complete = false;
        } else {
            prompt = Messages.prompt_ref.msg
            inputname = "input_refnum";
            input_type = kaiutils.USER_INPUT_TYPES.string
        }


        var response = buildKaiResponseFromVars(prompt, input_type, inputname, filteredTxs, complete);

        return response;

    }


    /**
     * Get the filtered transactions from the transaction cache based on the filter options
     *
     * It will return all transactions that match each of the otpions.
     * @param filterOptions
     * @returns {Array}
     */
    function getFilteredTransactionsFromCache(filterOptions, message) {
        var eapiCache
        var txCache
        var accountCache
        //in memory cache for ALL transactions and accounts
        //filtering is down after the fact against these arrays
        kaiutils.getUserDefinedData(controller, message, 'eapi', function (err, data) {
            if (err) return console.log('Ooops! EAPI Error', err) // some kind of I/O error
            eapiCache = data
            debug(eapiCache)
            txCache = eapiCache.transaction_cache
            accountCache = eapiCache.account_cache

        })


        var searchOptions = {}

        //only filter by ref number if not using account number
        if (filterOptions.refnum && !filterOptions.accountnum) {
            searchOptions['transaction_reference_no'] = ({
                name: "transaction_reference_no",
                value: filterOptions.refnum,
                "meta": true
            });
        }


        //if the option is an account_number must do a 'join' with accounts to find the account-id
        if (filterOptions.accountnum) {

            var accountSearchOptions = {}


            accountSearchOptions['account_number'] = {
                name: "account_number",
                value: filterOptions.accountnum,
                "meta": false
            };

            var accounts = kaiutils.filterAccounts(accountCache, accountSearchOptions);


            if (accounts && accounts.length > 0) {
                var resolvedAccountId = accounts[0].account_id;
                searchOptions['account_id'] = {name: "account_id", value: resolvedAccountId, "meta": false};
            } else {
                searchOptions['account_id'] = {name: "account_id", value: "NOT_FOUND_ACCOUNT_ID", "meta": false};
            }

        }

        if (filterOptions.txdate) {
            searchOptions['transaction_date'] = ({
                name: "transaction_date",
                value: filterOptions.txdate,
                "meta": false
            });
        }

        if (filterOptions.txamount) {

            searchOptions['amount'] = ({name: "amount", value: filterOptions.txamount, "meta": false});

        }


        var tx = kaiutils.filterTransactions(txCache, searchOptions);

        /*
            expand search by 10% on either side if no transactions found
         */
        if (tx.length < 1 && searchOptions['amount']) {


            var origAmount = searchOptions['amount'].value

            var lowerBound = (origAmount * 1.0) - (0.10 * origAmount);
            var upperBound = (origAmount * 1.0) + (0.10 * origAmount);


            searchOptions['amount'] = ({
                name: "amount",
                value: "[" + lowerBound + "-" + upperBound + "]",
                "meta": false
            });

            tx = kaiutils.filterTransactions(txCache, searchOptions);
            return tx;

        } else {
            return tx;
        }


    }


    /**
     * Load accounts and transactions into memory.  Load upon initial request.
     *
     * This is done to sidestep some of the issues around promises, but also may be useful for performance.
     *
     * Mick and I need to review to see if we can introduce the promises more effectively back into the code
     *
     * @param token
     * @param user_id
     * @param options
     */

    function loadBankingCache(token, user_id, options) {
        var bankingCache = {}
        return new Promise(function (resolve, reject) {
            kaiutils.getTransactions(config.get('enterprise_api_secret'), config.get('enterprise_api_url'), token, options).then(function (result) {
                bankingCache.transaction_cache = result.transactionArray
                kaiutils.getAccounts(config.get('enterprise_api_secret'), config.get('enterprise_api_url'), token, "").then(function (result) {
                    bankingCache.account_cache = result.accountArray;
                }).then(function () {
                    //console.log(util.inspect(bankingCache, false, null, true /* enable colors */))
                    resolve(bankingCache)
                }).catch(function (err) {
                    throw err
                })
            }).catch(function (err) {
                reject(err)
            })
        })
    }


}

