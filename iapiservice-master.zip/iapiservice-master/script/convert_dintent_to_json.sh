
#!/bin/bash
clear
echo "USAGE: $0 [dynamic_intent_file]"
echo "EXAMPLE: $0 $KAI_HOME/Kai/Apps/kai-en-us/conf/domain/lola/user/xml/dynintents/apps/liv/dynintents.xml "
export NODE_PATH=../node
if [ "$#" -ne 1 ]; then
    echo "Missing Mandatory Param: <Dynamic Intent File>"
    exit 0
fi

node node/lib/convertdintent2json.js $1


