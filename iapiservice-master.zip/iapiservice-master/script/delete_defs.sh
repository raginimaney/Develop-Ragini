#!/bin/bash

echo "about to modify and upload intent definitions"
echo "assumes all intent definitions have webhook url specified that will be replaced by parameters provided"
echo "files will be then posted to target kai environment: $IAPI_KAI_HOSTNAME"

#IAPI_HOSTNAME
#IAPI_PROTOCOL
#IAPI_PORT
#IAPI_KAI_HOSTNAME
#IAPI_KAI_PROTOCOL
#IAPI_KAI_PORT

DGC_SECRET=ef576554-637f-11e8-adc0-fa7ae01bbebc

IAPI_HOSTNAME="${IAPI_HOSTNAME:=localhost}"
IAPI_PROTOCOL="${IAPI_PROTOCOL:=http}"
IAPI_PORT="${IAPI_PORT:=8082}"
IAPI_KAI_HOSTNAME="${IAPI_KAI_HOSTNAME:=localhost}"
IAPI_KAI_PROTOCOL="${IAPI_KAI_PROTOCOL:=http}"
IAPI_KAI_PORT="${IAPI_KAI_PORT:=8090}"
INTENT_DEF_DIR="${INTENT_DEF_DIR:=$PWD\/intent_definitions\/}"

#kai-server URL
KAI_URL="$IAPI_KAI_PROTOCOL://$IAPI_KAI_HOSTNAME:$IAPI_KAI_PORT"
INTENT_API="$KAI_URL/kai/api/v1/intents/"
INTENT_API_WITH_NAME="$KAI_URL/kai/api/v1/intents?name="
VPA_API="$KAI_URL/kai/api/v1/vpa/"

now=$(date +"%Y.%m.%d_%H.%M.%S")


for f in $INTENT_DEF_DIR/*.json
do
   echo $f
   #mac specific request
   sed -i "" "s|http[^\"]*\"|$IAPI_PROTOCOL:\/\/$IAPI_HOSTNAME:$IAPI_PORT\/api\/intents\"|g" "$f"
   #non-mac version
   sed -i "s|http[^\"]*\"|$IAPI_PROTOCOL:\/\/$IAPI_HOSTNAME:$IAPI_PORT\/api\/intents\"|g" "$f"
   NAME=`cat $f | awk '/\"name\"/ {gsub("\"", "", $3); gsub(",", "", $3); print $3}'`
   echo "delete json definition $f [name=$NAME]"
   curl -X DELETE -H "Content-Type: application/json" -H "secret: $DGC_SECRET" $INTENT_API_WITH_NAME$NAME -k
done
echo "done modifying and updating the intent defintions to $KAI_URL"




