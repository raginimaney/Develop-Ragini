
#!/bin/bash
curl -X POST -H "Content-Type: application/json" -H "secret: ef576554-637f-11e8-adc0-fa7ae01bbebc" -d@$1 http://localhost:8090/kai/api/v1/intents/;
