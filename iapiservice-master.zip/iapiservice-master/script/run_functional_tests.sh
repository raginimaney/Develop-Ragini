#!/bin/bash

#script to execute the set of functional tests from a particular directory
echo "about to run functional tests..."

#path to the kai sourcecode/functional test runner
KAI_HOME=../../kai/

#directory with the specific testscripts
TEST_DIR=../test/testcases/functional/java/


DGC_SECRET=ef576554-637f-11e8-adc0-fa7ae01bbebc

#kai-server URL
KAI_URL="$KAI_HOST:$KAI_PORT"
INTENT_API="$KAI_URL/kai/api/v1/intents/"
VPA_API="$KAI_URL/kai/api/v1/vpa/"

IAPI_HOST="${IAPI_HOST/http:\/\//}"
IAPI_HOST="${IAPI_HOST/https:\/\//}"
echo "iapi=$IAPI_HOST"

bobscript_dir=$PWD/test/testcases/functional/$IAPI_TYPE/

echo "assumes that all the intent-definitions have been uploaded to the target KAI environment"

echo "execute bobscript tests"
for f in $TEST_DIR/*.json
do
        cmd="ant -buildfile $KAI_HOME/tests/build.xml  unit -Dtests.filename=$f -Dno.testcore.publish=true -Dserver.url=$KAI_HOST -Dserver.port=$KAI_PORT"
        echo $cmd
        $cmd
done

