#!/usr/bin/env bash
echo "about to train intent definitions"
echo "assumes all intent definitions have previously been uploaded"
echo "(RETRAINING API TBD) so assumes training  done on KAI @ localhost"
set -x

KAI_HOME=~/SourceCode/Kasisto/Kai
KAI_SUBAPP=kai
KAI_DOMAIN_LOCALE=en_US
now=$(date +"%Y.%m.%d_%H.%M.%S")
echo "starting training ${now} for $KAI_SUBAPP for locale $KAI_DOMAIN_LOCALE"
dynintents=`find ${KAI_HOME}/Apps/kai-en-us/build -name dynintents.xml`
statparsertrainer=`find ${KAI_HOME}/Apps/kai-en-us/src -name StatParserTrainer.java`
cp $statparsertrainer /tmp/StatParserTrainer.java
cp $dynintents $KAI_HOME/Apps/kai-en-us/conf/domain/lola/user/xml/dynintents/apps/$KAI_SUBAPP/dynintents.xml
cd $KAI_HOME/Apps/kai-en-us

#Uncomment the lines below to Comment out Argument Classifier Training - Leave Intent Training Classifier
statparsertrainer=`find ${KAI_HOME}/Apps/kai-en-us/src -name StatParserTrainer.java`
cp $statparsertrainer /tmp/StatParserTrainer.java
line="trainArgumentClassifiers(c"
grep -v $line $statparsertrainer > /tmp/tmp
cp /tmp/tmp $statparsertrainer
ant stat.parser.trainer -DsubApp=$KAI_SUBAPP -Ddomain_locale=$KAI_DOMAIN_LOCALE
# Restore original file and recompile
cp  /tmp/StatParserTrainer.java $statparsertrainer
cd -

