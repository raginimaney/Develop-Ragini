
//////////////////////////////////////////////////////////////
// Botium
//////////////////////////////////////////////////////////////

const BotDriver = require('botium-core').BotDriver
const Capabilities = require('botium-core').Capabilities
const Events = require('botium-core').Events
const Source = require('botium-core').Source
const path = require('path')
const copy = require('copy');
const config = require(path.join(__dirname, 'config/config.js'));
var convo_path = config.get("botium_convo_path");

var num_success = 0;
var num_error =0;


//to allow parallel runners to route traffic to the same proxy.  The proxy should use a session map based on the runner-id
//to run concurrent launch as follows:
// RUNNER_ID=1 npm test
// RUNNER_ID=2 npm test
// etc
const runner_id = process.argv[2]
console.log("runner_id: "+runner_id); 
function assert (actual, expected, stepTag) {
    if (!actual || actual.indexOf(expected) < 0) {
        num_error += 1;
        console.log(`ERROR: Expected <${expected}>, got <${actual}>`)
    } else {
        num_success += 1;
        console.log(`SUCCESS: Got Expected <${expected}> : <${actual}>`)
    }
}

function fail (err) {
    console.log(`ERROR: <${err}>`)
    throw err
}

const driver = new BotDriver()
    .setCapability(Capabilities.PROJECTNAME, 'Node IAPI Unit Tests')
    //.setCapability(Capabilities.CONTAINERMODE, 'docker')
    .setCapability(Capabilities.CONTAINERMODE, 'simplerest')
    .setCapability(Capabilities.SIMPLEREST_URL, 'http://localhost:5050/tests?runner_id='+runner_id)
    .setCapability(Capabilities.SIMPLEREST_METHOD, 'POST')
    .setCapability(Capabilities.SIMPLEREST_BODY_TEMPLATE, "{\"text\": \"{{msg.messageText}}\"}")
    .setCapability(Capabilities.SIMPLEREST_RESPONSE_JSONPATH, "$.message_contents[0].payload.text")
    .setCapability(Capabilities.SIMPLEREST_RESPONSE_JSONPATH_TX0, "$.message_contents[1].payload.title")
    .setCapability(Capabilities.SIMPLEREST_RESPONSE_JSONPATH_TX1, "$.message_contents[1].payload.contents[0].payload.title")
    .setCapability(Capabilities.SIMPLEREST_RESPONSE_JSONPATH_TX2, "$.message_contents[1].payload.contents[1].payload.title")
    .setCapability(Capabilities.SIMPLEREST_BUTTONS_JSONPATH_B0, "$.quick_replies[0].display_text")
    .setCapability(Capabilities.SIMPLEREST_BUTTONS_JSONPATH_B1, "$.quick_replies[1].display_text")
    .setCapability(Capabilities.SIMPLEREST_BUTTONS_JSONPATH_B2, "$.quick_replies[2].display_text")
    .setCapability(Capabilities.SIMPLEREST_BUTTONS_JSONPATH_B3, "$.quick_replies[3].display_text")
    .setCapability(Capabilities.SIMPLEREST_BUTTONS_JSONPATH_B4, "$.quick_replies[4].display_text")
    .setCapability(Capabilities.SCRIPTING_MATCHING_MODE, "include")
    //.setCapability(Capabilities.SCRIPTING_UTTEXPANSION_MODE, "random")
    .setCapability(Capabilities.SCRIPTING_UTTEXPANSION_MODE, "all")
    .setCapability(Capabilities.SCRIPTING_UTTEXPANSION_RANDOM_COUNT, 1)
    .setCapability(Capabilities.SCRIPTING_UTTEXPANSION_INCOMPREHENSION, "INCOMPREHENSION")
    .setCapability(Capabilities.CLEANUPTEMPDIR, true)
    .setCapability(Capabilities.WAITFORBOTTIMEOUT, "30000")
    .setSource(Source.LOCALPATH, '.')
    .setCapability(Capabilities.STARTCMD, 'npm install && node index.js')
    .setEnv('NODE_TLS_REJECT_UNAUTHORIZED', 0)

driver.on(Events.MESSAGE_SENTTOBOT, (container, msg) => {
    console.log('me: ' + msg.messageText)
})


const args = require('minimist')(process.argv.slice(2))
var source = args['source']
if (source != undefined) {
    var fs = require('fs');
    var dir = './.tmp';
    if (fs.existsSync(dir)){
        var rimraf = require("rimraf");
        rimraf.sync(dir);
    }
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir);
    }
    fs.copyFile(source, `${dir}/tmp.convo.txt`, (err) => {
        if (err) throw err;
        convo_path = dir;
        //copy utterance files as well
        //Extract the filename, but leave the file extension:
        var sourcdir = path.dirname(source);
        console.log(`copying ${sourcdir}/*.utterances.txt to ${dir}`);
        copy(`${sourcdir}/*.utterances.txt`, dir, function(err, file) {
            if (err) console.log('finished copying utterances. nothing to copy');
            console.log('convo_path = ' + convo_path);
            console.log(`finished copying utterances to ${convo_path}`);
            driver.BuildFluent()
                .ReadScripts(convo_path)
                .RunScripts(assert, fail)
                .Exec()
                .then(() => {
                    var total = Number(num_success) + Number(num_error);
                    console.log(`TOTAL: ${total}\n SUCCESS: ${num_success}\n ERROR: ${num_error}`)

                })
                .catch((err) => {
                    console.log('ERROR: ', err)
                })
                .finally(() => {
                    //console.log('READY')
                    process.exit()
                })
        });



    });

} else {
    console.log('convo_path = ' + convo_path);
    driver.BuildFluent()
        .ReadScripts(convo_path)
        .RunScripts(assert, fail)
        .Exec()
        .then(() => {
            var total = Number(num_success) + Number(num_error);
            console.log(`TOTAL: ${total}\n SUCCESS: ${num_success}\n ERROR: ${num_error}`)

        })
        .catch((err) => {
            console.log('ERROR: ', err)
        })
        .finally(() => {
            //console.log('READY')
            process.exit()
        })


}


//////////////////////////////////////////////////////////////////////////////////////////

