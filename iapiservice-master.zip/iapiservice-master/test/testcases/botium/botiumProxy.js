//////////////////////////////////////////////////////////////
// IAPI Botium Test Proxy
//////////////////////////////////////////////////////////////
const path = require('path')
var config = require(path.join(__dirname, 'config/config.js'));
var sessionid={}
var token={}

const express = require('express')
const bodyParser = require('body-parser')
const request = require('request')
const app = express()

app.set('port', (process.env.PROXYPORT || 5050))
// parse application/json
app.use(bodyParser.json())

// index
app.get('/ping', function (req, res) {
    var now = (new Date).toUTCString()
    res.status(200).send(`${now} - ping received`)
})

// to post data
app.post('/tests', function (req, res) {
    console.log(req.body)
    let secret = (req.get("secret"))
    let runner_id = "1"
    //allow the the client use a runner_id parameter
    //all session-id data will be associated with the runner_id 
    if(req.query.runner_id !== 'undefined'){
         runner_id = req.query.runner_id
    }


    console.log("using runner_id="+runner_id)
    let  capi=`${config.get('kai.protocol')}://${config.get('kai.hostname')}:${config.get('kai.port')}/kai/api/v2/capi`
    let tmp = req.body.text
    var text = tmp.replace(/&#39;/g, '\u0027');


    //console.log(text)
    var headers = {
        'secret': secret,
        'Content-Type': 'application/json'
    }

    if (text.slice(0, 12) == "ENTER_TOKEN.") {
        token[runner_id] = text.slice(12)
        console.log("Processing event ENTER_TOKEN ["+JSON.stringify(token)+"]")
        let messageData = {
            "context": {
                "device": {
                    "type": "botium",
                    "os": "Mac/iOS",
                    "model": "Chrome",
                    "id": ""
                },
                "platform": {
                    "name": "web",
                    "conversation_id": "",
                    "session_id": null,
                    "version": "1.34"
                },
                "user": {
                    "session_id": sessionid[runner_id],
                    "time_zone": ""
                },
                "api_version": "2.1.2"
            },
            "type": "ENTER_TOKEN",
            "payload": {
                "token": token[runner_id] 
            }
        }

        //console.log("URL=" + `${capi}/event`)
        request({
            url: `${capi}/event`,
            headers: headers,
            method: 'POST',
            json: messageData
        }, function(error, response, body) {
            if (error) {
                console.log('Error sending messages: ', error)
            } else if (response.body.error) {
                console.log('Error: ', response.body.error)
            } else {
                console.log('Bot Sent Message: ', messageData)
                console.log('KAI Sent Response: ', body)
                sessionid[runner_id] = body.context.user.session_id
                setTimeout(function () {
                    return res.status(200).send(body)
                }, 2000) //wait
            }

        })


    } else {
        console.log(`Processing USER_MESSAGE [${text}]`)
        let messageData = {
            "context": {
                "device": {
                    "type": "web",
                    "os": "Mac/iOS",
                    "model": "Chrome",
                    "id": ""
                },
                "platform": {
                    "name": "web",
                    "conversation_id": "",
                    "session_id": null,
                    "version": "1.34"
                },
                "user": {
                    "session_id": sessionid[runner_id],
                    "time_zone": ""
                },
                "api_version": "2.1.2"
            },
            "type": "TEXT",
            "payload": {
                "text": unescapeHTML(text)
            }
        }


        //console.log("URL=" + `${capi}/user_message`)
        request({
            url: `${capi}/user_message`,
            headers: headers,
            method: 'POST',
            json: messageData
        }, function(error, response, body) {
            if (error) {
                console.log('Error sending messages: ', error)
            } else if (response.body.error) {
                console.log('Error: ', response.body.error)
            } else {
                console.log('Bot Sent Message: ', messageData)
                console.log('KAI Sent Response: ', body)
                sessionid[runner_id] = body.context.user.session_id
                return res.status(200).send(body)
            }
        })


    }
});

app.listen(app.get('port'), function() {
    console.log('Tests listening on port', app.get('port'))
})

var htmlEntities = {
    nbsp: ' ',
    cent: '¢',
    pound: '£',
    yen: '¥',
    euro: '€',
    copy: '©',
    reg: '®',
    lt: '<',
    gt: '>',
    quot: '"',
    amp: '&',
    apos: '\''
};

function unescapeHTML(str) {
    return str.replace(/\&([^;]+);/g, function (entity, entityCode) {
        var match;

        if (entityCode in htmlEntities) {
            return htmlEntities[entityCode];
            /*eslint no-cond-assign: 0*/
        } else if (match = entityCode.match(/^#x([\da-fA-F]+)$/)) {
            return String.fromCharCode(parseInt(match[1], 16));
            /*eslint no-cond-assign: 0*/
        } else if (match = entityCode.match(/^#(\d+)$/)) {
            return String.fromCharCode(~~match[1]);
        } else {
            return entity;
        }
    });
};

