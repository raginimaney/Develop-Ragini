#!/bin/bash

export IAPI_KAI_HOSTNAME=iapi-kai-stable-kai.kasis.to 
export IAPI_KAI_PORT=80
export IAPI_KAI_PROTOCOL=http

npm run testproxy &
npm run emulatorBrowser 
